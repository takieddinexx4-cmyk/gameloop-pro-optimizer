"""Hardware-aware PUBG Mobile profile templates that never force unsupported specs."""

from __future__ import annotations

from gameloop_optimizer.app_core.models import HardwareProfile, PubgProfile


def _parse_resolution(res_str: str | None) -> tuple[int, int]:
    if not res_str or "x" not in res_str.lower():
        return 1920, 1080
    try:
        w, h = res_str.lower().split("x", 1)
        return int(w.strip()), int(h.strip())
    except ValueError:
        return 1920, 1080


def build_hardware_aware_presets(hw: HardwareProfile | None = None) -> list[PubgProfile]:
    """Generate 5 baseline presets automatically capped to actual detected PC capabilities."""
    phys_cores = int(hw.cpu_cores_physical.value) if (hw and hw.cpu_cores_physical.available) else 4
    ram_gb = float(hw.ram_total_gb.value) if (hw and hw.ram_total_gb.available) else 8.0
    max_w, max_h = _parse_resolution(
        str(hw.display_resolution.value) if (hw and hw.display_resolution.available) else None
    )
    refresh_hz = int(hw.display_refresh_hz.value) if (hw and hw.display_refresh_hz.available) else None

    safe_max_cores = max(1, min(8, phys_cores if phys_cores <= 2 else max(2, phys_cores // 2)))
    safe_max_ram_mb = max(1024, min(8192, int((ram_gb * 1024) * 0.5 // 512) * 512))

    raw_specs = [
        ("low_end", "Low-End Stability", "Low-End", "Prioritizes stability and minimal stutter on entry-level PCs.", "Auto", 1280, 720, 160, 60, "Smooth", "Close", 2, 2048),
        ("balanced", "Balanced", "Balanced", "Balanced visuals and resource overhead for mid-range systems.", "Auto", 1600, 900, 240, 60, "Smooth", "Balanced", 4, 4096),
        ("high_performance", "High Performance", "High Performance", "Smooth visuals optimized for consistent frame pacing on capable hardware.", "DirectX+", 1920, 1080, 240, 90, "Smooth", "Close", 4, 4096),
        ("competitive", "Competitive", "Competitive", "Low visual clutter and high refresh target where hardware and monitor support it.", "DirectX+", 1920, 1080, 240, 120, "Smooth", "Close", 4, 4096),
        ("high_graphics", "High Graphics", "High Graphics", "Higher resolution and visual detail for strong discrete GPUs.", "DirectX+", 1920, 1080, 320, 60, "HD", "Balanced", 4, 6144),
    ]

    profiles: list[PubgProfile] = []
    for pid, name, tier, desc, engine, w, h, dpi, fps, gfx, aa, cores, ram_mb in raw_specs:
        warnings: list[str] = []

        # Cap resolution to display resolution
        capped_w, capped_h = w, h
        if w > max_w or h > max_h:
            capped_w, capped_h = max_w, max_h
            warnings.append(f"Resolution capped to detected monitor size ({max_w}x{max_h}).")

        # Cap FPS to display refresh rate and hardware reality
        capped_fps = fps
        if refresh_hz is not None and capped_fps > refresh_hz:
            capped_fps = 90 if refresh_hz >= 90 else 60
            warnings.append(f"Target FPS capped to monitor refresh rate ({refresh_hz} Hz).")
        elif refresh_hz is None and capped_fps > 60:
            warnings.append("Monitor refresh rate unavailable; verify your monitor supports > 60 Hz.")

        if phys_cores < 4 or ram_gb < 8:
            if capped_fps > 60:
                capped_fps = 60
                warnings.append("FPS capped to 60 due to entry-level CPU/RAM capacity.")

        capped_cores = min(cores, safe_max_cores)
        if capped_cores < cores:
            warnings.append(f"Emulator CPU cores capped to {capped_cores} to avoid starving Windows.")

        capped_ram = min(ram_mb, safe_max_ram_mb)
        if capped_ram < ram_mb:
            warnings.append(f"Emulator RAM capped to {capped_ram} MB (<= 50% of total system RAM).")

        profiles.append(
            PubgProfile(
                profile_id=pid,
                name=name,
                tier=tier,
                description=desc,
                engine_mode=engine,
                resolution_width=capped_w,
                resolution_height=capped_h,
                dpi=dpi,
                target_fps=capped_fps,
                graphics_quality=gfx,
                anti_aliasing=aa,
                cpu_cores_alloc=capped_cores,
                ram_mb_alloc=capped_ram,
                warnings=warnings,
            )
        )
    return profiles
