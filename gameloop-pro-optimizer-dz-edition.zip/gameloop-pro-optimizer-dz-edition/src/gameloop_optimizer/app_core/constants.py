"""Central constants and security allow/deny lists for GAMELOOP PRO OPTIMIZER — DZ EDITION."""

from __future__ import annotations

APP_NAME = "GAMELOOP PRO OPTIMIZER — DZ EDITION"
APP_SHORT_NAME = "GAMELOOP PRO OPTIMIZER"
APP_EDITION = "DZ EDITION"
APP_VERSION = "1.0.0"
APP_DATA_FOLDER = "GameLoopProOptimizer"

# Default GitHub coordinates (user updates these in Settings or constants for their repo)
DEFAULT_GITHUB_OWNER = "YOUR_GITHUB_USERNAME"
DEFAULT_GITHUB_REPO = "gameloop-pro-optimizer"

SUPPORTED_LANGUAGES = ("ar", "en")
DEFAULT_LANGUAGE = "ar"

# Known GameLoop executable names (lowercase for safe comparison)
GAMELOOP_PROCESS_NAMES = frozenset(
    {
        "androidemulatorex.exe",
        "androidemulatoren.exe",
        "androidemulator.exe",
        "appmarket.exe",
        "txgameassistant.exe",
        "aow_exe.exe",
        "qmeemulatorservice.exe",
        "syzs_dl_svr.exe",
    }
)

# Critical Windows processes that Process Manager MUST NEVER terminate or alter
PROTECTED_SYSTEM_PROCESSES = frozenset(
    {
        "system",
        "system idle process",
        "registry",
        "smss.exe",
        "csrss.exe",
        "wininit.exe",
        "winlogon.exe",
        "services.exe",
        "lsass.exe",
        "svchost.exe",
        "dwm.exe",
        "explorer.exe",
        "msmpeng.exe",
        "nissrv.exe",
        "securityhealthservice.exe",
        "securityhealthsystray.exe",
        "sgrmbroker.exe",
        "spoolsv.exe",
        "taskhostw.exe",
        "sihost.exe",
        "ctfmon.exe",
        "audiodg.exe",
        "fontdrvhost.exe",
        "memory compression",
        "lsaiso.exe",
        "ntoskrnl.exe",
        "conhost.exe",
        "searchindexer.exe",
        "startmenuexperiencehost.exe",
        "shellexperiencehost.exe",
    }
)

# File extensions that Cleaner PRO MUST NEVER delete under any condition
PROTECTED_FILE_EXTENSIONS = frozenset(
    {
        ".sav",
        ".ini",
        ".cfg",
        ".conf",
        ".json",
        ".xml",
        ".pak",
        ".obb",
        ".apk",
        ".xapk",
        ".exe",
        ".dll",
        ".sys",
        ".reg",
        ".db",
        ".sqlite",
        ".sqlite3",
        ".docx",
        ".xlsx",
        ".pdf",
        ".jpg",
        ".jpeg",
        ".png",
        ".mp4",
        ".zip",
        ".7z",
        ".rar",
    }
)

# Official external tools metadata (links only - never auto-downloaded or silently run)
OFFICIAL_EXTERNAL_TOOLS = (
    {
        "id": "process_lasso",
        "name": "Process Lasso",
        "publisher": "Bitsum LLC",
        "official_url": "https://bitsum.com/",
        "description_key": "tools.ext.process_lasso_desc",
    },
    {
        "id": "rtss",
        "name": "RivaTuner Statistics Server (RTSS)",
        "publisher": "Guru3D / Alexey Nicolaychuk (Unwinder)",
        "official_url": "https://www.guru3d.com/download/rtss-rivatuner-statistics-server-download/",
        "description_key": "tools.ext.rtss_desc",
    },
    {
        "id": "xmouse",
        "name": "X-Mouse Button Control",
        "publisher": "Highresolution Enterprises",
        "official_url": "https://www.highrez.co.uk/downloads/XMouseButtonControl.htm",
        "description_key": "tools.ext.xmouse_desc",
    },
)
