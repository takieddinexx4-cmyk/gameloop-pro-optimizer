"""PC Analysis page showing real metrics, bottleneck, issues, and honest sensor notes."""

from __future__ import annotations

from PySide6.QtWidgets import (
    QGridLayout,
    QHBoxLayout,
    QHeaderView,
    QListWidget,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
)

from gameloop_optimizer.app_core.models import AnalysisReport, MetricValue
from gameloop_optimizer.app_core.service_container import ServiceContainer
from gameloop_optimizer.ui.pages.base_page import BasePage
from gameloop_optimizer.ui.widgets.cards import MetricCard, SectionHeader


class PcAnalysisPage(BasePage):
    def __init__(self, services: ServiceContainer, parent=None) -> None:
        super().__init__(services, parent)
        self._build_ui()

    def _build_ui(self) -> None:
        top_row = QHBoxLayout()
        self.scan_btn = QPushButton()
        self.scan_btn.setObjectName("PrimaryButton")
        self.scan_btn.clicked.connect(self._run_scan)
        top_row.addWidget(self.scan_btn)
        top_row.addStretch(1)
        self.page_layout.addLayout(top_row)

        summary = QGridLayout()
        summary.setSpacing(10)
        self.score_card = MetricCard("", "--")
        self.readiness_card = MetricCard("", "--")
        self.bottleneck_card = MetricCard("", "--")
        summary.addWidget(self.score_card, 0, 0)
        summary.addWidget(self.readiness_card, 0, 1)
        summary.addWidget(self.bottleneck_card, 0, 2)
        self.page_layout.addLayout(summary)

        self.specs_table = QTableWidget(0, 3)
        self.specs_table.setHorizontalHeaderLabels(["Metric", "Value", "Details / Availability"])
        self.specs_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.specs_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.specs_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.specs_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.specs_table.setAlternatingRowColors(True)
        self.page_layout.addWidget(self.specs_table, 2)

        lists_grid = QGridLayout()
        lists_grid.setSpacing(10)

        self.issues_hdr = SectionHeader("")
        self.recs_hdr = SectionHeader("")
        self.notes_hdr = SectionHeader("")

        self.issues_list = QListWidget()
        self.recs_list = QListWidget()
        self.notes_list = QListWidget()

        lists_grid.addWidget(self.issues_hdr, 0, 0)
        lists_grid.addWidget(self.recs_hdr, 0, 1)
        lists_grid.addWidget(self.notes_hdr, 0, 2)
        lists_grid.addWidget(self.issues_list, 1, 0)
        lists_grid.addWidget(self.recs_list, 1, 1)
        lists_grid.addWidget(self.notes_list, 1, 2)
        self.page_layout.addLayout(lists_grid, 1)

    def retranslate_ui(self) -> None:
        self.scan_btn.setText(self.t("pc.run_scan"))
        self.issues_hdr.title_label.setText(self.t("pc.issues"))
        self.recs_hdr.title_label.setText(self.t("pc.recommendations"))
        self.notes_hdr.title_label.setText(self.t("pc.notes"))
        if self.services.last_analysis:
            self._render_report(self.services.last_analysis)
        else:
            self.score_card.update_metric(self.t("dashboard.card_score"), "--", "")
            self.readiness_card.update_metric(self.t("dashboard.card_readiness"), "--", "")
            self.bottleneck_card.update_metric(self.t("pc.bottleneck"), "--", "")

    def on_page_activated(self) -> None:
        if self.services.last_analysis:
            self._render_report(self.services.last_analysis)

    def _run_scan(self) -> None:
        def task(progress_cb=None, cancel_token=None) -> AnalysisReport:
            hw = self.services.hardware_detector.detect(
                progress_cb=progress_cb, cancel_token=cancel_token
            )
            return self.services.hardware_analyzer.analyze(hw)

        def on_done(report: AnalysisReport) -> None:
            self.services.last_analysis = report
            self._render_report(report)

        self.run_background_task(self.t("pc.run_scan"), task, on_done)

    def _render_report(self, report: AnalysisReport) -> None:
        unavail = self.t("common.unavailable")
        self.score_card.update_metric(self.t("dashboard.card_score"), f"{report.hardware_score} / 100")
        self.readiness_card.update_metric(self.t("dashboard.card_readiness"), report.gaming_readiness)
        self.bottleneck_card.update_metric(self.t("pc.bottleneck"), report.bottleneck)

        hw = report.hardware
        rows: list[tuple[str, MetricValue]] = [
            ("CPU", hw.cpu_name),
            ("CPU Physical Cores", hw.cpu_cores_physical),
            ("CPU Logical Threads", hw.cpu_cores_logical),
            ("CPU Max/Current Frequency", hw.cpu_freq_mhz),
            ("CPU Temperature", hw.cpu_temp_c),
            ("RAM Total", hw.ram_total_gb),
            ("RAM Available", hw.ram_available_gb),
            ("RAM Usage", hw.ram_usage_percent),
            ("GPU Adapter", hw.gpu_name),
            ("GPU VRAM", hw.gpu_vram_gb),
            ("GPU Driver Version", hw.gpu_driver_version),
            ("GPU Temperature", hw.gpu_temp_c),
            ("Storage Drives", hw.storage_summary),
            ("System Drive Free Space", hw.system_drive_free_gb),
            ("GameLoop Drive Free Space", hw.gameloop_drive_free_gb),
            ("Windows Version", hw.windows_version),
            ("Display Resolution", hw.display_resolution),
            ("Monitor Refresh Rate", hw.display_refresh_hz),
            (
                "GameLoop Path",
                MetricValue(
                    value=hw.gameloop_path,
                    available=hw.gameloop_installed,
                    reason="GameLoop installation not detected.",
                ),
            ),
            ("GameLoop Version", hw.gameloop_version),
        ]

        self.specs_table.setRowCount(len(rows))
        for idx, (label, metric) in enumerate(rows):
            self.specs_table.setItem(idx, 0, QTableWidgetItem(label))
            self.specs_table.setItem(idx, 1, QTableWidgetItem(metric.display(unavail)))
            detail = "OK" if metric.available else (metric.reason or unavail)
            self.specs_table.setItem(idx, 2, QTableWidgetItem(detail))

        self.issues_list.clear()
        self.issues_list.addItems(report.issues or ["No issues detected."])
        self.recs_list.clear()
        self.recs_list.addItems(report.recommendations)
        self.notes_list.clear()
        self.notes_list.addItems(report.notes or ["All probed metrics reported cleanly."])
