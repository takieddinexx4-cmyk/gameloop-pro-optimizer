"""Confirmation, preview, and cancellable Liquid Glass progress dialogs."""

from __future__ import annotations

from datetime import datetime, timezone

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QDialog,
    QHBoxLayout,
    QLabel,
    QPlainTextEdit,
    QProgressBar,
    QPushButton,
    QVBoxLayout,
)

from gameloop_optimizer.ui.widgets.cards import StatusBadge


class ChangeConfirmationDialog(QDialog):
    """Mandatory review & consent dialog before modifying any system or GameLoop setting."""

    def __init__(
        self,
        title: str,
        summary_lines: list[str],
        approve_text: str,
        cancel_text: str,
        parent=None,
    ) -> None:
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setMinimumWidth(540)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 18, 20, 18)
        layout.setSpacing(12)

        header = QLabel(title)
        header.setObjectName("SectionTitle")
        layout.addWidget(header)

        details = QPlainTextEdit()
        details.setReadOnly(True)
        details.setPlainText("\n".join(summary_lines))
        details.setMinimumHeight(210)
        layout.addWidget(details)

        buttons = QHBoxLayout()
        buttons.addStretch(1)

        cancel_btn = QPushButton(cancel_text)
        cancel_btn.clicked.connect(self.reject)

        approve_btn = QPushButton(approve_text)
        approve_btn.setObjectName("PrimaryButton")
        approve_btn.clicked.connect(self.accept)

        buttons.addWidget(cancel_btn)
        buttons.addWidget(approve_btn)
        layout.addLayout(buttons)


class ProgressDialog(QDialog):
    """Non-freezing task progress dialog with indeterminate fallback, live log, and Cancel."""

    def __init__(self, title: str, cancel_text: str, parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setMinimumWidth(480)
        self.setModal(True)
        self.setWindowFlag(Qt.WindowType.WindowCloseButtonHint, False)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 18, 20, 18)
        layout.setSpacing(10)

        top_row = QHBoxLayout()
        self.title_label = QLabel(title)
        self.title_label.setObjectName("SectionTitle")
        top_row.addWidget(self.title_label, 1)

        self.status_badge = StatusBadge("Running", "cyan")
        top_row.addWidget(self.status_badge)
        layout.addLayout(top_row)

        started_ts = datetime.now(timezone.utc).strftime("%H:%M:%S UTC")
        self.started_label = QLabel(f"Started: {started_ts}")
        self.started_label.setObjectName("MutedLabel")
        layout.addWidget(self.started_label)

        self.status_label = QLabel(title)
        self.status_label.setWordWrap(True)
        layout.addWidget(self.status_label)

        # Start in indeterminate mode until a genuine percentage arrives (zero fake progress)
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 0)
        self.progress_bar.setTextVisible(False)
        layout.addWidget(self.progress_bar)

        self.step_log = QPlainTextEdit()
        self.step_log.setReadOnly(True)
        self.step_log.setMaximumHeight(110)
        self.step_log.appendPlainText(f"[{started_ts}] {title}")
        layout.addWidget(self.step_log)

        btn_row = QHBoxLayout()
        btn_row.addStretch(1)
        self.cancel_btn = QPushButton(cancel_text)
        self.cancel_btn.setObjectName("DangerButton")
        btn_row.addWidget(self.cancel_btn)
        layout.addLayout(btn_row)

    def update_progress(self, percent: int, message: str) -> None:
        if percent is not None and percent >= 0:
            if self.progress_bar.maximum() == 0:
                self.progress_bar.setRange(0, 100)
                self.progress_bar.setTextVisible(True)
            self.progress_bar.setValue(max(0, min(100, int(percent))))
        if message:
            self.status_label.setText(message)
            ts = datetime.now(timezone.utc).strftime("%H:%M:%S")
            self.step_log.appendPlainText(f"[{ts}] {message}")
