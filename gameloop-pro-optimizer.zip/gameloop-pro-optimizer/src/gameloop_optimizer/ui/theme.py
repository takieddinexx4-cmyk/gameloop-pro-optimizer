"""Dark Premium Glassmorphism QSS theme with full Arabic/English clarity."""

from __future__ import annotations


def build_stylesheet() -> str:
    return """
    QWidget {
        background-color: #0B0F19;
        color: #E5EDF7;
        font-family: "Segoe UI", "Cairo", "Tahoma", sans-serif;
        font-size: 13px;
    }

    QMainWindow {
        background-color: #0B0F19;
    }

    QFrame#Sidebar {
        background-color: #0F1626;
        border-right: 1px solid rgba(255, 255, 255, 0.07);
        border-left: 1px solid rgba(255, 255, 255, 0.07);
    }

    QFrame#TopBar {
        background-color: rgba(17, 25, 42, 0.92);
        border-bottom: 1px solid rgba(255, 255, 255, 0.08);
    }

    QFrame#GlassCard {
        background-color: rgba(20, 29, 48, 0.88);
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 14px;
    }

    QFrame#GlassCard:hover {
        border: 1px solid rgba(0, 212, 255, 0.30);
    }

    QLabel#AppBrand {
        color: #00D4FF;
        font-size: 15px;
        font-weight: 700;
        background: transparent;
    }

    QLabel#PageTitle {
        color: #F8FAFC;
        font-size: 20px;
        font-weight: 700;
        background: transparent;
    }

    QLabel#SectionTitle {
        color: #E2E8F0;
        font-size: 15px;
        font-weight: 600;
        background: transparent;
    }

    QLabel#MutedLabel {
        color: #94A3B8;
        font-size: 12px;
        background: transparent;
    }

    QLabel#MetricValue {
        color: #F8FAFC;
        font-size: 22px;
        font-weight: 700;
        background: transparent;
    }

    QPushButton#NavButton {
        background-color: transparent;
        color: #94A3B8;
        border: none;
        border-radius: 10px;
        padding: 10px 14px;
        text-align: left;
        font-weight: 500;
    }

    QPushButton#NavButton:hover {
        background-color: rgba(0, 212, 255, 0.09);
        color: #E5EDF7;
    }

    QPushButton#NavButton[active="true"] {
        background-color: rgba(0, 212, 255, 0.16);
        color: #00D4FF;
        border: 1px solid rgba(0, 212, 255, 0.32);
        font-weight: 700;
    }

    QPushButton {
        background-color: #19253D;
        color: #E5EDF7;
        border: 1px solid rgba(255, 255, 255, 0.10);
        border-radius: 9px;
        padding: 8px 16px;
        font-weight: 600;
    }

    QPushButton:hover {
        background-color: #213152;
        border: 1px solid rgba(0, 212, 255, 0.40);
    }

    QPushButton:disabled {
        background-color: #131B2C;
        color: #64748B;
        border: 1px solid rgba(255, 255, 255, 0.04);
    }

    QPushButton#PrimaryButton {
        background-color: #00A8CC;
        color: #06101B;
        border: none;
        font-weight: 700;
    }

    QPushButton#PrimaryButton:hover {
        background-color: #00C6F0;
    }

    QPushButton#DangerButton {
        background-color: rgba(239, 68, 68, 0.18);
        color: #FCA5A5;
        border: 1px solid rgba(239, 68, 68, 0.40);
    }

    QPushButton#DangerButton:hover {
        background-color: rgba(239, 68, 68, 0.30);
    }

    QPushButton#SuccessButton {
        background-color: rgba(16, 185, 129, 0.20);
        color: #6EE7B7;
        border: 1px solid rgba(16, 185, 129, 0.42);
    }

    QLineEdit, QComboBox, QSpinBox, QPlainTextEdit, QTextEdit {
        background-color: #0F172A;
        color: #E5EDF7;
        border: 1px solid rgba(255, 255, 255, 0.12);
        border-radius: 8px;
        padding: 7px 10px;
    }

    QLineEdit:focus, QComboBox:focus, QSpinBox:focus {
        border: 1px solid #00D4FF;
    }

    QTableWidget, QTreeWidget, QListWidget {
        background-color: #0F172A;
        alternate-background-color: #131E34;
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 10px;
        gridline-color: rgba(255, 255, 255, 0.06);
    }

    QHeaderView::section {
        background-color: #162238;
        color: #CBD5E1;
        padding: 8px;
        border: none;
        border-bottom: 1px solid rgba(255, 255, 255, 0.10);
        font-weight: 600;
    }

    QTabWidget::pane {
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 10px;
        background-color: #0E1525;
    }

    QTabBar::tab {
        background-color: #141E33;
        color: #94A3B8;
        padding: 8px 16px;
        border-top-left-radius: 8px;
        border-top-right-radius: 8px;
        margin-right: 4px;
    }

    QTabBar::tab:selected {
        background-color: rgba(0, 212, 255, 0.16);
        color: #00D4FF;
        font-weight: 700;
    }

    QProgressBar {
        background-color: #131E34;
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 6px;
        text-align: center;
        height: 16px;
    }

    QProgressBar::chunk {
        background-color: #00D4FF;
        border-radius: 5px;
    }

    QScrollArea {
        border: none;
        background: transparent;
    }

    QScrollBar:vertical {
        background: #0B0F19;
        width: 8px;
    }

    QScrollBar::handle:vertical {
        background: #273754;
        border-radius: 4px;
        min-height: 24px;
    }
    """
