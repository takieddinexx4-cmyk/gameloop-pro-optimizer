"""Safe, audited, reversible Windows and GameLoop optimization engine."""
