"""Official external tool links and pure Win32 signature + SHA-256 verification."""

from __future__ import annotations

import ctypes
import hashlib
import sys
import webbrowser
from pathlib import Path

from gameloop_optimizer.app_core.constants import OFFICIAL_EXTERNAL_TOOLS
from gameloop_optimizer.app_core.models import VerificationResult


def _verify_authenticode_windows(file_path: str) -> tuple[bool | None, str]:
    """Verify Authenticode signature via native wintrust.dll WinVerifyTrust (zero shell)."""
    if sys.platform != "win32":
        return None, "Authenticode verification is only available on Windows."

    try:
        class GUID(ctypes.Structure):
            _fields_ = [
                ("Data1", ctypes.c_ulong),
                ("Data2", ctypes.c_ushort),
                ("Data3", ctypes.c_ushort),
                ("Data4", ctypes.c_ubyte * 8),
            ]

        class WINTRUST_FILE_INFO(ctypes.Structure):
            _fields_ = [
                ("cbStruct", ctypes.c_ulong),
                ("pcwszFilePath", ctypes.c_wchar_p),
                ("hFile", ctypes.c_void_p),
                ("pgKnownSubject", ctypes.c_void_p),
            ]

        class WINTRUST_DATA(ctypes.Structure):
            _fields_ = [
                ("cbStruct", ctypes.c_ulong),
                ("pPolicyCallbackData", ctypes.c_void_p),
                ("pSIPClientData", ctypes.c_void_p),
                ("dwUIChoice", ctypes.c_ulong),
                ("fdwRevocationChecks", ctypes.c_ulong),
                ("dwUnionChoice", ctypes.c_ulong),
                ("pFile", ctypes.POINTER(WINTRUST_FILE_INFO)),
                ("dwStateAction", ctypes.c_ulong),
                ("hWVTStateData", ctypes.c_void_p),
                ("pwszURLReference", ctypes.c_wchar_p),
                ("dwProvFlags", ctypes.c_ulong),
                ("dwUIContext", ctypes.c_ulong),
            ]

        # WINTRUST_ACTION_GENERIC_VERIFY_V2 = {00AAC56B-CD44-11d0-8CC2-00C04FC295EE}
        action_guid = GUID(
            0x00AAC56B,
            0xCD44,
            0x11D0,
            (ctypes.c_ubyte * 8)(0x8C, 0xC2, 0x00, 0xC0, 0x4F, 0xC2, 0x95, 0xEE),
        )
        file_info = WINTRUST_FILE_INFO(
            cbStruct=ctypes.sizeof(WINTRUST_FILE_INFO),
            pcwszFilePath=file_path,
            hFile=None,
            pgKnownSubject=None,
        )
        trust_data = WINTRUST_DATA(
            cbStruct=ctypes.sizeof(WINTRUST_DATA),
            dwUIChoice=2,  # WTD_UI_NONE
            fdwRevocationChecks=0,
            dwUnionChoice=1,  # WTD_CHOICE_FILE
            pFile=ctypes.pointer(file_info),
            dwStateAction=0,
        )
        status = ctypes.windll.wintrust.WinVerifyTrust(
            None, ctypes.byref(action_guid), ctypes.byref(trust_data)
        )
        if status == 0:
            return True, "Valid Windows Authenticode digital signature."
        return False, f"Signature invalid or unsigned (WinVerifyTrust code 0x{status & 0xFFFFFFFF:08X})."
    except Exception as exc:  # noqa: BLE001
        return None, f"Could not verify Authenticode signature: {exc}"


def _read_version_metadata_windows(file_path: str) -> tuple[str, str]:
    """Read CompanyName (publisher) and FileVersion via pywin32 without shell calls."""
    if sys.platform != "win32":
        return "", ""
    try:
        import win32api

        langs = win32api.GetFileVersionInfo(file_path, r"\VarFileInfo\Translation")
        if not langs:
            return "", ""
        lang, codepage = langs[0]
        prefix = f"\\StringFileInfo\\{lang:04x}{codepage:04x}\\"
        company = win32api.GetFileVersionInfo(file_path, prefix + "CompanyName") or ""
        version = win32api.GetFileVersionInfo(file_path, prefix + "FileVersion") or ""
        return str(company).strip(), str(version).strip()
    except Exception:  # noqa: BLE001
        return "", ""


class ExternalToolsManager:
    """Provides official URLs and local file verification (never silent installs)."""

    def list_tools(self) -> list[dict[str, str]]:
        return [dict(item) for item in OFFICIAL_EXTERNAL_TOOLS]

    def open_official_url(self, tool_id: str) -> tuple[bool, str]:
        for tool in OFFICIAL_EXTERNAL_TOOLS:
            if tool["id"] == tool_id:
                url = tool["official_url"]
                webbrowser.open(url)
                return True, f"Opened official page: {url}"
        return False, f"Unknown external tool ID: {tool_id}"

    def verify_downloaded_file(
        self, file_path: str, expected_sha256: str = ""
    ) -> VerificationResult:
        target = Path(file_path)
        if not target.is_file():
            return VerificationResult(file_path=file_path, exists=False, details="File does not exist.")

        h = hashlib.sha256()
        try:
            with target.open("rb") as fh:
                for chunk in iter(lambda: fh.read(65536), b""):
                    h.update(chunk)
        except OSError as exc:
            return VerificationResult(file_path=file_path, exists=True, details=f"Read error: {exc}")

        actual_hash = h.hexdigest().lower()
        clean_expected = expected_sha256.strip().lower()
        hash_matched = (actual_hash == clean_expected) if clean_expected else None

        sig_valid, sig_details = _verify_authenticode_windows(str(target))
        publisher, file_version = _read_version_metadata_windows(str(target))

        return VerificationResult(
            file_path=str(target),
            exists=True,
            sha256=actual_hash,
            hash_matched=hash_matched,
            signature_valid=sig_valid,
            publisher=publisher or "Unavailable",
            file_version=file_version or "Unavailable",
            details=sig_details,
        )
