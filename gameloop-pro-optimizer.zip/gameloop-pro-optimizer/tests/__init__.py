"""Automated non-GUI unit test suite with hardware, GameLoop, and ADB mocks."""
