"""Shared isolated fixtures for non-GUI unit tests."""

from __future__ import annotations

from pathlib import Path
import pytest

from gameloop_optimizer.app_core.config import ConfigManager
from gameloop_optimizer.backup_restore.manager import BackupManager
from gameloop_optimizer.backup_restore.registry_io import InMemoryRegistryBackend
from gameloop_optimizer.logging.audit import AuditLogger


@pytest.fixture
def isolated_data_dir(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    data_dir = tmp_path / "appdata"
    data_dir.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("GAMELOOP_OPT_DATA_DIR", str(data_dir))
    return data_dir


@pytest.fixture
def mem_registry() -> InMemoryRegistryBackend:
    return InMemoryRegistryBackend()


@pytest.fixture
def audit_logger(isolated_data_dir: Path) -> AuditLogger:
    return AuditLogger(log_dir=isolated_data_dir / "logs")


@pytest.fixture
def backup_manager(
    isolated_data_dir: Path,
    mem_registry: InMemoryRegistryBackend,
    audit_logger: AuditLogger,
) -> BackupManager:
    return BackupManager(
        backups_dir=isolated_data_dir / "backups",
        registry=mem_registry,
        audit_logger=audit_logger,
    )


@pytest.fixture
def config_manager(isolated_data_dir: Path) -> ConfigManager:
    return ConfigManager(config_path=isolated_data_dir / "config.json")
