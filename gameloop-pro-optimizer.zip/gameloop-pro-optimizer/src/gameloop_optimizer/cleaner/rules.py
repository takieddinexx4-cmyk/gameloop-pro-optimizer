"""Strict safety allow/deny rules preventing accidental deletion of user or game data."""

from __future__ import annotations

from pathlib import Path

from gameloop_optimizer.app_core.constants import PROTECTED_FILE_EXTENSIONS

# Only these temporary/log extensions may ever be proposed for cleanup
ALLOWED_CLEANUP_EXTENSIONS = frozenset(
    {
        ".log",
        ".tmp",
        ".temp",
        ".dmp",
        ".old",
        ".trace",
        ".etl",
        ".cache",
    }
)

# User folder names that Cleaner PRO must NEVER enter
FORBIDDEN_DIR_NAMES = frozenset(
    {
        "documents",
        "desktop",
        "pictures",
        "videos",
        "music",
        "downloads",
        "saved games",
        "onedrive",
        "windows",
        "system32",
        "syswow64",
    }
)


def is_path_protected(file_path: Path, allowed_roots: list[Path]) -> tuple[bool, str]:
    """Return (True, reason) if a file MUST NEVER be deleted."""
    try:
        resolved = file_path.resolve()
    except OSError:
        return True, "Could not resolve path safely."

    suffix = resolved.suffix.lower()
    if suffix in PROTECTED_FILE_EXTENSIONS:
        return True, f"Protected file extension: {suffix}"

    if suffix not in ALLOWED_CLEANUP_EXTENSIONS:
        return True, f"Extension not in temporary/log allowlist: {suffix or '(none)'}"

    lower_parts = {p.lower() for p in resolved.parts}
    forbidden_hit = lower_parts.intersection(FORBIDDEN_DIR_NAMES)
    if forbidden_hit:
        return True, f"Path intersects protected directory: {', '.join(sorted(forbidden_hit))}"

    name_low = resolved.name.lower()
    if any(token in name_low for token in ("usercustom", "active.sav", "config", "profile", "account")):
        return True, "Filename matches protected game/user configuration pattern."

    in_allowed_root = False
    for root in allowed_roots:
        try:
            resolved.relative_to(root.resolve())
            in_allowed_root = True
            break
        except ValueError:
            continue

    if not in_allowed_root:
        return True, "File lies outside approved GameLoop temporary/log directories."

    return False, ""
