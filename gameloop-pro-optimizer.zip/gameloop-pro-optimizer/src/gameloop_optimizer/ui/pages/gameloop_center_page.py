"""GameLoop Center: dynamic discovery, process lifecycle, folders, and ADB control."""

from __future__ import annotations

from PySide6.QtWidgets import (
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
)

from gameloop_optimizer.app_core.models import GameLoopInstallInfo
from gameloop_optimizer.app_core.service_container import ServiceContainer
from gameloop_optimizer.ui.pages.base_page import BasePage
from gameloop_optimizer.ui.widgets.cards import GlassCard, SectionHeader


class GameLoopCenterPage(BasePage):
    def __init__(self, services: ServiceContainer, parent=None) -> None:
        super().__init__(services, parent)
        self._info = GameLoopInstallInfo()
        self._build_ui()

    def _build_ui(self) -> None:
        info_card = GlassCard()
        self.info_label = QLabel()
        self.info_label.setWordWrap(True)
        info_card.root_layout.addWidget(self.info_label)

        ctrl_row = QHBoxLayout()
        self.detect_btn = QPushButton()
        self.detect_btn.clicked.connect(self._refresh_info)
        self.start_btn = QPushButton()
        self.start_btn.setObjectName("SuccessButton")
        self.start_btn.clicked.connect(self._start_gl)
        self.stop_btn = QPushButton()
        self.stop_btn.setObjectName("DangerButton")
        self.stop_btn.clicked.connect(self._stop_gl)
        self.restart_btn = QPushButton()
        self.restart_btn.clicked.connect(self._restart_gl)

        for btn in (self.detect_btn, self.start_btn, self.stop_btn, self.restart_btn):
            ctrl_row.addWidget(btn)
        ctrl_row.addStretch(1)
        info_card.root_layout.addLayout(ctrl_row)

        folder_row = QHBoxLayout()
        self.open_install_btn = QPushButton()
        self.open_install_btn.clicked.connect(lambda: self._open_dir(self._info.install_dir))
        self.open_ui_btn = QPushButton()
        self.open_ui_btn.clicked.connect(lambda: self._open_dir(self._info.ui_dir))
        self.open_logs_btn = QPushButton()
        self.open_logs_btn.clicked.connect(
            lambda: self._open_dir(self._info.logs_dirs[0] if self._info.logs_dirs else "")
        )
        self.open_cfg_btn = QPushButton()
        self.open_cfg_btn.clicked.connect(
            lambda: self._open_dir(self._info.config_dirs[0] if self._info.config_dirs else "")
        )
        for btn in (self.open_install_btn, self.open_ui_btn, self.open_logs_btn, self.open_cfg_btn):
            folder_row.addWidget(btn)
        folder_row.addStretch(1)
        info_card.root_layout.addLayout(folder_row)
        self.page_layout.addWidget(info_card)

        self.adb_hdr = SectionHeader("")
        self.page_layout.addWidget(self.adb_hdr)

        adb_card = GlassCard()
        adb_row = QHBoxLayout()
        self.endpoint_input = QLineEdit("127.0.0.1:5555")
        self.endpoint_input.setMaximumWidth(200)
        self.adb_check_btn = QPushButton()
        self.adb_check_btn.clicked.connect(self._check_adb)
        self.adb_connect_btn = QPushButton()
        self.adb_connect_btn.setObjectName("PrimaryButton")
        self.adb_connect_btn.clicked.connect(self._connect_adb)
        self.adb_disconnect_btn = QPushButton()
        self.adb_disconnect_btn.clicked.connect(self._disconnect_adb)
        self.adb_repair_btn = QPushButton()
        self.adb_repair_btn.setObjectName("SuccessButton")
        self.adb_repair_btn.clicked.connect(self._repair_adb)

        adb_row.addWidget(self.endpoint_input)
        adb_row.addWidget(self.adb_check_btn)
        adb_row.addWidget(self.adb_connect_btn)
        adb_row.addWidget(self.adb_disconnect_btn)
        adb_row.addWidget(self.adb_repair_btn)
        adb_row.addStretch(1)
        adb_card.root_layout.addLayout(adb_row)

        self.adb_output = QPlainTextEdit()
        self.adb_output.setReadOnly(True)
        adb_card.root_layout.addWidget(self.adb_output, 1)
        self.page_layout.addWidget(adb_card, 1)

    def on_page_activated(self) -> None:
        self._refresh_info()

    def retranslate_ui(self) -> None:
        self.detect_btn.setText(self.t("gl.detect"))
        self.start_btn.setText(self.t("gl.start"))
        self.stop_btn.setText(self.t("gl.stop"))
        self.restart_btn.setText(self.t("gl.restart"))
        self.open_install_btn.setText(self.t("gl.open_install"))
        self.open_ui_btn.setText(self.t("gl.open_ui"))
        self.open_logs_btn.setText(self.t("gl.open_logs"))
        self.open_cfg_btn.setText(self.t("gl.open_config"))
        self.adb_hdr.title_label.setText(self.t("gl.adb_section"))
        self.adb_check_btn.setText(self.t("gl.adb_check"))
        self.adb_connect_btn.setText(self.t("gl.adb_connect"))
        self.adb_disconnect_btn.setText(self.t("gl.adb_disconnect"))
        self.adb_repair_btn.setText(self.t("gl.adb_repair"))

    def _refresh_info(self) -> None:
        self._info = self.services.gameloop_discovery.discover()
        self.services.last_gameloop_info = self._info
        unavail = self.t("common.unavailable")
        running = self.services.gameloop_controller.list_running_processes()

        if self._info.installed:
            txt = (
                f"Install Dir: {self._info.install_dir}\n"
                f"Emulator EXE: {self._info.emulator_exe or unavail}\n"
                f"AppMarket EXE: {self._info.appmarket_exe or unavail}\n"
                f"ADB Binary: {self._info.adb_exe or unavail}\n"
                f"Version: {self._info.version or unavail} | Source: {self._info.detection_source}\n"
                f"Running Processes: {len(running)}"
            )
        else:
            txt = f"GameLoop: {unavail} (Not detected automatically. Set custom path in Settings if installed elsewhere.)"
        self.info_label.setText(txt)

        self.start_btn.setEnabled(self._info.installed)
        self.restart_btn.setEnabled(self._info.installed)
        self.open_install_btn.setEnabled(bool(self._info.install_dir))
        self.open_ui_btn.setEnabled(bool(self._info.ui_dir))
        self.open_logs_btn.setEnabled(bool(self._info.logs_dirs))
        self.open_cfg_btn.setEnabled(bool(self._info.config_dirs))

    def _start_gl(self) -> None:
        ok, msg = self.services.gameloop_controller.start_gameloop()
        QMessageBox.information(self, self.t("common.success" if ok else "common.error"), msg)
        self._refresh_info()

    def _stop_gl(self) -> None:
        ok, msg = self.services.gameloop_controller.stop_gameloop(force=False)
        if not ok and "still running" in msg.lower():
            ans = QMessageBox.question(self, self.t("common.confirm"), f"{msg}\nForce kill remaining GameLoop processes?")
            if ans == QMessageBox.StandardButton.Yes:
                ok, msg = self.services.gameloop_controller.stop_gameloop(force=True)
        QMessageBox.information(self, self.t("common.success" if ok else "common.warning"), msg)
        self._refresh_info()

    def _restart_gl(self) -> None:
        ok, msg = self.services.gameloop_controller.restart_gameloop(force_stop=False)
        QMessageBox.information(self, self.t("common.success" if ok else "common.warning"), msg)
        self._refresh_info()

    def _open_dir(self, path: str) -> None:
        ok, msg = self.services.gameloop_controller.open_folder(path)
        if not ok:
            QMessageBox.warning(self, self.t("common.warning"), msg)

    def _check_adb(self) -> None:
        st = self.services.adb_manager.get_status()
        lines = [
            f"ADB Available : {st.adb_available}",
            f"ADB Path      : {st.adb_path or self.t('common.unavailable')}",
            f"Server OK     : {st.server_running}",
            f"Active Ports  : {st.active_ports or 'None detected'}",
            f"Devices       : {[(d.serial, d.state) for d in st.devices] or 'None'}",
        ]
        if st.error:
            lines.append(f"Error         : {st.error}")
        self.adb_output.setPlainText("\n".join(lines))

    def _connect_adb(self) -> None:
        ok, msg = self.services.adb_manager.connect(self.endpoint_input.text().strip())
        self.adb_output.appendPlainText(f"[CONNECT {'OK' if ok else 'FAIL'}] {msg}")

    def _disconnect_adb(self) -> None:
        ok, msg = self.services.adb_manager.disconnect(self.endpoint_input.text().strip() or None)
        self.adb_output.appendPlainText(f"[DISCONNECT {'OK' if ok else 'FAIL'}] {msg}")

    def _repair_adb(self) -> None:
        def on_done(result: tuple[bool, str]) -> None:
            ok, msg = result
            self.adb_output.appendPlainText(f"[REPAIR {'OK' if ok else 'INFO'}] {msg}")

        self.run_background_task(
            self.t("gl.adb_repair"), self.services.adb_manager.repair, on_done
        )
