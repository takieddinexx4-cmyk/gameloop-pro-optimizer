"""Tests for non-admin fallback, tweak apply/verify, SHA-256 backups, and rollback."""

from __future__ import annotations

from pathlib import Path
import psutil
import pytest

from gameloop_optimizer.app_core.config import ConfigManager
from gameloop_optimizer.app_core.process_runner import CommandResult
from gameloop_optimizer.backup_restore.manager import BackupManager
from gameloop_optimizer.backup_restore.registry_io import (
    REG_DWORD,
    InMemoryRegistryBackend,
)
from gameloop_optimizer.gameloop_manager.discovery import GameLoopDiscovery
from gameloop_optimizer.logging.audit import AuditLogger
from gameloop_optimizer.optimization_engine.engine import OptimizationEngine


def test_standard_user_fallback_and_full_rollback(
    backup_manager: BackupManager,
    mem_registry: InMemoryRegistryBackend,
    audit_logger: AuditLogger,
    config_manager: ConfigManager,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(psutil, "process_iter", lambda *a, **kw: [])
    monkeypatch.setattr(psutil, "disk_partitions", lambda *a, **kw: [])

    # Simulate non-Admin standard user with existing HKLM HwSchMode=1
    mem_registry.require_admin_hklm = True
    mem_registry.is_admin = False
    mem_registry._store[("HKLM", r"SYSTEM\CurrentControlSet\Control\GraphicsDrivers", "HwSchMode")] = (
        1,
        REG_DWORD,
    )

    discovery = GameLoopDiscovery(config_manager=config_manager, registry_reader=lambda: ("", ""))
    engine = OptimizationEngine(
        backup_manager=backup_manager,
        audit_logger=audit_logger,
        gameloop_discovery=discovery,
        command_runner=lambda args, timeout=8.0: CommandResult(1, "", "powercfg unavailable"),
        admin_checker=lambda: False,
    )

    previews = {p.tweak_id: p for p in engine.list_previews("pro")}

    # HKLM tweak must report unavailable cleanly without Administrator
    assert previews["windows_hags"].available is False
    assert "administrator" in previews["windows_hags"].unavailable_reason.lower()

    # GameLoop tweak must report unavailable when GameLoop is not installed
    assert previews["gameloop_gpu_preference"].available is False

    # HKCU tweak works without Admin; original key did not exist
    assert previews["windows_game_mode"].available is True
    res = engine.apply_tweak("windows_game_mode")
    assert res.success is True
    assert res.verified is True
    assert res.backup_id != ""

    after = mem_registry.read_value("HKCU", r"Software\Microsoft\GameBar", "AutoGameModeEnabled")
    assert after.existed is True and after.value == 1

    # Rollback deletes newly created value so original absent state is restored
    ok_rb, _logs = engine.rollback_tweak("windows_game_mode")
    assert ok_rb is True
    restored = mem_registry.read_value("HKCU", r"Software\Microsoft\GameBar", "AutoGameModeEnabled")
    assert restored.existed is False


def test_backup_tampering_detected_by_sha256(
    backup_manager: BackupManager, mem_registry: InMemoryRegistryBackend
) -> None:
    mem_registry.write_value("HKCU", r"Software\Test", "Val", 42, REG_DWORD)
    snap = mem_registry.read_value("HKCU", r"Software\Test", "Val")
    rec = backup_manager.create_backup("test", "Integrity test", registry_snapshots=[snap])

    valid, _msg, _payload = backup_manager.verify_backup(rec.backup_id)
    assert valid is True

    # Tamper with stored JSON on disk
    path = Path(rec.file_path)
    tampered = path.read_text(encoding="utf-8").replace("42", "99")
    path.write_text(tampered, encoding="utf-8")

    valid_after, msg_after, _ = backup_manager.verify_backup(rec.backup_id)
    assert valid_after is False
    assert "sha-256 mismatch" in msg_after.lower()

    ok_restore, logs = backup_manager.restore_backup(rec.backup_id)
    assert ok_restore is False
    assert any("mismatch" in line.lower() for line in logs)


def test_power_plan_tweak_and_custom_rollback(
    backup_manager: BackupManager,
    audit_logger: AuditLogger,
    config_manager: ConfigManager,
) -> None:
    balanced_guid = "381b4222-f694-41f0-9685-ff5bb260df2e"
    high_guid = "8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c"
    state = {"active": balanced_guid}

    def fake_powercfg(args, timeout=8.0) -> CommandResult:
        if "/getactivescheme" in args:
            return CommandResult(0, f"Power Scheme GUID: {state['active']} (Plan)", "")
        if "/list" in args:
            return CommandResult(0, f"{balanced_guid}\n{high_guid}", "")
        if "/setactive" in args:
            state["active"] = args[2].lower()
            return CommandResult(0, "", "")
        return CommandResult(1, "", "unknown")

    discovery = GameLoopDiscovery(config_manager=config_manager, registry_reader=lambda: ("", ""))
    engine = OptimizationEngine(
        backup_manager=backup_manager,
        audit_logger=audit_logger,
        gameloop_discovery=discovery,
        command_runner=fake_powercfg,
    )

    res = engine.apply_tweak("power_plan_high_perf")
    assert res.success is True
    assert state["active"] == high_guid

    ok_rb, _ = engine.rollback_tweak("power_plan_high_perf")
    assert ok_rb is True
    assert state["active"] == balanced_guid
