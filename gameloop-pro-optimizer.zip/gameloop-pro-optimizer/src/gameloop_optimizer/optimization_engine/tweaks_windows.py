"""Documented, safe, reversible Windows gaming tweaks (zero security weakening)."""

from __future__ import annotations

import re
from typing import Callable, Sequence

from gameloop_optimizer.app_core.models import TweakActionResult, TweakState
from gameloop_optimizer.app_core.permissions import is_admin
from gameloop_optimizer.app_core.process_runner import CommandResult, run_command
from gameloop_optimizer.backup_restore.manager import BackupManager
from gameloop_optimizer.backup_restore.registry_io import REG_DWORD, RegistryBackend
from gameloop_optimizer.logging.audit import AuditLogger
from gameloop_optimizer.optimization_engine.tweaks_base import BaseTweak

_HIGH_PERF_GUID = "8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c"
_GUID_RE = re.compile(r"([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})")


class WindowsGameModeTweak(BaseTweak):
    tweak_id = "windows_game_mode"
    name = "Windows Game Mode"
    category = "safe"
    risk_level = "low"
    requires_admin = False
    description = "Enables native Windows Game Mode (HKCU) to reduce background scheduling interference."
    proposed_display = "Enabled (1)"

    _ROOT = "HKCU"
    _SUBKEY = r"Software\Microsoft\GameBar"
    _VALUE = "AutoGameModeEnabled"

    def __init__(self, registry: RegistryBackend) -> None:
        self._reg = registry

    def read_state(self) -> TweakState:
        snap = self._reg.read_value(self._ROOT, self._SUBKEY, self._VALUE)
        enabled = snap.existed and snap.value == 1
        label = "Enabled (1)" if enabled else (f"Disabled ({snap.value})" if snap.existed else "Default / Not Set")
        return TweakState(current_value=label, available=True, is_optimized=enabled)

    def apply(self, backup_manager: BackupManager, audit_logger: AuditLogger) -> TweakActionResult:
        before_snap = self._reg.read_value(self._ROOT, self._SUBKEY, self._VALUE)
        record = backup_manager.create_backup(
            category="tweak",
            description=f"Backup before {self.tweak_id}",
            registry_snapshots=[before_snap],
        )
        ok, msg = self._reg.write_value(self._ROOT, self._SUBKEY, self._VALUE, 1, REG_DWORD)
        if not ok:
            audit_logger.record("tweak_apply", self.tweak_id, before_snap.value, 1, record.backup_id, False, msg)
            return TweakActionResult(self.tweak_id, False, msg, verified=False, backup_id=record.backup_id)

        after_snap = self._reg.read_value(self._ROOT, self._SUBKEY, self._VALUE)
        verified = after_snap.existed and after_snap.value == 1
        audit_logger.record(
            "tweak_apply", self.tweak_id, before_snap.value, after_snap.value, record.backup_id, verified
        )
        return TweakActionResult(
            tweak_id=self.tweak_id,
            success=verified,
            message="Windows Game Mode enabled and verified." if verified else "Applied but verification failed.",
            verified=verified,
            backup_id=record.backup_id,
            before_value=before_snap.value,
            after_value=after_snap.value,
        )


class DisableGameDvrTweak(BaseTweak):
    tweak_id = "disable_game_dvr"
    name = "Disable Background Game DVR Capture"
    category = "safe"
    risk_level = "low"
    requires_admin = False
    description = "Turns off background Xbox Game Bar recording (HKCU) to avoid constant GPU encoding overhead."
    proposed_display = "Background Capture Disabled (0)"

    _TARGETS = (
        ("HKCU", r"System\GameConfigStore", "GameDVR_Enabled", 0),
        ("HKCU", r"Software\Microsoft\Windows\CurrentVersion\GameDVR", "AppCaptureEnabled", 0),
    )

    def __init__(self, registry: RegistryBackend) -> None:
        self._reg = registry

    def read_state(self) -> TweakState:
        snaps = [self._reg.read_value(r, s, n) for r, s, n, _ in self._TARGETS]
        disabled = all(s.existed and s.value == 0 for s in snaps)
        summary = ", ".join(f"{s.name}={s.value if s.existed else 'unset'}" for s in snaps)
        return TweakState(current_value=summary, available=True, is_optimized=disabled)

    def apply(self, backup_manager: BackupManager, audit_logger: AuditLogger) -> TweakActionResult:
        before_snaps = [self._reg.read_value(r, s, n) for r, s, n, _ in self._TARGETS]
        record = backup_manager.create_backup(
            category="tweak",
            description=f"Backup before {self.tweak_id}",
            registry_snapshots=before_snaps,
        )
        for root, subkey, name, val in self._TARGETS:
            ok, msg = self._reg.write_value(root, subkey, name, val, REG_DWORD)
            if not ok:
                audit_logger.record("tweak_apply", self.tweak_id, None, None, record.backup_id, False, msg)
                return TweakActionResult(self.tweak_id, False, msg, backup_id=record.backup_id)

        after_snaps = [self._reg.read_value(r, s, n) for r, s, n, _ in self._TARGETS]
        verified = all(s.existed and s.value == 0 for s in after_snaps)
        audit_logger.record(
            "tweak_apply",
            self.tweak_id,
            {s.name: s.value for s in before_snaps},
            {s.name: s.value for s in after_snaps},
            record.backup_id,
            verified,
        )
        return TweakActionResult(
            tweak_id=self.tweak_id,
            success=verified,
            message="Background Game DVR disabled and verified." if verified else "Verification failed.",
            verified=verified,
            backup_id=record.backup_id,
        )


class HighPerformancePowerPlanTweak(BaseTweak):
    tweak_id = "power_plan_high_perf"
    name = "High Performance Windows Power Plan"
    category = "safe"
    risk_level = "low"
    requires_admin = False
    description = "Switches active power scheme to High Performance (only if exposed by Windows) to reduce CPU frequency drops."
    proposed_display = f"High Performance ({_HIGH_PERF_GUID})"

    def __init__(
        self,
        command_runner: Callable[[Sequence[str], float], CommandResult] | None = None,
    ) -> None:
        self._runner = command_runner or (lambda args, timeout=8.0: run_command(args, timeout=timeout))

    def _get_active_guid(self) -> tuple[str | None, str]:
        res = self._runner(["powercfg", "/getactivescheme"], 6.0)
        if not res.ok:
            return None, res.stderr or "powercfg unavailable."
        match = _GUID_RE.search(res.stdout)
        return (match.group(1).lower(), res.stdout) if match else (None, res.stdout)

    def _has_high_perf_plan(self) -> bool:
        res = self._runner(["powercfg", "/list"], 6.0)
        return res.ok and (_HIGH_PERF_GUID in res.stdout.lower())

    def read_state(self) -> TweakState:
        active_guid, raw = self._get_active_guid()
        if not active_guid:
            return TweakState(current_value="Unavailable", available=False, reason=raw)
        if not self._has_high_perf_plan():
            return TweakState(
                current_value=active_guid,
                available=False,
                reason="High Performance power plan is not exposed on this Windows device (e.g., Modern Standby).",
            )
        return TweakState(
            current_value=raw,
            available=True,
            is_optimized=(active_guid == _HIGH_PERF_GUID),
            raw_snapshot={"previous_guid": active_guid},
        )

    def apply(self, backup_manager: BackupManager, audit_logger: AuditLogger) -> TweakActionResult:
        state = self.read_state()
        if not state.available:
            return TweakActionResult(self.tweak_id, False, state.reason)

        prev_guid = state.raw_snapshot.get("previous_guid", "")
        record = backup_manager.create_backup(
            category="tweak",
            description=f"Backup before {self.tweak_id}",
            custom_items=[{"item_type": "power_plan", "data": {"guid": prev_guid}}],
        )
        res = self._runner(["powercfg", "/setactive", _HIGH_PERF_GUID], 6.0)
        if not res.ok:
            msg = res.stderr or "Failed to activate High Performance plan."
            audit_logger.record("tweak_apply", self.tweak_id, prev_guid, _HIGH_PERF_GUID, record.backup_id, False, msg)
            return TweakActionResult(self.tweak_id, False, msg, backup_id=record.backup_id)

        after_guid, _ = self._get_active_guid()
        verified = after_guid == _HIGH_PERF_GUID
        audit_logger.record("tweak_apply", self.tweak_id, prev_guid, after_guid, record.backup_id, verified)
        return TweakActionResult(
            tweak_id=self.tweak_id,
            success=verified,
            message="High Performance power plan active." if verified else "Power plan change could not be verified.",
            verified=verified,
            backup_id=record.backup_id,
            before_value=prev_guid,
            after_value=after_guid,
        )

    def restore_power_plan(self, data: dict) -> tuple[bool, str]:
        guid = str(data.get("guid", "")).strip()
        if not _GUID_RE.fullmatch(guid):
            return False, "Invalid power plan GUID in backup."
        res = self._runner(["powercfg", "/setactive", guid], 6.0)
        return res.ok, f"Restored power plan {guid}" if res.ok else (res.stderr or "powercfg restore failed.")


class HardwareGpuSchedulingTweak(BaseTweak):
    tweak_id = "windows_hags"
    name = "Hardware-Accelerated GPU Scheduling (HAGS)"
    category = "advanced"
    risk_level = "medium"
    requires_admin = True
    description = "Enables Windows HAGS (HKLM, requires Administrator & system restart). Test stability after enabling."
    proposed_display = "Enabled (HwSchMode=2, reboot required)"

    _ROOT = "HKLM"
    _SUBKEY = r"SYSTEM\CurrentControlSet\Control\GraphicsDrivers"
    _VALUE = "HwSchMode"

    def __init__(
        self,
        registry: RegistryBackend,
        admin_checker: Callable[[], bool] | None = None,
    ) -> None:
        self._reg = registry
        self._is_admin = admin_checker or is_admin

    def read_state(self) -> TweakState:
        snap = self._reg.read_value(self._ROOT, self._SUBKEY, self._VALUE)
        if not snap.existed:
            return TweakState(
                current_value="Unsupported",
                available=False,
                reason="HwSchMode key not present (GPU driver or Windows version may not support HAGS).",
            )
        if not self._is_admin():
            return TweakState(
                current_value=f"HwSchMode={snap.value}",
                available=False,
                is_optimized=(snap.value == 2),
                reason="Administrator privileges required to change HKLM graphics scheduling.",
            )
        return TweakState(
            current_value=f"HwSchMode={snap.value} ({'On' if snap.value == 2 else 'Off'})",
            available=True,
            is_optimized=(snap.value == 2),
        )

    def apply(self, backup_manager: BackupManager, audit_logger: AuditLogger) -> TweakActionResult:
        state = self.read_state()
        if not state.available:
            return TweakActionResult(self.tweak_id, False, state.reason)

        before_snap = self._reg.read_value(self._ROOT, self._SUBKEY, self._VALUE)
        record = backup_manager.create_backup(
            category="tweak",
            description=f"Backup before {self.tweak_id}",
            registry_snapshots=[before_snap],
        )
        ok, msg = self._reg.write_value(self._ROOT, self._SUBKEY, self._VALUE, 2, REG_DWORD)
        if not ok:
            audit_logger.record("tweak_apply", self.tweak_id, before_snap.value, 2, record.backup_id, False, msg)
            return TweakActionResult(self.tweak_id, False, msg, backup_id=record.backup_id)

        after_snap = self._reg.read_value(self._ROOT, self._SUBKEY, self._VALUE)
        verified = after_snap.existed and after_snap.value == 2
        audit_logger.record(
            "tweak_apply", self.tweak_id, before_snap.value, after_snap.value, record.backup_id, verified
        )
        return TweakActionResult(
            tweak_id=self.tweak_id,
            success=verified,
            message="HAGS enabled (restart Windows for effect)." if verified else "Verification failed.",
            verified=verified,
            backup_id=record.backup_id,
            before_value=before_snap.value,
            after_value=after_snap.value,
        )
