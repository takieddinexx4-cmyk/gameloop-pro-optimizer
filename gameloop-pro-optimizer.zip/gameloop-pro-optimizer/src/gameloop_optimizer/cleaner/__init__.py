"""Preview-first, Recycle-Bin-only cleaner with strict user/SAV/INI protection."""
