"""Live Monitor page: low-overhead background polling with 60s and 5m QPainter graphs."""

from __future__ import annotations

import threading

from PySide6.QtCore import QThread, Signal
from PySide6.QtWidgets import QGridLayout, QHBoxLayout, QPushButton

from gameloop_optimizer.app_core.models import MonitorSnapshot
from gameloop_optimizer.app_core.service_container import ServiceContainer
from gameloop_optimizer.ui.pages.base_page import BasePage
from gameloop_optimizer.ui.widgets.cards import MetricCard
from gameloop_optimizer.ui.widgets.chart_widget import RollingLineChart


class _MonitorLoopThread(QThread):
    sampled = Signal(object)

    def __init__(self, monitor, interval_ms: int) -> None:
        super().__init__()
        self._monitor = monitor
        self._interval_sec = max(0.5, interval_ms / 1000.0)
        self._stop_event = threading.Event()

    def stop(self) -> None:
        self._stop_event.set()

    def run(self) -> None:
        while not self._stop_event.is_set():
            snap = self._monitor.sample()
            self.sampled.emit(snap)
            self._stop_event.wait(self._interval_sec)


class LiveMonitorPage(BasePage):
    def __init__(self, services: ServiceContainer, parent=None) -> None:
        super().__init__(services, parent)
        self._thread: _MonitorLoopThread | None = None
        self._window_seconds = 60
        self._build_ui()

    def _build_ui(self) -> None:
        controls = QHBoxLayout()
        self.start_btn = QPushButton()
        self.start_btn.setObjectName("PrimaryButton")
        self.start_btn.clicked.connect(self._start_monitor)

        self.stop_btn = QPushButton()
        self.stop_btn.setObjectName("DangerButton")
        self.stop_btn.setEnabled(False)
        self.stop_btn.clicked.connect(self._stop_monitor)

        self.win60_btn = QPushButton()
        self.win60_btn.clicked.connect(lambda: self._set_window(60))
        self.win5m_btn = QPushButton()
        self.win5m_btn.clicked.connect(lambda: self._set_window(300))

        controls.addWidget(self.start_btn)
        controls.addWidget(self.stop_btn)
        controls.addStretch(1)
        controls.addWidget(self.win60_btn)
        controls.addWidget(self.win5m_btn)
        self.page_layout.addLayout(controls)

        grid = QGridLayout()
        grid.setSpacing(10)
        self.cpu_card = MetricCard("", "--")
        self.ram_card = MetricCard("", "--")
        self.gpu_card = MetricCard("", "--")
        self.temp_card = MetricCard("", "--")
        self.gl_card = MetricCard("", "--")
        self.ping_card = MetricCard("", "--")
        self.fps_card = MetricCard("", "--")

        grid.addWidget(self.cpu_card, 0, 0)
        grid.addWidget(self.ram_card, 0, 1)
        grid.addWidget(self.gpu_card, 0, 2)
        grid.addWidget(self.temp_card, 0, 3)
        grid.addWidget(self.gl_card, 1, 0, 1, 2)
        grid.addWidget(self.ping_card, 1, 2)
        grid.addWidget(self.fps_card, 1, 3)
        self.page_layout.addLayout(grid)

        self.cpu_chart = RollingLineChart("CPU %", "#00D4FF", max_points=60)
        self.ram_chart = RollingLineChart("RAM %", "#10B981", max_points=60)
        self.gpu_chart = RollingLineChart("GPU %", "#F59E0B", max_points=60)

        self.page_layout.addWidget(self.cpu_chart, 1)
        self.page_layout.addWidget(self.ram_chart, 1)
        self.page_layout.addWidget(self.gpu_chart, 1)

    def retranslate_ui(self) -> None:
        self.start_btn.setText(self.t("monitor.start"))
        self.stop_btn.setText(self.t("monitor.stop"))
        self.win60_btn.setText(self.t("monitor.window_60s"))
        self.win5m_btn.setText(self.t("monitor.window_5m"))
        self.cpu_card.title_label.setText(self.t("monitor.cpu"))
        self.ram_card.title_label.setText(self.t("monitor.ram"))
        self.gpu_card.title_label.setText(self.t("monitor.gpu"))
        self.temp_card.title_label.setText(self.t("monitor.temp"))
        self.gl_card.title_label.setText(self.t("monitor.gameloop"))
        self.ping_card.title_label.setText(self.t("monitor.ping"))
        self.fps_card.title_label.setText(self.t("monitor.fps"))
        self.cpu_chart.set_title(self.t("monitor.cpu"))
        self.ram_chart.set_title(self.t("monitor.ram"))
        self.gpu_chart.set_title(self.t("monitor.gpu"))

    def _set_window(self, seconds: int) -> None:
        self._window_seconds = seconds
        interval_s = max(0.5, self.services.config_manager.config.monitor_interval_ms / 1000.0)
        pts = max(15, int(seconds / interval_s))
        self.cpu_chart.set_window_size(pts)
        self.ram_chart.set_window_size(pts)
        self.gpu_chart.set_window_size(pts)

    def _start_monitor(self) -> None:
        if self._thread and self._thread.isRunning():
            return
        interval_ms = self.services.config_manager.config.monitor_interval_ms
        self._set_window(self._window_seconds)
        self._thread = _MonitorLoopThread(self.services.performance_monitor, interval_ms)
        self._thread.sampled.connect(self._on_snapshot)
        self._thread.start()
        self.start_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)

    def _stop_monitor(self) -> None:
        if self._thread:
            self._thread.stop()
            self._thread.wait(2000)
            self._thread.deleteLater()
            self._thread = None
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)

    def _on_snapshot(self, snap: MonitorSnapshot) -> None:
        unavail = self.t("common.unavailable")
        self.cpu_card.update_metric(None, snap.cpu_percent.display(unavail))
        self.ram_card.update_metric(None, snap.ram_percent.display(unavail), snap.ram_used_gb.display(unavail))
        self.gpu_card.update_metric(
            None,
            snap.gpu_percent.display(unavail),
            "" if snap.gpu_percent.available else snap.gpu_percent.reason,
        )

        temp_val = f"{snap.cpu_temp_c.display(unavail)} / {snap.gpu_temp_c.display(unavail)}"
        temp_sub = "" if (snap.cpu_temp_c.available or snap.gpu_temp_c.available) else snap.cpu_temp_c.reason
        self.temp_card.update_metric(None, temp_val, temp_sub)

        if snap.gameloop_running:
            self.gl_card.update_metric(
                None,
                f"CPU {snap.gameloop_cpu_percent.display(unavail)} | RAM {snap.gameloop_ram_mb.display(unavail)}",
                "Running",
            )
        else:
            self.gl_card.update_metric(None, "Not Running", "")

        self.ping_card.update_metric(
            None,
            snap.ping_ms.display(unavail),
            "" if snap.ping_ms.available else snap.ping_ms.reason,
        )
        self.fps_card.update_metric(
            None,
            snap.fps.display(unavail),
            "" if snap.fps.available else snap.fps.reason,
        )

        self.cpu_chart.push_value(float(snap.cpu_percent.value) if snap.cpu_percent.available else None)
        self.ram_chart.push_value(float(snap.ram_percent.value) if snap.ram_percent.available else None)
        self.gpu_chart.push_value(float(snap.gpu_percent.value) if snap.gpu_percent.available else None)

    def shutdown(self) -> None:
        self._stop_monitor()
        super().shutdown()
