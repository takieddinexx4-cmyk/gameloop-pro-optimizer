"""Cleaner PRO page: mandatory preview, strict SAV/INI protection, Recycle Bin only."""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
)

from gameloop_optimizer.app_core.models import CleanerPreview, CleanerResult
from gameloop_optimizer.app_core.service_container import ServiceContainer
from gameloop_optimizer.ui.pages.base_page import BasePage
from gameloop_optimizer.ui.widgets.cards import GlassCard


def _fmt_bytes(size: int) -> str:
    if size >= 1024**2:
        return f"{size / (1024**2):.2f} MB"
    if size >= 1024:
        return f"{size / 1024:.1f} KB"
    return f"{size} B"


class CleanerPage(BasePage):
    def __init__(self, services: ServiceContainer, parent=None) -> None:
        super().__init__(services, parent)
        self._preview: CleanerPreview | None = None
        self._build_ui()

    def _build_ui(self) -> None:
        notice_card = GlassCard()
        self.notice_label = QLabel()
        self.notice_label.setWordWrap(True)
        self.notice_label.setStyleSheet("color: #6EE7B7; background: transparent;")
        notice_card.root_layout.addWidget(self.notice_label)

        self.summary_label = QLabel("Run Scan & Preview first to inspect eligible files.")
        self.summary_label.setObjectName("MutedLabel")
        notice_card.root_layout.addWidget(self.summary_label)
        self.page_layout.addWidget(notice_card)

        btn_row = QHBoxLayout()
        self.scan_btn = QPushButton()
        self.scan_btn.setObjectName("PrimaryButton")
        self.scan_btn.clicked.connect(self._scan_preview)

        self.clean_btn = QPushButton()
        self.clean_btn.setObjectName("DangerButton")
        self.clean_btn.setEnabled(False)
        self.clean_btn.clicked.connect(self._clean_selected)

        btn_row.addWidget(self.scan_btn)
        btn_row.addWidget(self.clean_btn)
        btn_row.addStretch(1)
        self.page_layout.addLayout(btn_row)

        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["Select", "File Path", "Size", "Category / Reason"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        self.page_layout.addWidget(self.table, 1)

    def retranslate_ui(self) -> None:
        self.notice_label.setText(self.t("cleaner.notice"))
        self.scan_btn.setText(self.t("cleaner.scan_preview"))
        self.clean_btn.setText(self.t("cleaner.clean_selected"))

    def _scan_preview(self) -> None:
        def on_done(preview: CleanerPreview) -> None:
            self._preview = preview
            self._render_preview()

        self.run_background_task(
            self.t("cleaner.scan_preview"), self.services.cleaner.scan_preview, on_done
        )

    def _render_preview(self) -> None:
        if not self._preview:
            return
        items = self._preview.items
        self.table.setRowCount(len(items))
        for row, item in enumerate(items):
            chk = QTableWidgetItem()
            chk.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsUserCheckable)
            chk.setCheckState(Qt.CheckState.Checked if item.selected else Qt.CheckState.Unchecked)
            self.table.setItem(row, 0, chk)
            self.table.setItem(row, 1, QTableWidgetItem(item.path))
            self.table.setItem(row, 2, QTableWidgetItem(_fmt_bytes(item.size_bytes)))
            self.table.setItem(row, 3, QTableWidgetItem(item.reason))

        notes = " | ".join(self._preview.scan_notes)
        self.summary_label.setText(
            f"Preview: {len(items)} eligible file(s) | Total: {_fmt_bytes(self._preview.total_size_bytes)} "
            f"| Protected files skipped: {self._preview.skipped_protected_count}"
            + (f" | {notes}" if notes else "")
        )
        self.clean_btn.setEnabled(len(items) > 0)

    def _clean_selected(self) -> None:
        if not self._preview:
            return
        for row, item in enumerate(self._preview.items):
            chk = self.table.item(row, 0)
            item.selected = bool(chk and chk.checkState() == Qt.CheckState.Checked)

        selected = [i for i in self._preview.items if i.selected]
        if not selected:
            QMessageBox.information(self, self.t("common.info"), "No files selected.")
            return

        total_sz = sum(i.size_bytes for i in selected)
        ans = QMessageBox.question(
            self,
            self.t("common.confirm"),
            f"Move {len(selected)} file(s) ({_fmt_bytes(total_sz)}) to the Windows Recycle Bin?",
        )
        if ans != QMessageBox.StandardButton.Yes:
            return

        def on_done(res: CleanerResult) -> None:
            msg = f"Moved {res.deleted_count} file(s) to Recycle Bin (freed {_fmt_bytes(res.freed_bytes)})."
            if res.failed_items:
                msg += f"\nSkipped/Failed: {len(res.failed_items)}"
            QMessageBox.information(self, self.t("common.success"), msg)
            self._scan_preview()

        self.run_background_task(
            self.t("cleaner.clean_selected"),
            self.services.cleaner.execute_clean,
            on_done,
            items=selected,
        )
