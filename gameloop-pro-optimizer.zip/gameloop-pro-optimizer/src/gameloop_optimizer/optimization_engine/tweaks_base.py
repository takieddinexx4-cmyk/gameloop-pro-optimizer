"""Abstract base contract for every system or GameLoop tweak."""

from __future__ import annotations

from abc import ABC, abstractmethod

from gameloop_optimizer.app_core.models import (
    TweakActionResult,
    TweakPreview,
    TweakState,
)
from gameloop_optimizer.backup_restore.manager import BackupManager
from gameloop_optimizer.logging.audit import AuditLogger


class BaseTweak(ABC):
    tweak_id: str = ""
    name: str = ""
    category: str = "safe"  # safe | advanced | pro
    risk_level: str = "low"  # low | medium
    requires_admin: bool = False
    description: str = ""
    proposed_display: str = ""

    @abstractmethod
    def read_state(self) -> TweakState:
        """Inspect real current system/GameLoop state."""

    @abstractmethod
    def apply(
        self,
        backup_manager: BackupManager,
        audit_logger: AuditLogger,
    ) -> TweakActionResult:
        """Backup original state, apply change, verify, and record audit log."""

    def preview(self) -> TweakPreview:
        state = self.read_state()
        return TweakPreview(
            tweak_id=self.tweak_id,
            name=self.name,
            category=self.category,
            risk_level=self.risk_level,
            requires_admin=self.requires_admin,
            current_display=str(state.current_value) if state.available else "Unavailable",
            proposed_display=self.proposed_display,
            description=self.description,
            available=state.available,
            unavailable_reason=state.reason,
        )
