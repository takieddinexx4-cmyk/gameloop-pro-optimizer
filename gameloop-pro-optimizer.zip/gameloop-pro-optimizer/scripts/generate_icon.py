"""Generate vector SVG source and matching multi-resolution ICO/PNG assets.

Note: Uses Pillow supersampled vector drawing instead of native Cairo DLLs
so builds on Windows GitHub Actions runners require zero external binaries.
"""

from __future__ import annotations

import math
from pathlib import Path
from PIL import Image, ImageDraw

SVG_CONTENT = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#0B1221"/>
      <stop offset="100%" stop-color="#132238"/>
    </linearGradient>
    <linearGradient id="accent" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#00D4FF"/>
      <stop offset="100%" stop-color="#10B981"/>
    </linearGradient>
  </defs>
  <rect x="12" y="12" width="232" height="232" rx="48" fill="url(#bg)" stroke="url(#accent)" stroke-width="8"/>
  <polygon points="128,36 208,74 196,172 128,220 60,172 48,74" fill="#101B2E" stroke="url(#accent)" stroke-width="8"/>
  <circle cx="128" cy="126" r="46" fill="none" stroke="#00D4FF" stroke-width="8"/>
  <line x1="128" y1="64" x2="128" y2="90" stroke="#10B981" stroke-width="8" stroke-linecap="round"/>
  <line x1="128" y1="162" x2="128" y2="188" stroke="#10B981" stroke-width="8" stroke-linecap="round"/>
  <line x1="66" y1="126" x2="92" y2="126" stroke="#10B981" stroke-width="8" stroke-linecap="round"/>
  <line x1="164" y1="126" x2="190" y2="126" stroke="#10B981" stroke-width="8" stroke-linecap="round"/>
  <polygon points="134,98 110,130 126,130 122,154 146,122 130,122" fill="#00D4FF"/>
</svg>
"""


def _render_icon_image(size: int = 512) -> Image.Image:
    """Render high-resolution anti-aliased emblem matching SVG_CONTENT."""
    s = size / 256.0
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    # Rounded dark navy background
    pad = int(12 * s)
    radius = int(48 * s)
    draw.rounded_rectangle(
        [pad, pad, size - pad, size - pad],
        radius=radius,
        fill=(14, 24, 42, 255),
        outline=(0, 212, 255, 255),
        width=max(2, int(8 * s)),
    )

    # Inner tactical shield polygon
    shield = [
        (128 * s, 36 * s),
        (208 * s, 74 * s),
        (196 * s, 172 * s),
        (128 * s, 220 * s),
        (60 * s, 172 * s),
        (48 * s, 74 * s),
    ]
    draw.polygon(shield, fill=(16, 27, 46, 255), outline=(16, 185, 129, 255))
    # Thicker polygon stroke
    stroke_w = max(2, int(7 * s))
    for i in range(len(shield)):
        p1 = shield[i]
        p2 = shield[(i + 1) % len(shield)]
        draw.line([p1, p2], fill=(16, 185, 129, 255), width=stroke_w)

    # Precision ring
    cx, cy, r = 128 * s, 126 * s, 46 * s
    draw.ellipse(
        [cx - r, cy - r, cx + r, cy + r],
        outline=(0, 212, 255, 255),
        width=max(2, int(8 * s)),
    )

    # Crosshair ticks
    tick_w = max(2, int(8 * s))
    ticks = [
        ((128 * s, 64 * s), (128 * s, 90 * s)),
        ((128 * s, 162 * s), (128 * s, 188 * s)),
        ((66 * s, 126 * s), (92 * s, 126 * s)),
        ((164 * s, 126 * s), (190 * s, 126 * s)),
    ]
    for start, end in ticks:
        draw.line([start, end], fill=(16, 185, 129, 255), width=tick_w)

    # Central lightning / performance bolt
    bolt = [
        (134 * s, 98 * s),
        (110 * s, 130 * s),
        (126 * s, 130 * s),
        (122 * s, 154 * s),
        (146 * s, 122 * s),
        (130 * s, 122 * s),
    ]
    draw.polygon(bolt, fill=(0, 212, 255, 255))

    # Subtle outer corner highlights
    for angle_deg in (45, 135, 225, 315):
        rad = math.radians(angle_deg)
        px = cx + math.cos(rad) * (r + 12 * s)
        py = cy + math.sin(rad) * (r + 12 * s)
        dot_r = max(1, int(3 * s))
        draw.ellipse(
            [px - dot_r, py - dot_r, px + dot_r, py + dot_r],
            fill=(0, 212, 255, 180),
        )

    return img


def generate_assets(output_dir: Path) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    svg_path = output_dir / "app_icon.svg"
    png_path = output_dir / "app_icon.png"
    ico_path = output_dir / "app_icon.ico"

    svg_path.write_text(SVG_CONTENT, encoding="utf-8")

    hi_res = _render_icon_image(512)
    png_img = hi_res.resize((256, 256), Image.Resampling.LANCZOS)
    png_img.save(png_path, format="PNG")

    ico_sizes = [(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)]
    hi_res.save(ico_path, format="ICO", sizes=ico_sizes)
    print(f"[OK] Generated {svg_path}, {png_path}, {ico_path}")


if __name__ == "__main__":
    root = Path(__file__).resolve().parent.parent
    generate_assets(root / "assets")
