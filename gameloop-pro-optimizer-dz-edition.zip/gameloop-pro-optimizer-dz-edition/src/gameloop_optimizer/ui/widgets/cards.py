"""Liquid Glass cards, metric tiles, badges, and subtle elevation effects."""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QFrame,
    QGraphicsDropShadowEffect,
    QHBoxLayout,
    QLabel,
    QProgressBar,
    QVBoxLayout,
)


def apply_glass_shadow(
    widget: QFrame,
    blur_radius: int = 20,
    y_offset: int = 6,
    alpha: int = 90,
) -> None:
    """Attach a lightweight drop shadow selectively to hero/key panels (never every small item)."""
    effect = QGraphicsDropShadowEffect(widget)
    effect.setBlurRadius(blur_radius)
    effect.setOffset(0, y_offset)
    effect.setColor(QColor(0, 6, 18, alpha))
    widget.setGraphicsEffect(effect)


class GlassCard(QFrame):
    def __init__(
        self,
        parent=None,
        accent: str | None = None,
        elevated: bool = False,
        hero: bool = False,
    ) -> None:
        super().__init__(parent)
        self.setObjectName("HeroGlassCard" if hero else "GlassCard")
        if accent:
            self.setProperty("accent", accent)
        self.root_layout = QVBoxLayout(self)
        self.root_layout.setContentsMargins(16, 14, 16, 14)
        self.root_layout.setSpacing(8)
        if elevated or hero:
            apply_glass_shadow(self, blur_radius=24 if hero else 18, y_offset=6, alpha=95)


class StatusBadge(QLabel):
    _STYLES = {
        "ok": ("rgba(16, 185, 129, 0.18)", "#34D399", "rgba(16, 185, 129, 0.45)"),
        "info": ("rgba(0, 180, 255, 0.16)", "#38BDF8", "rgba(0, 229, 255, 0.40)"),
        "warning": ("rgba(245, 158, 11, 0.18)", "#FBBF24", "rgba(245, 158, 11, 0.45)"),
        "high": ("rgba(249, 115, 22, 0.20)", "#FB923C", "rgba(249, 115, 22, 0.48)"),
        "critical": ("rgba(239, 68, 68, 0.20)", "#F87171", "rgba(239, 68, 68, 0.48)"),
        "muted": ("rgba(148, 163, 184, 0.14)", "#94A3B8", "rgba(148, 163, 184, 0.30)"),
        "cyan": ("rgba(0, 229, 255, 0.18)", "#00E5FF", "rgba(0, 229, 255, 0.50)"),
    }

    def __init__(self, text: str = "", level: str = "info", parent=None) -> None:
        super().__init__(text, parent)
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.set_level(level)

    def set_level(self, level: str) -> None:
        bg, fg, border = self._STYLES.get(level, self._STYLES["info"])
        self.setStyleSheet(
            f"background-color: {bg}; color: {fg}; border: 1px solid {border};"
            "border-radius: 10px; padding: 3px 10px; font-weight: 700; font-size: 11px;"
        )


class MetricCard(GlassCard):
    def __init__(
        self,
        title: str,
        value: str = "--",
        subtitle: str = "",
        parent=None,
        accent: str | None = None,
        show_bar: bool = False,
        elevated: bool = False,
    ) -> None:
        super().__init__(parent=parent, accent=accent, elevated=elevated)
        header_row = QHBoxLayout()
        header_row.setSpacing(6)
        self.title_label = QLabel(title)
        self.title_label.setObjectName("MutedLabel")
        header_row.addWidget(self.title_label, 1)

        self.badge = StatusBadge("", "info")
        self.badge.setVisible(False)
        header_row.addWidget(self.badge)
        self.root_layout.addLayout(header_row)

        self.value_label = QLabel(value)
        self.value_label.setObjectName("MetricValue")
        self.value_label.setWordWrap(True)

        self.subtitle_label = QLabel(subtitle)
        self.subtitle_label.setObjectName("MutedLabel")
        self.subtitle_label.setWordWrap(True)

        self.root_layout.addWidget(self.value_label)
        self.root_layout.addWidget(self.subtitle_label)

        self.progress_bar: QProgressBar | None = None
        if show_bar:
            self.progress_bar = QProgressBar()
            self.progress_bar.setRange(0, 100)
            self.progress_bar.setValue(0)
            self.progress_bar.setTextVisible(False)
            self.progress_bar.setFixedHeight(7)
            self.root_layout.addWidget(self.progress_bar)

    def update_metric(
        self,
        title: str | None,
        value: str,
        subtitle: str = "",
        badge_text: str | None = None,
        badge_level: str = "info",
        bar_percent: int | None = None,
    ) -> None:
        if title is not None:
            self.title_label.setText(title)
        self.value_label.setText(value)
        self.subtitle_label.setText(subtitle)
        if badge_text is not None:
            self.badge.setText(badge_text)
            self.badge.set_level(badge_level)
            self.badge.setVisible(bool(badge_text))
        if self.progress_bar is not None and bar_percent is not None:
            self.progress_bar.setValue(max(0, min(100, int(bar_percent))))


class SectionHeader(QFrame):
    def __init__(self, title: str, subtitle: str = "", parent=None) -> None:
        super().__init__(parent)
        self.setStyleSheet("background: transparent; border: none;")
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 4, 0, 4)

        col = QVBoxLayout()
        col.setSpacing(2)
        self.title_label = QLabel(title)
        self.title_label.setObjectName("SectionTitle")
        self.subtitle_label = QLabel(subtitle)
        self.subtitle_label.setObjectName("MutedLabel")
        self.subtitle_label.setVisible(bool(subtitle))

        col.addWidget(self.title_label)
        col.addWidget(self.subtitle_label)
        layout.addLayout(col, 1)
        self.actions_layout = QHBoxLayout()
        self.actions_layout.setSpacing(8)
        layout.addLayout(self.actions_layout)
