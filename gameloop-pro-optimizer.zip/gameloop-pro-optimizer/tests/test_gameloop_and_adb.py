"""Tests for missing GameLoop, non-standard install paths, and ADB failure/repair."""

from __future__ import annotations

from pathlib import Path
import psutil
import pytest

from gameloop_optimizer.adb_manager.manager import AdbManager
from gameloop_optimizer.app_core.config import ConfigManager
from gameloop_optimizer.app_core.process_runner import CommandResult
from gameloop_optimizer.gameloop_manager.controller import GameLoopController
from gameloop_optimizer.gameloop_manager.discovery import GameLoopDiscovery


def test_gameloop_not_installed(
    config_manager: ConfigManager, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(psutil, "process_iter", lambda *a, **kw: [])
    monkeypatch.setattr(psutil, "disk_partitions", lambda *a, **kw: [])

    discovery = GameLoopDiscovery(
        config_manager=config_manager,
        registry_reader=lambda: ("", ""),
        extra_search_roots=[],
    )
    info = discovery.discover()
    assert info.installed is False
    assert info.install_dir == ""

    ctrl = GameLoopController(discovery)
    ok, msg = ctrl.start_gameloop()
    assert ok is False
    assert "not found" in msg.lower()


def test_gameloop_non_standard_custom_path(
    tmp_path: Path, config_manager: ConfigManager, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(psutil, "process_iter", lambda *a, **kw: [])
    monkeypatch.setattr(psutil, "disk_partitions", lambda *a, **kw: [])

    custom_root = tmp_path / "CustomGamesDrive" / "MyGameLoop"
    ui_dir = custom_root / "ui"
    log_dir = ui_dir / "log"
    log_dir.mkdir(parents=True)
    emu = ui_dir / "AndroidEmulatorEx.exe"
    adb = ui_dir / "adb.exe"
    emu.write_bytes(b"fake-emu")
    adb.write_bytes(b"fake-adb")

    config_manager.config.custom_gameloop_path = str(custom_root)
    config_manager.save()

    discovery = GameLoopDiscovery(
        config_manager=config_manager,
        registry_reader=lambda: ("", ""),
    )
    info = discovery.discover()

    assert info.installed is True
    assert info.detection_source == "user_custom_path"
    assert Path(info.emulator_exe) == emu
    assert Path(info.adb_exe) == adb
    assert str(log_dir) in info.logs_dirs


def test_adb_disconnected_invalid_endpoint_and_repair(
    tmp_path: Path, config_manager: ConfigManager, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(psutil, "process_iter", lambda *a, **kw: [])
    monkeypatch.setattr(psutil, "disk_partitions", lambda *a, **kw: [])

    gl_root = tmp_path / "GL"
    (gl_root / "ui").mkdir(parents=True)
    (gl_root / "ui" / "AndroidEmulatorEx.exe").write_bytes(b"emu")
    (gl_root / "ui" / "adb.exe").write_bytes(b"adb")
    config_manager.config.custom_gameloop_path = str(gl_root)

    discovery = GameLoopDiscovery(
        config_manager=config_manager,
        registry_reader=lambda: ("", ""),
    )

    # First simulate disconnected / offline state
    calls: list[list[str]] = []
    repaired = {"done": False}

    def fake_runner(args, timeout=10.0) -> CommandResult:
        cmd = list(args)
        calls.append(cmd)
        sub = cmd[1] if len(cmd) > 1 else ""
        if sub == "devices":
            if not repaired["done"]:
                return CommandResult(0, "List of devices attached\n127.0.0.1:5555\toffline", "")
            return CommandResult(0, "List of devices attached\n127.0.0.1:5555\tdevice", "")
        if sub == "kill-server":
            return CommandResult(0, "", "")
        if sub == "start-server":
            repaired["done"] = True
            return CommandResult(0, "* daemon started successfully", "")
        if sub == "connect":
            return CommandResult(0, "connected to 127.0.0.1:5555", "")
        return CommandResult(0, "", "")

    adb = AdbManager(discovery=discovery, command_runner=fake_runner)
    st = adb.get_status()
    assert st.adb_available is True
    assert len(st.devices) == 1
    assert st.devices[0].state == "offline"

    # Reject shell injection attempt in endpoint
    ok_bad, msg_bad = adb.connect("127.0.0.1:5555 && calc.exe")
    assert ok_bad is False
    assert "invalid" in msg_bad.lower()

    # Repair sequence succeeds
    ok_rep, msg_rep = adb.repair()
    assert ok_rep is True
    assert "127.0.0.1:5555" in msg_rep
    assert any("kill-server" in c for c in calls)
    assert any("start-server" in c for c in calls)
