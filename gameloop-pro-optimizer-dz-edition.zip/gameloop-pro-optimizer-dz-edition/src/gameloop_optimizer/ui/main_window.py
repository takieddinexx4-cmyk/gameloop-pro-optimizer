"""Main application window with collapsible Liquid Glass sidebar, smooth transitions, and RTL/LTR."""

from __future__ import annotations

from PySide6.QtCore import QEasingCurve, QParallelAnimationGroup, QPropertyAnimation, Qt
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (
    QApplication,
    QFrame,
    QGraphicsOpacityEffect,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)

from gameloop_optimizer.app_core.constants import (
    APP_EDITION,
    APP_NAME,
    APP_SHORT_NAME,
    APP_VERSION,
)
from gameloop_optimizer.app_core.paths import get_assets_dir
from gameloop_optimizer.app_core.permissions import is_admin, request_elevation
from gameloop_optimizer.app_core.service_container import ServiceContainer
from gameloop_optimizer.ui.pages.about_page import AboutPage
from gameloop_optimizer.ui.pages.backup_restore_page import BackupRestorePage
from gameloop_optimizer.ui.pages.base_page import BasePage
from gameloop_optimizer.ui.pages.cleaner_page import CleanerPage
from gameloop_optimizer.ui.pages.crash_lag_page import CrashLagPage
from gameloop_optimizer.ui.pages.dashboard_page import DashboardPage
from gameloop_optimizer.ui.pages.dependencies_page import DependenciesPage
from gameloop_optimizer.ui.pages.gameloop_center_page import GameLoopCenterPage
from gameloop_optimizer.ui.pages.gaming_tools_page import GamingToolsPage
from gameloop_optimizer.ui.pages.live_monitor_page import LiveMonitorPage
from gameloop_optimizer.ui.pages.optimization_page import OptimizationPage
from gameloop_optimizer.ui.pages.pc_analysis_page import PcAnalysisPage
from gameloop_optimizer.ui.pages.process_manager_page import ProcessManagerPage
from gameloop_optimizer.ui.pages.profiles_page import ProfilesPage
from gameloop_optimizer.ui.pages.settings_page import SettingsPage
from gameloop_optimizer.ui.widgets.cards import StatusBadge
from gameloop_optimizer.ui.widgets.operations_panel import OperationsCenterDialog


class MainWindow(QMainWindow):
    _SIDEBAR_EXPANDED = 252
    _SIDEBAR_COLLAPSED = 74

    def __init__(self, services: ServiceContainer) -> None:
        super().__init__()
        self.services = services
        self._nav_buttons: dict[str, QPushButton] = {}
        self._nav_group_labels: list[tuple[QLabel, str]] = []
        self._pages: dict[str, BasePage] = {}
        self._nav_specs: list[tuple[str, str, str, str | None]] = []
        self._current_page_key = ""
        self._sidebar_collapsed = False
        self._sidebar_anim: QParallelAnimationGroup | None = None
        self._page_anim: QPropertyAnimation | None = None

        self.setWindowTitle(f"{APP_NAME} v{APP_VERSION}")
        self.resize(1340, 840)
        self.setMinimumSize(1040, 680)

        self._build_ui()
        self.services.translator.subscribe(self._on_language_changed)
        self._retranslate_all()
        self.navigate_to("dashboard", animate=False)

    def _build_ui(self) -> None:
        central = QWidget(self)
        self.setCentralWidget(central)
        root = QHBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # === Collapsible Liquid Glass Sidebar ===
        self.sidebar = QFrame()
        self.sidebar.setObjectName("Sidebar")
        self.sidebar.setMinimumWidth(self._SIDEBAR_EXPANDED)
        self.sidebar.setMaximumWidth(self._SIDEBAR_EXPANDED)
        sb_layout = QVBoxLayout(self.sidebar)
        sb_layout.setContentsMargins(12, 14, 12, 14)
        sb_layout.setSpacing(8)

        # Brand header row (DZ emblem + title + collapse toggle)
        brand_row = QHBoxLayout()
        brand_row.setSpacing(8)

        self.brand_logo_lbl = QLabel()
        self.brand_logo_lbl.setStyleSheet("background: transparent;")
        logo_path = get_assets_dir() / "dz_logo_small.png"
        if not logo_path.exists():
            logo_path = get_assets_dir() / "app_icon.png"
        if logo_path.exists():
            self.brand_logo_lbl.setPixmap(
                QPixmap(str(logo_path)).scaled(
                    36,
                    36,
                    Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation,
                )
            )
        else:
            self.brand_logo_lbl.setText("DZ")
            self.brand_logo_lbl.setObjectName("EditionBadge")
        brand_row.addWidget(self.brand_logo_lbl)

        self.brand_text_col = QWidget()
        self.brand_text_col.setStyleSheet("background: transparent;")
        bt_layout = QVBoxLayout(self.brand_text_col)
        bt_layout.setContentsMargins(0, 0, 0, 0)
        bt_layout.setSpacing(2)

        brand_title = QLabel(APP_SHORT_NAME)
        brand_title.setObjectName("AppBrand")
        brand_title.setWordWrap(True)
        bt_layout.addWidget(brand_title)

        edition_lbl = QLabel(f"{APP_EDITION}  v{APP_VERSION}")
        edition_lbl.setObjectName("EditionBadge")
        bt_layout.addWidget(edition_lbl, 0, Qt.AlignmentFlag.AlignLeft)
        brand_row.addWidget(self.brand_text_col, 1)

        self.collapse_btn = QPushButton("☰")
        self.collapse_btn.setObjectName("IconGhostButton")
        self.collapse_btn.setFixedSize(32, 32)
        self.collapse_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.collapse_btn.clicked.connect(self._toggle_sidebar)
        brand_row.addWidget(self.collapse_btn)

        sb_layout.addLayout(brand_row)

        nav_scroll = QScrollArea()
        nav_scroll.setWidgetResizable(True)
        nav_container = QWidget()
        nav_container.setStyleSheet("background: transparent;")
        nav_layout = QVBoxLayout(nav_container)
        nav_layout.setContentsMargins(0, 6, 0, 6)
        nav_layout.setSpacing(3)

        # (page_key, label_key, icon_glyph, optional_group_header_key)
        self._nav_specs = [
            ("dashboard", "nav.dashboard", "◈", "nav.group_core"),
            ("pc_analysis", "nav.pc_analysis", "⌬", None),
            ("optimization", "nav.smart_optimization", "⚡", None),
            ("gameloop_center", "nav.gameloop_center", "🎮", "nav.group_gaming"),
            ("profiles", "nav.pubg_profiles", "🎯", None),
            ("crash_lag", "nav.crash_lag_center", "🛡", None),
            ("live_monitor", "nav.live_monitor", "📈", None),
            ("gaming_tools", "nav.gaming_tools", "⚙", None),
            ("process_manager", "nav.process_manager", "▤", "nav.group_system"),
            ("cleaner", "nav.cleaner_pro", "✦", None),
            ("dependencies", "nav.dependencies", "⊞", None),
            ("backup_restore", "nav.backup_restore", "⛨", None),
            ("settings", "nav.settings", "☰", "nav.group_app"),
            ("about", "nav.about", "ⓘ", None),
        ]

        for key, _label_key, _icon, group_key in self._nav_specs:
            if group_key:
                grp = QLabel()
                grp.setObjectName("NavGroupLabel")
                self._nav_group_labels.append((grp, group_key))
                nav_layout.addWidget(grp)

            btn = QPushButton()
            btn.setObjectName("NavButton")
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.clicked.connect(lambda _checked=False, k=key: self.navigate_to(k))
            self._nav_buttons[key] = btn
            nav_layout.addWidget(btn)

        nav_layout.addStretch(1)
        nav_scroll.setWidget(nav_container)
        sb_layout.addWidget(nav_scroll, 1)

        root.addWidget(self.sidebar)

        # === Main Content Column ===
        content_col = QVBoxLayout()
        content_col.setContentsMargins(0, 0, 0, 0)
        content_col.setSpacing(0)

        top_bar = QFrame()
        top_bar.setObjectName("TopBar")
        top_bar.setFixedHeight(60)
        tb_layout = QHBoxLayout(top_bar)
        tb_layout.setContentsMargins(20, 8, 20, 8)
        tb_layout.setSpacing(10)

        self.page_title_label = QLabel()
        self.page_title_label.setObjectName("PageTitle")
        tb_layout.addWidget(self.page_title_label)
        tb_layout.addStretch(1)

        self.ops_btn = QPushButton()
        self.ops_btn.setObjectName("IconGhostButton")
        self.ops_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.ops_btn.clicked.connect(self._open_operations_center)
        tb_layout.addWidget(self.ops_btn)

        self.admin_badge = StatusBadge()
        tb_layout.addWidget(self.admin_badge)

        self.elevate_btn = QPushButton()
        self.elevate_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.elevate_btn.clicked.connect(self._on_request_elevation)
        self.elevate_btn.setVisible(not is_admin())
        tb_layout.addWidget(self.elevate_btn)

        self.lang_btn = QPushButton()
        self.lang_btn.setObjectName("IconGhostButton")
        self.lang_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.lang_btn.clicked.connect(self._toggle_language)
        tb_layout.addWidget(self.lang_btn)

        content_col.addWidget(top_bar)

        self.stack = QStackedWidget()
        page_instances: dict[str, BasePage] = {
            "dashboard": DashboardPage(self.services, navigate_cb=self.navigate_to),
            "pc_analysis": PcAnalysisPage(self.services),
            "optimization": OptimizationPage(self.services),
            "gameloop_center": GameLoopCenterPage(self.services),
            "profiles": ProfilesPage(self.services),
            "crash_lag": CrashLagPage(self.services),
            "live_monitor": LiveMonitorPage(self.services),
            "gaming_tools": GamingToolsPage(self.services),
            "dependencies": DependenciesPage(self.services),
            "process_manager": ProcessManagerPage(self.services),
            "cleaner": CleanerPage(self.services),
            "backup_restore": BackupRestorePage(self.services),
            "settings": SettingsPage(self.services),
            "about": AboutPage(self.services),
        }

        for key, page in page_instances.items():
            self._pages[key] = page
            self.stack.addWidget(page)

        content_col.addWidget(self.stack, 1)
        root.addLayout(content_col, 1)

    def _toggle_sidebar(self) -> None:
        self._sidebar_collapsed = not self._sidebar_collapsed
        target = self._SIDEBAR_COLLAPSED if self._sidebar_collapsed else self._SIDEBAR_EXPANDED

        self.brand_text_col.setVisible(not self._sidebar_collapsed)
        for grp, _k in self._nav_group_labels:
            grp.setVisible(not self._sidebar_collapsed)
        self._update_nav_button_labels()

        anim_min = QPropertyAnimation(self.sidebar, b"minimumWidth", self)
        anim_min.setDuration(180)
        anim_min.setStartValue(self.sidebar.width())
        anim_min.setEndValue(target)
        anim_min.setEasingCurve(QEasingCurve.Type.OutCubic)

        anim_max = QPropertyAnimation(self.sidebar, b"maximumWidth", self)
        anim_max.setDuration(180)
        anim_max.setStartValue(self.sidebar.width())
        anim_max.setEndValue(target)
        anim_max.setEasingCurve(QEasingCurve.Type.OutCubic)

        group = QParallelAnimationGroup(self)
        group.addAnimation(anim_min)
        group.addAnimation(anim_max)
        self._sidebar_anim = group
        group.start()

    def navigate_to(self, page_key: str, animate: bool = True) -> None:
        if page_key not in self._pages:
            return
        prev_key = self._current_page_key
        if prev_key and prev_key != page_key and prev_key in self._pages:
            self._pages[prev_key].on_page_deactivated()

        self._current_page_key = page_key
        for key, btn in self._nav_buttons.items():
            btn.setProperty("active", key == page_key)
            btn.style().unpolish(btn)
            btn.style().polish(btn)

        page = self._pages[page_key]
        self.stack.setCurrentWidget(page)
        self._update_header_title()
        page.on_page_activated()

        if animate:
            self._animate_page_entrance(page)

    def _animate_page_entrance(self, page: QWidget) -> None:
        effect = QGraphicsOpacityEffect(page)
        page.setGraphicsEffect(effect)
        anim = QPropertyAnimation(effect, b"opacity", self)
        anim.setDuration(135)
        anim.setStartValue(0.68)
        anim.setEndValue(1.0)
        anim.setEasingCurve(QEasingCurve.Type.OutCubic)

        def _clear_effect() -> None:
            if page.graphicsEffect() is effect:
                page.setGraphicsEffect(None)

        anim.finished.connect(_clear_effect)
        self._page_anim = anim
        anim.start()

    def _open_operations_center(self) -> None:
        dlg = OperationsCenterDialog(self.services, parent=self)
        dlg.exec()

    def _update_header_title(self) -> None:
        key_map = {key: label_key for key, label_key, _icon, _grp in self._nav_specs}
        title_key = key_map.get(self._current_page_key, "nav.dashboard")
        self.page_title_label.setText(self.services.translator.t(title_key))

    def _update_nav_button_labels(self) -> None:
        tr = self.services.translator.t
        if self._sidebar_collapsed:
            align_css = "text-align: center; padding: 9px 4px;"
        else:
            align_css = "text-align: right;" if self.services.translator.is_rtl else "text-align: left;"

        for key, label_key, icon, _grp in self._nav_specs:
            btn = self._nav_buttons[key]
            text = tr(label_key)
            btn.setToolTip(text)
            btn.setText(icon if self._sidebar_collapsed else f" {icon}   {text}")
            btn.setStyleSheet(align_css)

    def _toggle_language(self) -> None:
        next_lang = "en" if self.services.translator.language == "ar" else "ar"
        self.services.config_manager.config.language = next_lang
        self.services.config_manager.save()
        self.services.translator.set_language(next_lang)

    def _on_language_changed(self, _lang: str) -> None:
        app = QApplication.instance()
        if app is not None:
            direction = (
                Qt.LayoutDirection.RightToLeft
                if self.services.translator.is_rtl
                else Qt.LayoutDirection.LeftToRight
            )
            app.setLayoutDirection(direction)
            self.setLayoutDirection(direction)
        self._retranslate_all()

    def _retranslate_all(self) -> None:
        tr = self.services.translator.t
        for grp, grp_key in self._nav_group_labels:
            grp.setText(tr(grp_key))
        self._update_nav_button_labels()

        self.ops_btn.setText(f"⚡ {tr('ops.button')}")

        if is_admin():
            self.admin_badge.setText(tr("topbar.admin_yes"))
            self.admin_badge.set_level("ok")
        else:
            self.admin_badge.setText(tr("topbar.admin_no"))
            self.admin_badge.set_level("warning")

        self.elevate_btn.setText(tr("topbar.run_as_admin"))
        self.lang_btn.setText("English" if self.services.translator.is_rtl else "العربية")
        self._update_header_title()

        for page in self._pages.values():
            page.retranslate_ui()

    def _on_request_elevation(self) -> None:
        tr = self.services.translator.t
        answer = QMessageBox.question(
            self,
            tr("topbar.run_as_admin"),
            tr("topbar.elevation_confirm"),
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        ok, msg = request_elevation()
        if ok:
            self.close()
        else:
            QMessageBox.information(self, tr("common.info"), msg)

    def closeEvent(self, event) -> None:  # noqa: N802 - Qt override
        for page in self._pages.values():
            page.shutdown()
        super().closeEvent(event)
