"""Commercial-grade Liquid Glass Dashboard with real telemetry, quick actions, and operations feed."""

from __future__ import annotations

from typing import Callable

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import (
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from gameloop_optimizer.app_core.models import AnalysisReport
from gameloop_optimizer.app_core.service_container import ServiceContainer
from gameloop_optimizer.ui.pages.base_page import BasePage
from gameloop_optimizer.ui.widgets.cards import GlassCard, MetricCard, SectionHeader, StatusBadge


class DashboardPage(BasePage):
    def __init__(
        self,
        services: ServiceContainer,
        navigate_cb: Callable[[str], None] | None = None,
        parent=None,
    ) -> None:
        super().__init__(services, parent)
        self._navigate_cb = navigate_cb
        self._live_timer = QTimer(self)
        self._live_timer.setInterval(2500)
        self._live_timer.timeout.connect(self._refresh_live_telemetry)
        self._build_ui()

    def _build_ui(self) -> None:
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        container = QWidget()
        container.setStyleSheet("background: transparent;")
        layout = QVBoxLayout(container)
        layout.setContentsMargins(0, 0, 4, 0)
        layout.setSpacing(14)

        # === Hero Status Banner ===
        hero = GlassCard(hero=True)
        hero_row = QHBoxLayout()
        hero_row.setSpacing(16)

        hero_left = QVBoxLayout()
        hero_left.setSpacing(6)
        self.hero_title = QLabel()
        self.hero_title.setObjectName("PageTitle")
        self.subtitle_label = QLabel()
        self.subtitle_label.setObjectName("MutedLabel")
        self.subtitle_label.setWordWrap(True)
        hero_left.addWidget(self.hero_title)
        hero_left.addWidget(self.subtitle_label)

        badges_row = QHBoxLayout()
        badges_row.setSpacing(8)
        self.pc_status_badge = StatusBadge("--", "info")
        self.gl_status_badge = StatusBadge("--", "muted")
        self.emu_status_badge = StatusBadge("--", "muted")
        badges_row.addWidget(self.pc_status_badge)
        badges_row.addWidget(self.gl_status_badge)
        badges_row.addWidget(self.emu_status_badge)
        badges_row.addStretch(1)
        hero_left.addLayout(badges_row)
        hero_row.addLayout(hero_left, 1)

        score_panel = QFrame()
        score_panel.setObjectName("SubGlassPanel")
        score_col = QVBoxLayout(score_panel)
        score_col.setContentsMargins(18, 12, 18, 12)
        score_col.setSpacing(2)
        self.hero_score_title = QLabel()
        self.hero_score_title.setObjectName("MutedLabel")
        self.hero_score_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.hero_score_val = QLabel("--")
        self.hero_score_val.setObjectName("HeroMetricValue")
        self.hero_score_val.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.hero_readiness_lbl = QLabel("--")
        self.hero_readiness_lbl.setObjectName("MutedLabel")
        self.hero_readiness_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        score_col.addWidget(self.hero_score_title)
        score_col.addWidget(self.hero_score_val)
        score_col.addWidget(self.hero_readiness_lbl)
        hero_row.addWidget(score_panel)

        hero.root_layout.addLayout(hero_row)
        layout.addWidget(hero)

        # === Quick Access Bar (5 Core Actions) ===
        actions_card = GlassCard(accent="cyan")
        actions_row = QHBoxLayout()
        actions_row.setSpacing(10)

        self.scan_btn = QPushButton()
        self.scan_btn.setObjectName("PrimaryButton")
        self.scan_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.scan_btn.clicked.connect(self._run_quick_scan)

        self.opt_btn = QPushButton()
        self.opt_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.opt_btn.clicked.connect(lambda: self._go("optimization"))

        self.crash_btn = QPushButton()
        self.crash_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.crash_btn.clicked.connect(lambda: self._go("crash_lag"))

        self.gl_center_btn = QPushButton()
        self.gl_center_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.gl_center_btn.clicked.connect(lambda: self._go("gameloop_center"))

        self.proc_btn = QPushButton()
        self.proc_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.proc_btn.clicked.connect(lambda: self._go("process_manager"))

        for btn in (self.scan_btn, self.opt_btn, self.crash_btn, self.gl_center_btn, self.proc_btn):
            actions_row.addWidget(btn)
        actions_row.addStretch(1)
        actions_card.root_layout.addLayout(actions_row)
        layout.addWidget(actions_card)

        # === Live Telemetry & System Status Cards (2x4 Grid) ===
        grid = QGridLayout()
        grid.setSpacing(12)

        self.cpu_live_card = MetricCard("", "--", "", accent="cyan", show_bar=True)
        self.ram_live_card = MetricCard("", "--", "", accent="emerald", show_bar=True)
        self.gpu_live_card = MetricCard("", "--", "", accent="blue", show_bar=True)
        self.perf_card = MetricCard("", "--", "", accent="cyan")

        self.gameloop_card = MetricCard("", "--", "", accent="blue")
        self.readiness_card = MetricCard("", "--", "", accent="emerald")
        self.backups_card = MetricCard("", "0", "SHA-256", accent="emerald")
        self.alerts_card = MetricCard("", "--", "", accent="amber")

        grid.addWidget(self.cpu_live_card, 0, 0)
        grid.addWidget(self.ram_live_card, 0, 1)
        grid.addWidget(self.gpu_live_card, 0, 2)
        grid.addWidget(self.perf_card, 0, 3)

        grid.addWidget(self.gameloop_card, 1, 0)
        grid.addWidget(self.readiness_card, 1, 1)
        grid.addWidget(self.backups_card, 1, 2)
        grid.addWidget(self.alerts_card, 1, 3)
        layout.addLayout(grid)

        # === Dual Bottom Panels: Recent Operations + Recent Optimizations / Audit ===
        bottom_row = QHBoxLayout()
        bottom_row.setSpacing(12)

        ops_card = GlassCard()
        self.ops_header = SectionHeader("")
        ops_card.root_layout.addWidget(self.ops_header)
        self.ops_list = QListWidget()
        self.ops_list.setMinimumHeight(180)
        ops_card.root_layout.addWidget(self.ops_list, 1)

        audit_card = GlassCard()
        self.audit_header = SectionHeader("")
        audit_card.root_layout.addWidget(self.audit_header)
        self.audit_list = QListWidget()
        self.audit_list.setMinimumHeight(180)
        audit_card.root_layout.addWidget(self.audit_list, 1)

        bottom_row.addWidget(ops_card, 1)
        bottom_row.addWidget(audit_card, 1)
        layout.addLayout(bottom_row, 1)

        self.honesty_label = QLabel()
        self.honesty_label.setObjectName("MutedLabel")
        self.honesty_label.setWordWrap(True)
        layout.addWidget(self.honesty_label)

        scroll.setWidget(container)
        self.page_layout.addWidget(scroll, 1)

    def _go(self, page_key: str) -> None:
        if self._navigate_cb:
            self._navigate_cb(page_key)

    def on_page_activated(self) -> None:
        self._refresh_summary()
        self._refresh_live_telemetry()
        if not self._live_timer.isActive():
            self._live_timer.start()

    def on_page_deactivated(self) -> None:
        if self._live_timer.isActive():
            self._live_timer.stop()

    def shutdown(self) -> None:
        if self._live_timer.isActive():
            self._live_timer.stop()
        super().shutdown()

    def retranslate_ui(self) -> None:
        self.hero_title.setText(self.t("dashboard.hero_title"))
        self.subtitle_label.setText(self.t("dashboard.subtitle"))
        self.hero_score_title.setText(self.t("dashboard.card_score"))

        self.scan_btn.setText(self.t("dashboard.quick_scan"))
        self.opt_btn.setText(self.t("dashboard.quick_opt"))
        self.crash_btn.setText(self.t("dashboard.quick_crash"))
        self.gl_center_btn.setText(self.t("dashboard.quick_gameloop"))
        self.proc_btn.setText(self.t("dashboard.quick_process"))

        self.cpu_live_card.title_label.setText(self.t("monitor.cpu"))
        self.ram_live_card.title_label.setText(self.t("monitor.ram"))
        self.gpu_live_card.title_label.setText(self.t("monitor.gpu"))
        self.perf_card.title_label.setText(self.t("dashboard.card_perf"))
        self.gameloop_card.title_label.setText(self.t("dashboard.card_gameloop"))
        self.readiness_card.title_label.setText(self.t("dashboard.card_readiness"))
        self.backups_card.title_label.setText(self.t("dashboard.card_backups"))
        self.alerts_card.title_label.setText(self.t("dashboard.card_alerts"))

        self.ops_header.title_label.setText(self.t("dashboard.recent_ops"))
        self.audit_header.title_label.setText(self.t("dashboard.recent_audit"))
        self.honesty_label.setText(self.t("common.not_tested_hw"))
        self._refresh_summary()
        self._refresh_live_telemetry()

    def _refresh_live_telemetry(self) -> None:
        """Read lightweight real-time OS counters without fabricating unavailable sensors."""
        unavail = self.t("common.unavailable")
        try:
            snap = self.services.performance_monitor.sample()
        except Exception:  # noqa: BLE001
            return

        cpu_val = float(snap.cpu_percent.value) if snap.cpu_percent.available else 0.0
        self.cpu_live_card.update_metric(
            None,
            snap.cpu_percent.display(unavail),
            snap.cpu_temp_c.display(unavail) if snap.cpu_temp_c.available else self.t("dashboard.live_sensor_active"),
            bar_percent=int(cpu_val) if snap.cpu_percent.available else 0,
        )

        ram_val = float(snap.ram_percent.value) if snap.ram_percent.available else 0.0
        self.ram_live_card.update_metric(
            None,
            snap.ram_percent.display(unavail),
            snap.ram_used_gb.display(unavail),
            bar_percent=int(ram_val) if snap.ram_percent.available else 0,
        )

        if snap.gpu_percent.available:
            gpu_val = float(snap.gpu_percent.value)
            vram_sub = (
                f"VRAM {snap.gpu_vram_used_mb.value}/{snap.gpu_vram_total_mb.value} MB"
                if (snap.gpu_vram_used_mb.available and snap.gpu_vram_total_mb.available)
                else snap.gpu_temp_c.display(unavail)
            )
            self.gpu_live_card.update_metric(None, snap.gpu_percent.display(unavail), vram_sub, bar_percent=int(gpu_val))
        else:
            self.gpu_live_card.update_metric(None, unavail, snap.gpu_percent.reason, bar_percent=0)

        # Emulator live running status
        if snap.gameloop_running:
            self.emu_status_badge.setText(self.t("dashboard.emu_running"))
            self.emu_status_badge.set_level("ok")
            perf_sub = f"GameLoop RAM: {snap.gameloop_ram_mb.display(unavail)}"
        else:
            self.emu_status_badge.setText(self.t("dashboard.emu_stopped"))
            self.emu_status_badge.set_level("muted")
            perf_sub = self.t("dashboard.emu_stopped")

        perf_state = self.t("dashboard.perf_optimal") if (cpu_val < 75 and ram_val < 80) else self.t("dashboard.perf_heavy")
        perf_level = "ok" if (cpu_val < 75 and ram_val < 80) else "warning"
        self.perf_card.update_metric(None, perf_state, perf_sub, badge_text=perf_state, badge_level=perf_level)

    def _refresh_summary(self) -> None:
        report = self.services.last_analysis
        unavail = self.t("common.unavailable")
        if report:
            self.hero_score_val.setText(f"{report.hardware_score} / 100")
            self.hero_readiness_lbl.setText(report.gaming_readiness)
            self.pc_status_badge.setText(f"PC: {report.gaming_readiness}")
            self.pc_status_badge.set_level("ok" if report.hardware_score >= 70 else "warning")

            self.readiness_card.update_metric(
                None,
                report.gaming_readiness,
                report.bottleneck,
                badge_text=f"{report.hardware_score}/100",
                badge_level="ok" if report.hardware_score >= 70 else "warning",
            )
            gl_installed = report.hardware.gameloop_installed
            gl_text = self.t("dashboard.gl_installed") if gl_installed else self.t("dashboard.gl_missing")
            self.gl_status_badge.setText(f"GameLoop: {gl_text}")
            self.gl_status_badge.set_level("ok" if gl_installed else "warning")
            self.gameloop_card.update_metric(
                None,
                gl_text,
                report.hardware.gameloop_path or unavail,
                badge_text=gl_text,
                badge_level="ok" if gl_installed else "warning",
            )

            issue_count = len(report.issues)
            self.alerts_card.update_metric(
                None,
                str(issue_count),
                report.issues[0] if report.issues else self.t("dashboard.no_alerts"),
                badge_text=self.t("dashboard.alerts_ok") if issue_count == 0 else self.t("dashboard.alerts_review"),
                badge_level="ok" if issue_count == 0 else "warning",
            )
        else:
            self.hero_score_val.setText("--")
            self.hero_readiness_lbl.setText(self.t("dashboard.run_scan_prompt"))
            self.pc_status_badge.setText(self.t("dashboard.not_scanned"))
            self.pc_status_badge.set_level("info")

            gl = self.services.last_gameloop_info
            gl_text = self.t("dashboard.gl_installed") if (gl and gl.installed) else "--"
            self.gl_status_badge.setText(f"GameLoop: {gl_text}")
            self.gl_status_badge.set_level("ok" if (gl and gl.installed) else "muted")
            self.gameloop_card.update_metric(None, gl_text, gl.install_dir if (gl and gl.installed) else "")
            self.readiness_card.update_metric(None, "--", self.t("dashboard.run_scan_prompt"))
            self.alerts_card.update_metric(None, "0", self.t("dashboard.no_alerts"))

        backups = self.services.backup_manager.list_backups()
        verified_count = sum(1 for b in backups if b.verified)
        self.backups_card.update_metric(
            None,
            f"{verified_count} / {len(backups)}",
            "SHA-256",
            badge_text="SHA-256",
            badge_level="ok" if verified_count == len(backups) else "warning",
        )

        # Recent Operations from unified TaskManager
        self.ops_list.clear()
        recent_ops = self.services.task_manager.all_recent(12)
        if not recent_ops:
            self.ops_list.addItem(self.t("ops.no_history"))
        else:
            for op in recent_ops:
                pct = f" ({op.progress}%)" if op.progress is not None else ""
                line = f"[{op.status.upper()}{pct}] {op.name} — {op.result_summary or op.description}"
                self.ops_list.addItem(line)

        # Recent Audited Optimizations
        self.audit_list.clear()
        entries = self.services.audit.recent_entries(12)
        if not entries:
            self.audit_list.addItem(self.t("dashboard.no_audit"))
        else:
            for entry in entries:
                ts = str(entry.get("timestamp_utc", ""))[:19].replace("T", " ")
                status = "OK" if entry.get("success") else "FAIL"
                line = f"[{ts}] [{status}] {entry.get('action')} -> {entry.get('target')}"
                self.audit_list.addItem(line)

    def _run_quick_scan(self) -> None:
        def task(progress_cb=None, cancel_token=None) -> AnalysisReport:
            hw = self.services.hardware_detector.detect(
                progress_cb=progress_cb, cancel_token=cancel_token
            )
            return self.services.hardware_analyzer.analyze(hw)

        def on_done(report: AnalysisReport) -> None:
            self.services.last_analysis = report
            self.services.last_gameloop_info = self.services.gameloop_discovery.discover()
            self._refresh_summary()

        self.run_background_task(self.t("dashboard.quick_scan"), task, on_done)
