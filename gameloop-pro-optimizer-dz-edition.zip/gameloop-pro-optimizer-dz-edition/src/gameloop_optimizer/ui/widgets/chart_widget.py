"""Liquid Glass ultra-lightweight smooth rolling line chart built with QPainter."""

from __future__ import annotations

from collections import deque

from PySide6.QtCore import QPointF, Qt
from PySide6.QtGui import QColor, QLinearGradient, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import QWidget


class RollingLineChart(QWidget):
    def __init__(
        self,
        title: str = "",
        color_hex: str = "#00E5FF",
        max_points: int = 60,
        y_max: float = 100.0,
        unit: str = "%",
        auto_scale: bool = False,
        parent=None,
    ) -> None:
        super().__init__(parent)
        self._title = title
        self._color = QColor(color_hex)
        self._max_points = max(10, max_points)
        self._y_max = max(1.0, y_max)
        self._auto_scale = auto_scale
        self._unit = unit
        self._values: deque[float | None] = deque(maxlen=self._max_points)
        self.setMinimumHeight(138)

    def set_window_size(self, max_points: int) -> None:
        new_deque: deque[float | None] = deque(self._values, maxlen=max(10, max_points))
        self._max_points = max(10, max_points)
        self._values = new_deque
        self.update()

    def set_title(self, title: str) -> None:
        self._title = title
        self.update()

    def clear(self) -> None:
        self._values.clear()
        self.update()

    def push_value(self, value: float | None) -> None:
        self._values.append(value)
        self.update()

    def stats(self) -> tuple[float | None, float | None, float | None]:
        """Return (latest, average, peak) across currently buffered valid samples."""
        valid = [float(v) for v in self._values if v is not None]
        if not valid:
            return None, None, None
        latest = float(self._values[-1]) if self._values[-1] is not None else valid[-1]
        avg = sum(valid) / len(valid)
        peak = max(valid)
        return latest, avg, peak

    def paintEvent(self, event) -> None:  # noqa: N802 - Qt override
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)

        rect = self.rect().adjusted(4, 4, -4, -4)

        # Liquid Glass card background
        bg_grad = QLinearGradient(0, rect.top(), 0, rect.bottom())
        bg_grad.setColorAt(0.0, QColor(20, 34, 60, 224))
        bg_grad.setColorAt(1.0, QColor(11, 19, 36, 238))
        painter.setPen(QPen(QColor(148, 215, 255, 42), 1))
        painter.setBrush(bg_grad)
        painter.drawRoundedRect(rect, 14, 14)

        # Top specular glass highlight line
        painter.setPen(QPen(QColor(255, 255, 255, 48), 1))
        painter.drawLine(rect.left() + 14, rect.top() + 1, rect.right() - 14, rect.top() + 1)

        plot = rect.adjusted(14, 34, -14, -12)

        # Subtle horizontal gridlines
        grid_pen = QPen(QColor(148, 215, 255, 22), 1, Qt.PenStyle.DashLine)
        painter.setPen(grid_pen)
        for frac in (0.25, 0.5, 0.75):
            y = plot.top() + plot.height() * frac
            painter.drawLine(int(plot.left()), int(y), int(plot.right()), int(y))

        # Header: title + live / average stats
        latest, avg, peak = self.stats()
        if latest is not None and avg is not None:
            metrics_text = f"{latest:.1f}{self._unit}  •  avg {avg:.1f}{self._unit}"
        else:
            metrics_text = "--"

        header_rect = rect.adjusted(14, 8, -14, 0)
        painter.setPen(QColor("#E2E8F0"))
        painter.drawText(header_rect, Qt.AlignmentFlag.AlignLeft, self._title)
        painter.setPen(self._color)
        painter.drawText(header_rect, Qt.AlignmentFlag.AlignRight, metrics_text)

        valid_points = [(i, float(v)) for i, v in enumerate(self._values) if v is not None]
        if len(valid_points) < 2:
            painter.end()
            return

        effective_ymax = self._y_max
        if self._auto_scale and peak is not None:
            effective_ymax = max(10.0, peak * 1.25)

        step_x = plot.width() / max(1, self._max_points - 1)
        offset = self._max_points - len(self._values)

        pts: list[QPointF] = []
        for idx, val in valid_points:
            clamped = max(0.0, min(effective_ymax, val))
            x = plot.left() + (offset + idx) * step_x
            y = plot.bottom() - (clamped / effective_ymax) * plot.height()
            pts.append(QPointF(x, y))

        # Smooth cubic spline path
        line_path = QPainterPath()
        line_path.moveTo(pts[0])
        for i in range(1, len(pts)):
            p0 = pts[i - 1]
            p1 = pts[i]
            mid_x = (p0.x() + p1.x()) * 0.5
            line_path.cubicTo(QPointF(mid_x, p0.y()), QPointF(mid_x, p1.y()), p1)

        # Translucent gradient area fill
        fill_path = QPainterPath(line_path)
        fill_path.lineTo(QPointF(pts[-1].x(), plot.bottom()))
        fill_path.lineTo(QPointF(pts[0].x(), plot.bottom()))
        fill_path.closeSubpath()

        gradient = QLinearGradient(0, plot.top(), 0, plot.bottom())
        top_color = QColor(self._color)
        top_color.setAlpha(82)
        bottom_color = QColor(self._color)
        bottom_color.setAlpha(4)
        gradient.setColorAt(0.0, top_color)
        gradient.setColorAt(1.0, bottom_color)
        painter.fillPath(fill_path, gradient)

        # Soft glow stroke + crisp main curve
        glow_color = QColor(self._color)
        glow_color.setAlpha(55)
        painter.setPen(QPen(glow_color, 5, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        painter.drawPath(line_path)

        painter.setPen(QPen(self._color, 2.2, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        painter.drawPath(line_path)

        # Latest sample luminous dot
        last_pt = pts[-1]
        painter.setBrush(self._color)
        painter.setPen(QPen(QColor("#FFFFFF"), 1.5))
        painter.drawEllipse(last_pt, 3.6, 3.6)
        painter.end()
