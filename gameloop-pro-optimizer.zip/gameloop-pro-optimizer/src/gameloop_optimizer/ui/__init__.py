"""PySide6 Dark Premium UI package."""
