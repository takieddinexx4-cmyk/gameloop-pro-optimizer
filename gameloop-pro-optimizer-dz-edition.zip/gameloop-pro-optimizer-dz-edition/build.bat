@echo off
setlocal enabledelayedexpansion

echo ==============================================================
echo   GAMELOOP PRO OPTIMIZER - DZ EDITION (Local Windows Builder)
echo ==============================================================

where python >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Python 3.11 is not installed or not in PATH.
    exit /b 1
)

if not exist ".venv" (
    echo [INFO] Creating virtual environment...
    python -m venv .venv
    if %errorlevel% neq 0 exit /b 1
)

call .venv\Scripts\activate.bat
if %errorlevel% neq 0 exit /b 1

echo [INFO] Installing pinned requirements...
python -m pip install --upgrade pip
pip install -r requirements.txt
if %errorlevel% neq 0 exit /b 1

echo [INFO] Running non-GUI tests...
pytest -v -m "not gui"
if %errorlevel% neq 0 (
    echo [ERROR] Unit tests failed. Build aborted.
    exit /b 1
)

echo [INFO] Generating DZ Edition icon & brand assets...
python scripts\generate_icon.py
if %errorlevel% neq 0 exit /b 1

echo [INFO] Building executable with PyInstaller...
pyinstaller --noconfirm --clean --onefile --windowed --noconsole ^
  --name "GAMELOOP PRO OPTIMIZER DZ EDITION" ^
  --icon "assets\app_icon.ico" ^
  --version-file "version_info.txt" ^
  --paths "src" ^
  --add-data "locales;locales" ^
  --add-data "assets;assets" ^
  --hidden-import "win32api" ^
  --hidden-import "win32con" ^
  --hidden-import "win32evtlog" ^
  --hidden-import "win32timezone" ^
  --hidden-import "pywintypes" ^
  --hidden-import "pythoncom" ^
  --hidden-import "wmi" ^
  src\main.py

if %errorlevel% neq 0 (
    echo [ERROR] PyInstaller build failed.
    exit /b 1
)

echo [INFO] Generating SHA256 checksum...
powershell -NoProfile -Command "$p='dist\GAMELOOP PRO OPTIMIZER DZ EDITION.exe'; $h=(Get-FileHash -Path $p -Algorithm SHA256).Hash.ToLowerInvariant(); \"$h  GAMELOOP PRO OPTIMIZER DZ EDITION.exe\" | Set-Content -Path \"$p.sha256\" -Encoding ascii -NoNewline"

echo ==============================================================
echo [SUCCESS] Build complete:
echo   dist\GAMELOOP PRO OPTIMIZER DZ EDITION.exe
echo   dist\GAMELOOP PRO OPTIMIZER DZ EDITION.exe.sha256
echo ==============================================================
endlocal
