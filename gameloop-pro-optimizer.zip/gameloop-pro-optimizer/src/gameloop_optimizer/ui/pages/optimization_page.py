"""Smart Optimization page: Safe / Advanced / Pro Custom with mandatory preview & rollback."""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QHBoxLayout,
    QHeaderView,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
)

from gameloop_optimizer.app_core.models import TweakActionResult, TweakPreview
from gameloop_optimizer.app_core.service_container import ServiceContainer
from gameloop_optimizer.ui.pages.base_page import BasePage
from gameloop_optimizer.ui.widgets.dialogs import ChangeConfirmationDialog


class OptimizationPage(BasePage):
    def __init__(self, services: ServiceContainer, parent=None) -> None:
        super().__init__(services, parent)
        self._mode = "safe"
        self._previews: list[TweakPreview] = []
        self._build_ui()

    def _build_ui(self) -> None:
        mode_row = QHBoxLayout()
        mode_row.setSpacing(8)
        self.safe_btn = QPushButton()
        self.adv_btn = QPushButton()
        self.pro_btn = QPushButton()
        self.refresh_btn = QPushButton()

        self.safe_btn.clicked.connect(lambda: self._set_mode("safe"))
        self.adv_btn.clicked.connect(lambda: self._set_mode("advanced"))
        self.pro_btn.clicked.connect(lambda: self._set_mode("pro"))
        self.refresh_btn.clicked.connect(self._load_previews)

        mode_row.addWidget(self.safe_btn)
        mode_row.addWidget(self.adv_btn)
        mode_row.addWidget(self.pro_btn)
        mode_row.addStretch(1)
        mode_row.addWidget(self.refresh_btn)
        self.page_layout.addLayout(mode_row)

        self.table = QTableWidget(0, 6)
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(5, QHeaderView.ResizeMode.Stretch)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        self.page_layout.addWidget(self.table, 1)

        action_row = QHBoxLayout()
        self.apply_btn = QPushButton()
        self.apply_btn.setObjectName("PrimaryButton")
        self.apply_btn.clicked.connect(self._on_apply_selected)

        self.rollback_btn = QPushButton()
        self.rollback_btn.setObjectName("DangerButton")
        self.rollback_btn.clicked.connect(self._on_rollback_selected)

        action_row.addWidget(self.apply_btn)
        action_row.addWidget(self.rollback_btn)
        action_row.addStretch(1)
        self.page_layout.addLayout(action_row)

    def on_page_activated(self) -> None:
        self._load_previews()

    def retranslate_ui(self) -> None:
        self.safe_btn.setText(self.t("opt.mode_safe"))
        self.adv_btn.setText(self.t("opt.mode_advanced"))
        self.pro_btn.setText(self.t("opt.mode_pro"))
        self.refresh_btn.setText(self.t("common.refresh"))
        self.apply_btn.setText(self.t("opt.apply_selected"))
        self.rollback_btn.setText(self.t("opt.rollback_selected"))
        self.table.setHorizontalHeaderLabels(
            [
                self.t("opt.col_select"),
                self.t("opt.col_name"),
                self.t("opt.col_category"),
                self.t("opt.col_current"),
                self.t("opt.col_proposed"),
                self.t("opt.col_status"),
            ]
        )

    def _set_mode(self, mode: str) -> None:
        self._mode = mode
        self._load_previews()

    def _load_previews(self) -> None:
        self._previews = self.services.optimization_engine.list_previews(self._mode)
        self.table.setRowCount(len(self._previews))
        unavail = self.t("common.unavailable")

        for row, p in enumerate(self._previews):
            chk = QTableWidgetItem()
            chk.setFlags(
                Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsUserCheckable
                if p.available
                else Qt.ItemFlag.NoItemFlags
            )
            chk.setCheckState(Qt.CheckState.Unchecked)
            self.table.setItem(row, 0, chk)
            self.table.setItem(row, 1, QTableWidgetItem(f"{p.name}\n({p.description})"))
            self.table.setItem(row, 2, QTableWidgetItem(p.category.upper()))
            self.table.setItem(row, 3, QTableWidgetItem(p.current_display))
            self.table.setItem(row, 4, QTableWidgetItem(p.proposed_display))
            status_txt = "Available" if p.available else f"{unavail}: {p.unavailable_reason}"
            self.table.setItem(row, 5, QTableWidgetItem(status_txt))
        self.table.resizeRowsToContents()

    def _selected_previews(self) -> list[TweakPreview]:
        selected: list[TweakPreview] = []
        for row, p in enumerate(self._previews):
            item = self.table.item(row, 0)
            if item and item.checkState() == Qt.CheckState.Checked:
                selected.append(p)
        return selected

    def _on_apply_selected(self) -> None:
        selected = [p for p in self._selected_previews() if p.available]
        if not selected:
            QMessageBox.information(self, self.t("common.info"), self.t("opt.no_selection"))
            return

        lines = [
            "Every change below will be backed up (SHA-256 verified) before modification:",
            "",
        ]
        for p in selected:
            lines.append(f"- {p.name}")
            lines.append(f"  Current : {p.current_display}")
            lines.append(f"  Proposed: {p.proposed_display}")
            if p.requires_admin:
                lines.append("  Privilege: Requires Administrator")
            lines.append("")

        dlg = ChangeConfirmationDialog(
            title=self.t("opt.confirm_title"),
            summary_lines=lines,
            approve_text=self.t("common.approve_apply"),
            cancel_text=self.t("common.cancel"),
            parent=self,
        )
        if dlg.exec() != ChangeConfirmationDialog.DialogCode.Accepted:
            return

        tweak_ids = [p.tweak_id for p in selected]

        def on_done(results: list[TweakActionResult]) -> None:
            summary = [
                f"[{'OK' if r.success else 'FAIL'}] {r.tweak_id}: {r.message} (Backup: {r.backup_id or 'none'})"
                for r in results
            ]
            QMessageBox.information(self, self.t("common.info"), "\n".join(summary))
            self._load_previews()

        self.run_background_task(
            self.t("opt.apply_selected"),
            self.services.optimization_engine.apply_many,
            on_done,
            tweak_ids=tweak_ids,
        )

    def _on_rollback_selected(self) -> None:
        selected = self._selected_previews()
        if not selected:
            QMessageBox.information(self, self.t("common.info"), self.t("opt.no_selection"))
            return

        msgs: list[str] = []
        for p in selected:
            ok, logs = self.services.optimization_engine.rollback_tweak(p.tweak_id)
            msgs.append(f"[{'OK' if ok else 'INFO'}] {p.name}: {'; '.join(logs)}")
        QMessageBox.information(self, self.t("common.info"), "\n".join(msgs))
        self._load_previews()
