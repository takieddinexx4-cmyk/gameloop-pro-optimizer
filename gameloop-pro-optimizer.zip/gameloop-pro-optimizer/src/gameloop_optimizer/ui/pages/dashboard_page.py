"""Dashboard overview page with quick diagnostics and recent audit history."""

from __future__ import annotations

from typing import Callable

from PySide6.QtWidgets import (
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QPushButton,
)

from gameloop_optimizer.app_core.models import AnalysisReport
from gameloop_optimizer.app_core.service_container import ServiceContainer
from gameloop_optimizer.ui.pages.base_page import BasePage
from gameloop_optimizer.ui.widgets.cards import GlassCard, MetricCard, SectionHeader


class DashboardPage(BasePage):
    def __init__(
        self,
        services: ServiceContainer,
        navigate_cb: Callable[[str], None] | None = None,
        parent=None,
    ) -> None:
        super().__init__(services, parent)
        self._navigate_cb = navigate_cb
        self._build_ui()

    def _build_ui(self) -> None:
        self.subtitle_label = QLabel()
        self.subtitle_label.setObjectName("MutedLabel")
        self.subtitle_label.setWordWrap(True)
        self.page_layout.addWidget(self.subtitle_label)

        cards_grid = QGridLayout()
        cards_grid.setSpacing(12)
        self.score_card = MetricCard("", "--")
        self.readiness_card = MetricCard("", "--")
        self.gameloop_card = MetricCard("", "--")
        self.backups_card = MetricCard("", "0")

        cards_grid.addWidget(self.score_card, 0, 0)
        cards_grid.addWidget(self.readiness_card, 0, 1)
        cards_grid.addWidget(self.gameloop_card, 0, 2)
        cards_grid.addWidget(self.backups_card, 0, 3)
        self.page_layout.addLayout(cards_grid)

        actions_card = GlassCard()
        actions_row = QHBoxLayout()
        actions_row.setSpacing(10)

        self.scan_btn = QPushButton()
        self.scan_btn.setObjectName("PrimaryButton")
        self.scan_btn.clicked.connect(self._run_quick_scan)

        self.crash_btn = QPushButton()
        self.crash_btn.clicked.connect(lambda: self._go("crash_lag"))

        self.opt_btn = QPushButton()
        self.opt_btn.clicked.connect(lambda: self._go("optimization"))

        actions_row.addWidget(self.scan_btn)
        actions_row.addWidget(self.crash_btn)
        actions_row.addWidget(self.opt_btn)
        actions_row.addStretch(1)
        actions_card.root_layout.addLayout(actions_row)

        self.honesty_label = QLabel()
        self.honesty_label.setObjectName("MutedLabel")
        self.honesty_label.setWordWrap(True)
        actions_card.root_layout.addWidget(self.honesty_label)
        self.page_layout.addWidget(actions_card)

        self.audit_header = SectionHeader("")
        self.page_layout.addWidget(self.audit_header)

        self.audit_list = QListWidget()
        self.page_layout.addWidget(self.audit_list, 1)

    def _go(self, page_key: str) -> None:
        if self._navigate_cb:
            self._navigate_cb(page_key)

    def on_page_activated(self) -> None:
        self._refresh_summary()

    def retranslate_ui(self) -> None:
        self.subtitle_label.setText(self.t("dashboard.subtitle"))
        self.scan_btn.setText(self.t("dashboard.quick_scan"))
        self.crash_btn.setText(self.t("dashboard.quick_crash"))
        self.opt_btn.setText(self.t("dashboard.quick_opt"))
        self.honesty_label.setText(self.t("common.not_tested_hw"))
        self.audit_header.title_label.setText(self.t("dashboard.recent_audit"))
        self._refresh_summary()

    def _refresh_summary(self) -> None:
        report = self.services.last_analysis
        if report:
            self.score_card.update_metric(
                self.t("dashboard.card_score"),
                f"{report.hardware_score} / 100",
                report.bottleneck,
            )
            self.readiness_card.update_metric(
                self.t("dashboard.card_readiness"),
                report.gaming_readiness,
                report.hardware.windows_version.display(self.t("common.unavailable")),
            )
            gl_text = (
                self.t("dashboard.gl_installed")
                if report.hardware.gameloop_installed
                else self.t("dashboard.gl_missing")
            )
            self.gameloop_card.update_metric(
                self.t("dashboard.card_gameloop"),
                gl_text,
                report.hardware.gameloop_path or self.t("common.unavailable"),
            )
        else:
            self.score_card.update_metric(self.t("dashboard.card_score"), "--", "")
            self.readiness_card.update_metric(self.t("dashboard.card_readiness"), "--", "")
            gl = self.services.last_gameloop_info
            gl_text = (
                self.t("dashboard.gl_installed")
                if (gl and gl.installed)
                else "--"
            )
            self.gameloop_card.update_metric(self.t("dashboard.card_gameloop"), gl_text, "")

        backups = self.services.backup_manager.list_backups()
        verified_count = sum(1 for b in backups if b.verified)
        self.backups_card.update_metric(
            self.t("dashboard.card_backups"),
            f"{verified_count} / {len(backups)}",
            "SHA-256",
        )

        self.audit_list.clear()
        for entry in self.services.audit.recent_entries(15):
            ts = str(entry.get("timestamp_utc", ""))[:19].replace("T", " ")
            status = "OK" if entry.get("success") else "FAIL"
            line = f"[{ts}] [{status}] {entry.get('action')} -> {entry.get('target')} ({entry.get('details', '')})"
            self.audit_list.addItem(line)

    def _run_quick_scan(self) -> None:
        def task(progress_cb=None, cancel_token=None) -> AnalysisReport:
            hw = self.services.hardware_detector.detect(
                progress_cb=progress_cb, cancel_token=cancel_token
            )
            return self.services.hardware_analyzer.analyze(hw)

        def on_done(report: AnalysisReport) -> None:
            self.services.last_analysis = report
            self.services.last_gameloop_info = self.services.gameloop_discovery.discover()
            self._refresh_summary()

        self.run_background_task(self.t("dashboard.quick_scan"), task, on_done)
