"""About page: DZ Edition brand lockup, transparency notice, security pledge, and log folder access."""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import QHBoxLayout, QLabel, QMessageBox, QPushButton

from gameloop_optimizer.app_core.constants import APP_NAME, APP_VERSION
from gameloop_optimizer.app_core.paths import get_app_data_dir, get_assets_dir, get_logs_dir
from gameloop_optimizer.app_core.service_container import ServiceContainer
from gameloop_optimizer.ui.pages.base_page import BasePage
from gameloop_optimizer.ui.widgets.cards import GlassCard


class AboutPage(BasePage):
    def __init__(self, services: ServiceContainer, parent=None) -> None:
        super().__init__(services, parent)
        self._build_ui()

    def _build_ui(self) -> None:
        card = GlassCard(hero=True)

        banner = QLabel()
        banner.setStyleSheet("background: transparent;")
        horiz_path = get_assets_dir() / "dz_logo_horizontal.png"
        if horiz_path.exists():
            banner.setPixmap(
                QPixmap(str(horiz_path)).scaledToWidth(
                    520, Qt.TransformationMode.SmoothTransformation
                )
            )
            card.root_layout.addWidget(banner)

        title = QLabel(f"{APP_NAME}  v{APP_VERSION}")
        title.setObjectName("PageTitle")
        card.root_layout.addWidget(title)

        self.desc_label = QLabel()
        self.desc_label.setWordWrap(True)
        card.root_layout.addWidget(self.desc_label)

        self.pledge_label = QLabel()
        self.pledge_label.setWordWrap(True)
        self.pledge_label.setStyleSheet("color: #6EE7B7; background: transparent;")
        card.root_layout.addWidget(self.pledge_label)

        self.honesty_label = QLabel()
        self.honesty_label.setWordWrap(True)
        self.honesty_label.setStyleSheet("color: #FBBF24; background: transparent;")
        card.root_layout.addWidget(self.honesty_label)

        paths_label = QLabel(
            f"Data Directory: {get_app_data_dir()}\n"
            f"Logs Directory: {get_logs_dir()}\n"
            "License: MIT License"
        )
        paths_label.setObjectName("MutedLabel")
        paths_label.setWordWrap(True)
        card.root_layout.addWidget(paths_label)

        btn_row = QHBoxLayout()
        self.open_logs_btn = QPushButton()
        self.open_logs_btn.setObjectName("PrimaryButton")
        self.open_logs_btn.clicked.connect(self._open_logs)
        btn_row.addWidget(self.open_logs_btn)
        btn_row.addStretch(1)
        card.root_layout.addLayout(btn_row)

        self.page_layout.addWidget(card)
        self.page_layout.addStretch(1)

    def retranslate_ui(self) -> None:
        self.desc_label.setText(self.t("about.description"))
        self.pledge_label.setText(self.t("about.security_pledge"))
        self.honesty_label.setText(self.t("common.not_tested_hw"))
        self.open_logs_btn.setText(self.t("about.open_logs"))

    def _open_logs(self) -> None:
        ok, msg = self.services.gameloop_controller.open_folder(str(get_logs_dir()))
        if not ok:
            QMessageBox.information(self, self.t("common.info"), f"Logs folder:\n{get_logs_dir()}\n({msg})")
