"""ADB discovery, health diagnostics, connection control, and repair."""
