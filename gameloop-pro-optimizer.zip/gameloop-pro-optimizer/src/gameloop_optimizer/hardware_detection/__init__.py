"""Hardware detection, sensor probing, and honest bottleneck analysis."""
