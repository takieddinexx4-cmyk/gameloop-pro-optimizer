"""Background QThread worker with progress reporting and safe cancellation."""

from __future__ import annotations

import threading
from typing import Any, Callable

from PySide6.QtCore import QThread, Signal


class CancellationToken:
    """Thread-safe cancellation flag passed into long-running tasks."""

    def __init__(self) -> None:
        self._event = threading.Event()

    def cancel(self) -> None:
        self._event.set()

    @property
    def is_cancelled(self) -> bool:
        return self._event.is_set()


class TaskCancelledError(Exception):
    """Raised cleanly inside tasks when user requests cancellation."""


class WorkerThread(QThread):
    progress = Signal(int, str)
    finished_result = Signal(object)
    failed = Signal(str)
    cancelled = Signal()

    def __init__(
        self,
        fn: Callable[..., Any],
        *args: Any,
        **kwargs: Any,
    ) -> None:
        super().__init__()
        self._fn = fn
        self._args = args
        self._kwargs = kwargs
        self.token = CancellationToken()

    def cancel(self) -> None:
        self.token.cancel()

    def _report_progress(self, percent: int, message: str) -> None:
        self.progress.emit(max(0, min(100, int(percent))), message)

    def run(self) -> None:
        try:
            result = self._fn(
                *self._args,
                progress_cb=self._report_progress,
                cancel_token=self.token,
                **self._kwargs,
            )
            if self.token.is_cancelled:
                self.cancelled.emit()
            else:
                self.finished_result.emit(result)
        except TaskCancelledError:
            self.cancelled.emit()
        except Exception as exc:  # noqa: BLE001 - worker boundary must never crash GUI
            self.failed.emit(str(exc))
