"""Process Manager page with strict Windows system-process protection."""

from __future__ import annotations

from PySide6.QtWidgets import (
    QHBoxLayout,
    QHeaderView,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
)

from gameloop_optimizer.app_core.service_container import ServiceContainer
from gameloop_optimizer.ui.pages.base_page import BasePage


class ProcessManagerPage(BasePage):
    def __init__(self, services: ServiceContainer, parent=None) -> None:
        super().__init__(services, parent)
        self._rows: list[dict] = []
        self._build_ui()

    def _build_ui(self) -> None:
        bar = QHBoxLayout()
        self.refresh_btn = QPushButton()
        self.refresh_btn.setObjectName("PrimaryButton")
        self.refresh_btn.clicked.connect(self._refresh)

        self.prio_norm_btn = QPushButton()
        self.prio_norm_btn.clicked.connect(lambda: self._set_priority("normal"))
        self.prio_above_btn = QPushButton()
        self.prio_above_btn.clicked.connect(lambda: self._set_priority("above_normal"))
        self.prio_high_btn = QPushButton()
        self.prio_high_btn.clicked.connect(lambda: self._set_priority("high"))
        self.affinity_btn = QPushButton()
        self.affinity_btn.clicked.connect(self._eval_affinity)
        self.term_btn = QPushButton()
        self.term_btn.setObjectName("DangerButton")
        self.term_btn.clicked.connect(self._terminate_selected)

        for b in (
            self.refresh_btn,
            self.prio_norm_btn,
            self.prio_above_btn,
            self.prio_high_btn,
            self.affinity_btn,
            self.term_btn,
        ):
            bar.addWidget(b)
        bar.addStretch(1)
        self.page_layout.addLayout(bar)

        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["PID", "Process Name", "RAM (MB)", "CPU %", "Safety Tag"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeMode.ResizeToContents)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        self.page_layout.addWidget(self.table, 1)

    def on_page_activated(self) -> None:
        self._refresh()

    def retranslate_ui(self) -> None:
        self.refresh_btn.setText(self.t("proc.refresh"))
        self.prio_norm_btn.setText(self.t("proc.priority_normal"))
        self.prio_above_btn.setText(self.t("proc.priority_above"))
        self.prio_high_btn.setText(self.t("proc.priority_high"))
        self.affinity_btn.setText(self.t("proc.check_affinity"))
        self.term_btn.setText(self.t("proc.terminate"))

    def _refresh(self) -> None:
        self._rows = self.services.process_tools.list_processes(limit=120)
        self.table.setRowCount(len(self._rows))
        for idx, row in enumerate(self._rows):
            self.table.setItem(idx, 0, QTableWidgetItem(str(row["pid"])))
            self.table.setItem(idx, 1, QTableWidgetItem(row["name"]))
            self.table.setItem(idx, 2, QTableWidgetItem(f"{row['ram_mb']:.1f}"))
            self.table.setItem(idx, 3, QTableWidgetItem(f"{row['cpu_percent']:.1f}"))
            tag = (
                "GAMELOOP"
                if row["is_gameloop"]
                else ("PROTECTED SYSTEM" if row["is_protected"] else "User")
            )
            self.table.setItem(idx, 4, QTableWidgetItem(tag))

    def _selected_row(self) -> dict | None:
        row_idx = self.table.currentRow()
        if 0 <= row_idx < len(self._rows):
            return self._rows[row_idx]
        QMessageBox.information(self, self.t("common.info"), "Select a process row first.")
        return None

    def _set_priority(self, level: str) -> None:
        row = self._selected_row()
        if not row:
            return
        ok, msg = self.services.process_tools.set_process_priority(row["pid"], level)
        QMessageBox.information(self, self.t("common.success" if ok else "common.warning"), msg)

    def _eval_affinity(self) -> None:
        row = self._selected_row()
        if not row:
            return
        rec, cpus, reason = self.services.process_tools.evaluate_cpu_affinity(row["pid"])
        if not rec:
            QMessageBox.information(self, self.t("common.info"), reason)
            return
        ans = QMessageBox.question(self, self.t("common.confirm"), f"{reason}\nApply affinity {cpus}?")
        if ans == QMessageBox.StandardButton.Yes:
            ok, msg = self.services.process_tools.apply_cpu_affinity(row["pid"], cpus)
            QMessageBox.information(self, self.t("common.success" if ok else "common.warning"), msg)

    def _terminate_selected(self) -> None:
        row = self._selected_row()
        if not row:
            return
        if row["is_protected"]:
            QMessageBox.warning(
                self,
                self.t("common.warning"),
                f"Blocked for Windows stability: '{row['name']}' is a protected system process.",
            )
            return
        ans = QMessageBox.question(
            self,
            self.t("common.confirm"),
            f"Terminate '{row['name']}' (PID {row['pid']})?",
        )
        if ans != QMessageBox.StandardButton.Yes:
            return
        ok, msg = self.services.process_tools.terminate_process(row["pid"])
        QMessageBox.information(self, self.t("common.success" if ok else "common.warning"), msg)
        self._refresh()
