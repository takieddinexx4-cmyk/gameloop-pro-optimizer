"""Honest hardware sensor probing (returns Unavailable when no sensor exists)."""

from __future__ import annotations

import sys
from typing import Callable

import psutil

from gameloop_optimizer.app_core.models import MetricValue
from gameloop_optimizer.app_core.process_runner import run_command
from gameloop_optimizer.logging.logger import get_logger

logger = get_logger("hardware_detection.sensors")


def _probe_libre_ohm_wmi() -> tuple[float | None, float | None]:
    """Query LibreHardwareMonitor or OpenHardwareMonitor WMI namespaces if running."""
    if sys.platform != "win32":
        return None, None
    try:
        import pythoncom
        import wmi
    except ImportError:
        return None, None

    cpu_temp: float | None = None
    gpu_temp: float | None = None
    pythoncom.CoInitialize()
    try:
        for ns in ("root\\LibreHardwareMonitor", "root\\OpenHardwareMonitor"):
            try:
                conn = wmi.WMI(namespace=ns)
                sensors = conn.Sensor()
            except Exception:  # noqa: BLE001
                continue
            for sensor in sensors:
                if getattr(sensor, "SensorType", "") != "Temperature":
                    continue
                val = getattr(sensor, "Value", None)
                if val is None:
                    continue
                name = str(getattr(sensor, "Name", "")).lower()
                ident = str(getattr(sensor, "Identifier", "")).lower()
                if cpu_temp is None and ("cpu" in name or "/cpu/" in ident):
                    cpu_temp = round(float(val), 1)
                elif gpu_temp is None and ("gpu" in name or "/gpu/" in ident):
                    gpu_temp = round(float(val), 1)
            if cpu_temp is not None or gpu_temp is not None:
                break
    finally:
        pythoncom.CoUninitialize()
    return cpu_temp, gpu_temp


def _probe_nvidia_smi() -> tuple[float | None, float | None]:
    """Query official nvidia-smi CLI if present on system PATH."""
    res = run_command(
        [
            "nvidia-smi",
            "--query-gpu=temperature.gpu,utilization.gpu",
            "--format=csv,noheader,nounits",
        ],
        timeout=3.0,
    )
    if not res.ok or not res.stdout:
        return None, None
    first_line = res.stdout.splitlines()[0]
    parts = [p.strip() for p in first_line.split(",")]
    if len(parts) < 2:
        return None, None
    try:
        temp = float(parts[0])
        util = float(parts[1])
        return round(temp, 1), round(util, 1)
    except ValueError:
        return None, None


def _probe_nvidia_vram() -> tuple[float | None, float | None]:
    """Query official nvidia-smi VRAM usage (used MB, total MB) if present."""
    res = run_command(
        [
            "nvidia-smi",
            "--query-gpu=memory.used,memory.total",
            "--format=csv,noheader,nounits",
        ],
        timeout=3.0,
    )
    if not res.ok or not res.stdout:
        return None, None
    first_line = res.stdout.splitlines()[0]
    parts = [p.strip() for p in first_line.split(",")]
    if len(parts) < 2:
        return None, None
    try:
        used_mb = round(float(parts[0]), 0)
        total_mb = round(float(parts[1]), 0)
        return used_mb, total_mb
    except ValueError:
        return None, None


def _probe_psutil_cpu_temp() -> float | None:
    if not hasattr(psutil, "sensors_temperatures"):
        return None
    try:
        temps = psutil.sensors_temperatures()
        if not temps:
            return None
        for entries in temps.values():
            for entry in entries:
                if entry.current is not None and entry.current > 0:
                    return round(float(entry.current), 1)
    except Exception:  # noqa: BLE001
        return None
    return None


class SensorProbe:
    """Probes temperature, GPU utilization, and VRAM strictly from verified sources."""

    def __init__(
        self,
        wmi_provider: Callable[[], tuple[float | None, float | None]] | None = None,
        nvidia_provider: Callable[[], tuple[float | None, float | None]] | None = None,
        psutil_temp_provider: Callable[[], float | None] | None = None,
        nvidia_vram_provider: Callable[[], tuple[float | None, float | None]] | None = None,
    ) -> None:
        self._wmi_provider = wmi_provider or _probe_libre_ohm_wmi
        self._nvidia_provider = nvidia_provider or _probe_nvidia_smi
        self._psutil_temp_provider = psutil_temp_provider or _probe_psutil_cpu_temp
        self._nvidia_vram_provider = nvidia_vram_provider or _probe_nvidia_vram

    def read_temperatures(self) -> tuple[MetricValue, MetricValue]:
        wmi_cpu, wmi_gpu = self._safe_pair(self._wmi_provider)
        nv_gpu_temp, _nv_util = self._safe_pair(self._nvidia_provider)

        cpu_val = wmi_cpu
        if cpu_val is None:
            try:
                cpu_val = self._psutil_temp_provider()
            except Exception:  # noqa: BLE001
                cpu_val = None

        gpu_val = wmi_gpu if wmi_gpu is not None else nv_gpu_temp

        cpu_metric = (
            MetricValue(value=cpu_val, unit="°C", available=True)
            if cpu_val is not None
            else MetricValue(
                available=False,
                reason="No accessible CPU temperature sensor (start LibreHardwareMonitor/OpenHardwareMonitor if needed).",
            )
        )
        gpu_metric = (
            MetricValue(value=gpu_val, unit="°C", available=True)
            if gpu_val is not None
            else MetricValue(
                available=False,
                reason="No accessible GPU temperature sensor detected.",
            )
        )
        return cpu_metric, gpu_metric

    def read_gpu_utilization(self) -> MetricValue:
        _nv_temp, nv_util = self._safe_pair(self._nvidia_provider)
        if nv_util is not None:
            return MetricValue(value=nv_util, unit="%", available=True)
        return MetricValue(
            available=False,
            reason="GPU load sensor requires NVIDIA driver (nvidia-smi) or an external monitor provider.",
        )

    def read_gpu_vram(self) -> tuple[MetricValue, MetricValue]:
        used_mb, total_mb = self._safe_pair(self._nvidia_vram_provider)
        if used_mb is not None and total_mb is not None:
            return (
                MetricValue(value=int(used_mb), unit="MB", available=True),
                MetricValue(value=int(total_mb), unit="MB", available=True),
            )
        reason = "VRAM telemetry requires NVIDIA driver (nvidia-smi)."
        return (
            MetricValue(available=False, reason=reason),
            MetricValue(available=False, reason=reason),
        )

    @staticmethod
    def _safe_pair(
        fn: Callable[[], tuple[float | None, float | None]],
    ) -> tuple[float | None, float | None]:
        try:
            return fn()
        except Exception as exc:  # noqa: BLE001
            logger.debug("Sensor provider failed: %s", exc)
            return None, None
