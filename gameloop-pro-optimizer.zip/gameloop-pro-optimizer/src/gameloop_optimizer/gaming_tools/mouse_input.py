"""Mouse & Input latency diagnostics with consented, backed-up precision toggle."""

from __future__ import annotations

from dataclasses import dataclass

from gameloop_optimizer.backup_restore.manager import BackupManager
from gameloop_optimizer.backup_restore.registry_io import REG_SZ
from gameloop_optimizer.logging.audit import AuditLogger


@dataclass
class MouseDiagnosticReport:
    enhance_pointer_precision_enabled: bool
    mouse_sensitivity: str
    mouse_speed: str
    threshold1: str
    threshold2: str
    findings: list[str]
    notes: list[str]


class MouseInputDiagnostics:
    _ROOT = "HKCU"
    _SUBKEY = r"Control Panel\Mouse"

    def __init__(self, backup_manager: BackupManager, audit_logger: AuditLogger) -> None:
        self._backup = backup_manager
        self._reg = backup_manager.registry
        self._audit = audit_logger

    def inspect(self) -> MouseDiagnosticReport:
        speed = self._reg.read_value(self._ROOT, self._SUBKEY, "MouseSpeed")
        t1 = self._reg.read_value(self._ROOT, self._SUBKEY, "MouseThreshold1")
        t2 = self._reg.read_value(self._ROOT, self._SUBKEY, "MouseThreshold2")
        sens = self._reg.read_value(self._ROOT, self._SUBKEY, "MouseSensitivity")

        epp_on = str(speed.value) == "1" if speed.existed else False
        findings: list[str] = []
        notes: list[str] = [
            "Windows pointer sensitivity is NEVER altered automatically; only shown for reference.",
            "Hardware USB mouse polling rate (125/500/1000 Hz) must be configured via your mouse firmware/vendor utility.",
            "For custom side-button remapping outside GameLoop keymapper, see verified X-Mouse Button Control in External Tools.",
        ]

        if epp_on:
            findings.append(
                "Windows 'Enhance Pointer Precision' (mouse acceleration) is ENABLED. Disabling it gives linear 1:1 aim response."
            )
        else:
            findings.append("Windows mouse acceleration appears disabled (linear pointer response).")

        if sens.existed and str(sens.value) != "10":
            findings.append(
                f"Windows MouseSensitivity is {sens.value} (default 1:1 raw notch is 10). Keep your preferred value unless intentionally resetting."
            )

        return MouseDiagnosticReport(
            enhance_pointer_precision_enabled=epp_on,
            mouse_sensitivity=str(sens.value) if sens.existed else "Unavailable",
            mouse_speed=str(speed.value) if speed.existed else "Unavailable",
            threshold1=str(t1.value) if t1.existed else "Unavailable",
            threshold2=str(t2.value) if t2.existed else "Unavailable",
            findings=findings,
            notes=notes,
        )

    def set_pointer_precision(self, enabled: bool) -> tuple[bool, str, str]:
        """Toggle Enhance Pointer Precision with full Registry backup and verification."""
        names = ("MouseSpeed", "MouseThreshold1", "MouseThreshold2")
        before = [self._reg.read_value(self._ROOT, self._SUBKEY, n) for n in names]
        record = self._backup.create_backup(
            category="mouse_input",
            description=f"Backup mouse acceleration before setting enabled={enabled}",
            registry_snapshots=before,
        )

        desired = (
            {"MouseSpeed": "1", "MouseThreshold1": "6", "MouseThreshold2": "10"}
            if enabled
            else {"MouseSpeed": "0", "MouseThreshold1": "0", "MouseThreshold2": "0"}
        )

        for name, val in desired.items():
            ok, msg = self._reg.write_value(self._ROOT, self._SUBKEY, name, val, REG_SZ)
            if not ok:
                self._audit.record("mouse_epp", name, None, val, record.backup_id, False, msg)
                return False, msg, record.backup_id

        after_speed = self._reg.read_value(self._ROOT, self._SUBKEY, "MouseSpeed")
        verified = after_speed.existed and str(after_speed.value) == desired["MouseSpeed"]
        self._audit.record(
            "mouse_epp",
            self._SUBKEY,
            {s.name: s.value for s in before},
            desired,
            record.backup_id,
            verified,
        )
        return (
            verified,
            "Mouse acceleration updated (sign out/in or toggle in Windows Mouse settings if not immediately active)."
            if verified
            else "Failed to verify mouse registry update.",
            record.backup_id,
        )
