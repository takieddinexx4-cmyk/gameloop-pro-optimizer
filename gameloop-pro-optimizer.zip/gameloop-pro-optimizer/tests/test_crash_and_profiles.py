"""Tests for Crash & Lag log parsing, report generation, and hardware-capped PUBG profiles."""

from __future__ import annotations

import json
from pathlib import Path

from gameloop_optimizer.adb_manager.manager import AdbManager
from gameloop_optimizer.app_core.config import ConfigManager
from gameloop_optimizer.app_core.models import HardwareProfile, MetricValue
from gameloop_optimizer.app_core.process_runner import CommandResult
from gameloop_optimizer.backup_restore.manager import BackupManager
from gameloop_optimizer.crash_analyzer.analyzer import CrashLagAnalyzer
from gameloop_optimizer.crash_analyzer.gameloop_logs import scan_gameloop_logs
from gameloop_optimizer.gameloop_manager.discovery import GameLoopDiscovery
from gameloop_optimizer.hardware_detection.detector import HardwareDetector
from gameloop_optimizer.hardware_detection.sensors import SensorProbe
from gameloop_optimizer.logging.audit import AuditLogger
from gameloop_optimizer.profiles.manager import ProfileManager
from gameloop_optimizer.profiles.presets import build_hardware_aware_presets


def test_crash_log_signatures_and_report_export(
    tmp_path: Path, config_manager: ConfigManager
) -> None:
    gl_root = tmp_path / "GL"
    log_dir = gl_root / "ui" / "log"
    log_dir.mkdir(parents=True)
    (gl_root / "ui" / "AndroidEmulatorEx.exe").write_bytes(b"emu")
    (gl_root / "ui" / "adb.exe").write_bytes(b"adb")
    (log_dir / "engine.log").write_text(
        "2025-01-01 ERROR eglCreateContext shader compile fail\n"
        "2025-01-01 WARN adb disconnect socket closed\n",
        encoding="utf-8",
    )

    hits = scan_gameloop_logs([str(log_dir)])
    sig_ids = {h.signature_id for h in hits}
    assert "render_init_error" in sig_ids
    assert "adb_socket_error" in sig_ids

    config_manager.config.custom_gameloop_path = str(gl_root)
    discovery = GameLoopDiscovery(config_manager=config_manager, registry_reader=lambda: ("", ""))
    adb = AdbManager(
        discovery=discovery,
        command_runner=lambda args, timeout=8.0: CommandResult(0, "List of devices attached\n", ""),
    )
    hw_det = HardwareDetector(
        gameloop_discovery=discovery,
        sensor_probe=SensorProbe(lambda: (None, None), lambda: (None, None), lambda: None),
        wmi_querier=lambda: {},
        display_querier=lambda: ("1920x1080", 60),
        vram_reg_querier=lambda: None,
    )
    analyzer = CrashLagAnalyzer(
        gameloop_discovery=discovery,
        adb_manager=adb,
        hardware_detector=hw_det,
        event_log_scanner=lambda: ([], ""),
        reports_dir=tmp_path / "reports",
    )

    findings = analyzer.run_full_scan()
    by_id = {f.finding_id: f for f in findings}
    assert "log_render_init_error" in by_id
    assert by_id["log_render_init_error"].can_auto_fix is False
    assert "log_adb_socket_error" in by_id
    assert by_id["log_adb_socket_error"].can_auto_fix is True

    rep_path = analyzer.generate_report(findings)
    assert rep_path.is_file()
    parsed = json.loads(rep_path.read_text(encoding="utf-8"))
    assert parsed["finding_count"] == len(findings)


def test_pubg_profiles_never_force_unsupported_fps_or_resolution(
    tmp_path: Path, backup_manager: BackupManager, audit_logger: AuditLogger
) -> None:
    weak_hw = HardwareProfile(
        cpu_cores_physical=MetricValue(2, "cores", True),
        ram_total_gb=MetricValue(4.0, "GB", True),
        display_resolution=MetricValue("1366x768", "", True),
        display_refresh_hz=MetricValue(60, "Hz", True),
    )
    presets = {p.profile_id: p for p in build_hardware_aware_presets(weak_hw)}
    comp = presets["competitive"]

    assert comp.resolution_width <= 1366
    assert comp.resolution_height <= 768
    assert comp.target_fps <= 60
    assert comp.ram_mb_alloc <= 2048
    assert len(comp.warnings) >= 2

    pm = ProfileManager(backup_manager, audit_logger, profiles_dir=tmp_path / "profiles")
    ok, _msg, bid = pm.apply_profile(comp)
    assert ok is True
    assert bid != ""

    cur = pm.read_current_gameloop_settings()
    assert cur["FPSLevel"] == str(comp.target_fps)

    # Export & import round-trip
    exp = tmp_path / "exported.json"
    pm.export_profile(comp, exp)
    imported = pm.import_profile(exp)
    assert imported.target_fps == comp.target_fps
    assert imported.resolution_width == comp.resolution_width
