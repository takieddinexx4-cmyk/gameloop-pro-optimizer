"""Secure subprocess execution wrapper.

Enforces shell=False and list-only arguments across the entire codebase.
"""

from __future__ import annotations

import subprocess
import sys
from dataclasses import dataclass
from typing import Sequence


@dataclass
class CommandResult:
    returncode: int
    stdout: str
    stderr: str
    timed_out: bool = False
    not_found: bool = False

    @property
    def ok(self) -> bool:
        return not self.timed_out and not self.not_found and self.returncode == 0


def run_command(
    args: Sequence[str],
    timeout: float = 15.0,
    cwd: str | None = None,
) -> CommandResult:
    """Execute a command safely without a shell."""
    if isinstance(args, (str, bytes)) or not args:
        raise ValueError("Command arguments must be a non-empty sequence of strings.")

    cmd_list = [str(part) for part in args]
    creationflags = 0
    if sys.platform == "win32":
        creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)

    try:
        completed = subprocess.run(
            cmd_list,
            shell=False,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            cwd=cwd,
            creationflags=creationflags,
        )
        return CommandResult(
            returncode=completed.returncode,
            stdout=completed.stdout.strip(),
            stderr=completed.stderr.strip(),
        )
    except FileNotFoundError as exc:
        return CommandResult(returncode=-1, stdout="", stderr=str(exc), not_found=True)
    except subprocess.TimeoutExpired as exc:
        return CommandResult(
            returncode=-1,
            stdout=(exc.stdout or "") if isinstance(exc.stdout, str) else "",
            stderr="Command timed out.",
            timed_out=True,
        )
    except OSError as exc:
        return CommandResult(returncode=-1, stdout="", stderr=str(exc))
