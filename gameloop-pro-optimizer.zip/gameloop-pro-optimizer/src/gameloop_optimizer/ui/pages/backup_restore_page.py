"""Backup & Restore page: SHA-256 verification, full and granular item restoration."""

from __future__ import annotations

from PySide6.QtWidgets import (
    QHBoxLayout,
    QHeaderView,
    QListWidget,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
)

from gameloop_optimizer.app_core.models import BackupRecord
from gameloop_optimizer.app_core.service_container import ServiceContainer
from gameloop_optimizer.ui.pages.base_page import BasePage
from gameloop_optimizer.ui.widgets.cards import SectionHeader


class BackupRestorePage(BasePage):
    def __init__(self, services: ServiceContainer, parent=None) -> None:
        super().__init__(services, parent)
        self._records: list[BackupRecord] = []
        self._build_ui()

    def _build_ui(self) -> None:
        bar = QHBoxLayout()
        self.snapshot_btn = QPushButton()
        self.snapshot_btn.setObjectName("PrimaryButton")
        self.snapshot_btn.clicked.connect(self._create_snapshot)

        self.verify_btn = QPushButton()
        self.verify_btn.clicked.connect(self._verify_selected)

        self.restore_full_btn = QPushButton()
        self.restore_full_btn.setObjectName("SuccessButton")
        self.restore_full_btn.clicked.connect(self._restore_full)

        self.restore_item_btn = QPushButton()
        self.restore_item_btn.clicked.connect(self._restore_single_item)

        self.refresh_btn = QPushButton()
        self.refresh_btn.clicked.connect(self._refresh)

        for b in (
            self.snapshot_btn,
            self.verify_btn,
            self.restore_full_btn,
            self.restore_item_btn,
            self.refresh_btn,
        ):
            bar.addWidget(b)
        bar.addStretch(1)
        self.page_layout.addLayout(bar)

        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(
            ["Backup ID", "Created (UTC)", "Category", "Description", "Items", "SHA-256 Integrity"]
        )
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(5, QHeaderView.ResizeMode.ResizeToContents)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.itemSelectionChanged.connect(self._load_selected_items)
        self.page_layout.addWidget(self.table, 2)

        self.items_hdr = SectionHeader("Backup Contents (select an item for individual restore)")
        self.page_layout.addWidget(self.items_hdr)

        self.items_list = QListWidget()
        self.page_layout.addWidget(self.items_list, 1)

    def on_page_activated(self) -> None:
        self._refresh()

    def retranslate_ui(self) -> None:
        self.snapshot_btn.setText(self.t("backup.create_snapshot"))
        self.verify_btn.setText(self.t("backup.verify"))
        self.restore_full_btn.setText(self.t("backup.restore_full"))
        self.restore_item_btn.setText(self.t("backup.restore_item"))
        self.refresh_btn.setText(self.t("common.refresh"))

    def _refresh(self) -> None:
        self._records = self.services.backup_manager.list_backups()
        self.table.setRowCount(len(self._records))
        for idx, rec in enumerate(self._records):
            self.table.setItem(idx, 0, QTableWidgetItem(rec.backup_id))
            self.table.setItem(idx, 1, QTableWidgetItem(rec.created_at[:19].replace("T", " ")))
            self.table.setItem(idx, 2, QTableWidgetItem(rec.category))
            self.table.setItem(idx, 3, QTableWidgetItem(rec.description))
            self.table.setItem(idx, 4, QTableWidgetItem(str(rec.item_count)))
            status = f"VALID ({rec.sha256[:10]}...)" if rec.verified else "CORRUPTED / TAMPERED"
            self.table.setItem(idx, 5, QTableWidgetItem(status))
        self.items_list.clear()

    def _selected_record(self) -> BackupRecord | None:
        row = self.table.currentRow()
        if 0 <= row < len(self._records):
            return self._records[row]
        QMessageBox.information(self, self.t("common.info"), "Select a backup record first.")
        return None

    def _load_selected_items(self) -> None:
        self.items_list.clear()
        row = self.table.currentRow()
        if not (0 <= row < len(self._records)):
            return
        rec = self._records[row]
        items = self.services.backup_manager.load_backup_items(rec.backup_id)
        for idx, item in enumerate(items):
            itype = item.get("item_type", "unknown")
            data = item.get("data", {})
            if itype == "registry":
                desc = f"[{idx}] REGISTRY {data.get('root')}\\{data.get('subkey')}\\{data.get('name')} = {data.get('value') if data.get('existed') else '(absent)'}"
            elif itype == "file":
                desc = f"[{idx}] FILE {data.get('original_path')}"
            else:
                desc = f"[{idx}] {itype.upper()} {data}"
            self.items_list.addItem(desc)

    def _create_snapshot(self) -> None:
        reg = self.services.backup_manager.registry
        gl_snaps = reg.list_values("HKCU", r"Software\Tencent\MobileGamePC")
        rec = self.services.backup_manager.create_backup(
            category="snapshot",
            description="Manual GameLoop Registry Snapshot",
            registry_snapshots=gl_snaps,
        )
        QMessageBox.information(
            self,
            self.t("common.success"),
            f"Snapshot created: {rec.backup_id}\nItems: {rec.item_count}\nSHA-256: {rec.sha256}",
        )
        self._refresh()

    def _verify_selected(self) -> None:
        rec = self._selected_record()
        if not rec:
            return
        valid, msg, _ = self.services.backup_manager.verify_backup(rec.backup_id)
        QMessageBox.information(self, self.t("common.success" if valid else "common.error"), msg)
        self._refresh()

    def _restore_full(self) -> None:
        rec = self._selected_record()
        if not rec:
            return
        ans = QMessageBox.question(
            self,
            self.t("common.confirm"),
            f"Restore ALL {rec.item_count} item(s) from backup '{rec.backup_id}'?",
        )
        if ans != QMessageBox.StandardButton.Yes:
            return
        ok, logs = self.services.backup_manager.restore_backup(rec.backup_id)
        QMessageBox.information(self, self.t("common.success" if ok else "common.warning"), "\n".join(logs))

    def _restore_single_item(self) -> None:
        rec = self._selected_record()
        if not rec:
            return
        item_idx = self.items_list.currentRow()
        if item_idx < 0:
            QMessageBox.information(self, self.t("common.info"), "Select a specific item from the list below first.")
            return
        ok, logs = self.services.backup_manager.restore_backup(rec.backup_id, item_indices=[item_idx])
        QMessageBox.information(self, self.t("common.success" if ok else "common.warning"), "\n".join(logs))
