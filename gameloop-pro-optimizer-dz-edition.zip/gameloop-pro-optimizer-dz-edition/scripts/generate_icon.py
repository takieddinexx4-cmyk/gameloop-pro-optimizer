"""Generate original DZ Edition vector SVG and multi-resolution ICO/PNG visual assets.

Generates:
  - assets/app_icon.ico           (multi-size Windows EXE & taskbar icon: 16..256px)
  - assets/app_icon.png           (256x256 square app icon)
  - assets/dz_logo_square.png     (512x512 high-res square DZ emblem)
  - assets/dz_logo_square.svg     (scalable vector square DZ emblem)
  - assets/dz_logo_small.png      (64x64 ultra-crisp simplified emblem for small UI chrome)
  - assets/dz_logo_horizontal.png (960x240 horizontal brand lockup)
  - assets/dz_logo_horizontal.svg (scalable vector horizontal brand lockup)
  - assets/dz_splash.png          (760x440 Liquid Glass splash screen hero artwork)

Uses Pillow supersampled vector drawing so builds require zero native Cairo DLLs.
"""

from __future__ import annotations

import math
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter, ImageFont

SQUARE_SVG = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
  <defs>
    <linearGradient id="bgGrad" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#071022"/>
      <stop offset="55%" stop-color="#0C1B38"/>
      <stop offset="100%" stop-color="#060D1C"/>
    </linearGradient>
    <linearGradient id="glassShine" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#FFFFFF" stop-opacity="0.22"/>
      <stop offset="45%" stop-color="#00E5FF" stop-opacity="0.06"/>
      <stop offset="100%" stop-color="#000000" stop-opacity="0.0"/>
    </linearGradient>
    <linearGradient id="dzAccent" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#00E5FF"/>
      <stop offset="50%" stop-color="#0095FF"/>
      <stop offset="100%" stop-color="#2563EB"/>
    </linearGradient>
    <linearGradient id="boltGrad" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#7DF9FF"/>
      <stop offset="100%" stop-color="#00C8FF"/>
    </linearGradient>
  </defs>
  <rect x="20" y="20" width="472" height="472" rx="108" fill="url(#bgGrad)" stroke="url(#dzAccent)" stroke-width="10"/>
  <rect x="34" y="34" width="444" height="218" rx="92" fill="url(#glassShine)"/>
  <polygon points="256,56 424,128 402,356 256,452 110,356 88,128" fill="#0B1830" fill-opacity="0.86" stroke="url(#dzAccent)" stroke-width="8"/>
  <polygon points="256,82 396,142 378,340 256,422 134,340 116,142" fill="none" stroke="#00E5FF" stroke-opacity="0.25" stroke-width="3"/>
  <!-- Geometric D -->
  <path d="M132,164 L214,164 L254,204 L254,308 L214,348 L132,348 Z M166,196 L166,316 L202,316 L220,298 L220,214 L202,196 Z" fill="url(#dzAccent)"/>
  <!-- Geometric Z with speed slash -->
  <polygon points="266,164 382,164 382,196 310,316 382,316 382,348 262,348 262,316 334,196 266,196" fill="url(#boltGrad)"/>
  <!-- Performance speed chevron -->
  <polygon points="246,112 266,112 256,142" fill="#00E5FF"/>
  <rect x="196" y="380" width="120" height="8" rx="4" fill="url(#dzAccent)"/>
</svg>
"""

HORIZONTAL_SVG = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 960 240">
  <defs>
    <linearGradient id="hBg" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#071022"/>
      <stop offset="100%" stop-color="#0E1D3B"/>
    </linearGradient>
    <linearGradient id="hAccent" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0%" stop-color="#00E5FF"/>
      <stop offset="100%" stop-color="#0088FF"/>
    </linearGradient>
  </defs>
  <rect x="6" y="6" width="948" height="228" rx="34" fill="url(#hBg)" stroke="url(#hAccent)" stroke-opacity="0.45" stroke-width="3"/>
  <g transform="translate(26,24) scale(0.375)">
    <rect x="20" y="20" width="472" height="472" rx="108" fill="#0A162D" stroke="url(#hAccent)" stroke-width="14"/>
    <polygon points="256,58 422,128 400,354 256,450 112,354 90,128" fill="#0D1E3C" stroke="#00E5FF" stroke-width="10"/>
    <path d="M132,164 L214,164 L254,204 L254,308 L214,348 L132,348 Z M166,196 L166,316 L202,316 L220,298 L220,214 L202,196 Z" fill="url(#hAccent)"/>
    <polygon points="266,164 382,164 382,196 310,316 382,316 382,348 262,348 262,316 334,196 266,196" fill="#7DF9FF"/>
  </g>
  <text x="248" y="106" fill="#F8FAFC" font-family="Segoe UI, Arial, sans-serif" font-size="42" font-weight="800" letter-spacing="2">GAMELOOP PRO OPTIMIZER</text>
  <rect x="248" y="132" width="186" height="42" rx="12" fill="#0095FF" fill-opacity="0.22" stroke="#00E5FF" stroke-width="2"/>
  <text x="341" y="160" text-anchor="middle" fill="#00E5FF" font-family="Segoe UI, Arial, sans-serif" font-size="22" font-weight="800" letter-spacing="3">DZ EDITION</text>
  <text x="456" y="160" fill="#94A3B8" font-family="Segoe UI, Arial, sans-serif" font-size="20" font-weight="600">LIQUID GLASS PERFORMANCE SUITE</text>
</svg>
"""


def _load_font(size: int, bold: bool = True) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    candidates = (
        [
            "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
            "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
            "C:/Windows/Fonts/segoeuib.ttf",
            "C:/Windows/Fonts/arialbd.ttf",
        ]
        if bold
        else [
            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
            "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
            "C:/Windows/Fonts/segoeui.ttf",
            "C:/Windows/Fonts/arial.ttf",
        ]
    )
    for path in candidates:
        if Path(path).exists():
            try:
                return ImageFont.truetype(path, size)
            except OSError:
                continue
    return ImageFont.load_default()


def _create_gradient(size: tuple[int, int], top_rgb: tuple[int, int, int], bottom_rgb: tuple[int, int, int]) -> Image.Image:
    w, h = size
    base = Image.new("RGBA", (w, h))
    draw = ImageDraw.Draw(base)
    for y in range(h):
        t = y / max(1, h - 1)
        r = int(top_rgb[0] + (bottom_rgb[0] - top_rgb[0]) * t)
        g = int(top_rgb[1] + (bottom_rgb[1] - top_rgb[1]) * t)
        b = int(top_rgb[2] + (bottom_rgb[2] - top_rgb[2]) * t)
        draw.line([(0, y), (w, y)], fill=(r, g, b, 255))
    return base


def _render_dz_emblem(size: int = 1024, simplified: bool = False) -> Image.Image:
    """Render high-resolution anti-aliased DZ geometric gaming emblem."""
    s = size / 512.0
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))

    # Base rounded squircle mask
    pad = int(20 * s)
    radius = int(108 * s)
    bg_grad = _create_gradient((size, size), (8, 18, 38), (5, 11, 24))
    mask = Image.new("L", (size, size), 0)
    ImageDraw.Draw(mask).rounded_rectangle([pad, pad, size - pad, size - pad], radius=radius, fill=255)
    img.paste(bg_grad, (0, 0), mask)

    # Ambient cyan radial glow behind DZ
    glow = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    gdraw = ImageDraw.Draw(glow)
    gdraw.ellipse([110 * s, 96 * s, 402 * s, 388 * s], fill=(0, 180, 255, 62))
    glow = glow.filter(ImageFilter.GaussianBlur(radius=max(2, int(36 * s))))
    img = Image.alpha_composite(img, glow)

    draw = ImageDraw.Draw(img)

    # Outer Liquid Glass rim
    draw.rounded_rectangle(
        [pad, pad, size - pad, size - pad],
        radius=radius,
        outline=(0, 212, 255, 225),
        width=max(2, int((14 if simplified else 10) * s)),
    )

    if not simplified:
        # Top glass specular reflection crescent
        shine = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        sdraw = ImageDraw.Draw(shine)
        sdraw.rounded_rectangle(
            [int(36 * s), int(34 * s), int(476 * s), int(230 * s)],
            radius=int(88 * s),
            fill=(255, 255, 255, 22),
        )
        shine = shine.filter(ImageFilter.GaussianBlur(radius=max(1, int(8 * s))))
        img = Image.alpha_composite(img, shine)
        draw = ImageDraw.Draw(img)

    # Hexagonal tactical shield
    shield = [
        (256 * s, 56 * s),
        (424 * s, 128 * s),
        (402 * s, 356 * s),
        (256 * s, 452 * s),
        (110 * s, 356 * s),
        (88 * s, 128 * s),
    ]
    draw.polygon(shield, fill=(10, 24, 48, 228))
    stroke_w = max(2, int((11 if simplified else 8) * s))
    for i in range(len(shield)):
        p1 = shield[i]
        p2 = shield[(i + 1) % len(shield)]
        col = (0, 229, 255, 245) if i in (0, 1, 5) else (0, 136, 255, 235)
        draw.line([p1, p2], fill=col, width=stroke_w)

    if not simplified:
        inner_shield = [
            (256 * s, 82 * s),
            (396 * s, 142 * s),
            (378 * s, 340 * s),
            (256 * s, 422 * s),
            (134 * s, 340 * s),
            (116 * s, 142 * s),
        ]
        for i in range(len(inner_shield)):
            draw.line(
                [inner_shield[i], inner_shield[(i + 1) % len(inner_shield)]],
                fill=(0, 229, 255, 65),
                width=max(1, int(3 * s)),
            )

    # Geometric 'D' (left half, GameLoop electric blue -> cyan)
    d_outer = [
        (126 * s, 162 * s),
        (216 * s, 162 * s),
        (254 * s, 200 * s),
        (254 * s, 312 * s),
        (216 * s, 350 * s),
        (126 * s, 350 * s),
    ]
    d_inner = [
        (162 * s, 196 * s),
        (202 * s, 196 * s),
        (218 * s, 212 * s),
        (218 * s, 300 * s),
        (202 * s, 316 * s),
        (162 * s, 316 * s),
    ]
    draw.polygon(d_outer, fill=(0, 158, 255, 255))
    draw.polygon(d_inner, fill=(10, 24, 48, 255))

    # Geometric 'Z' (right half, bright neon cyan with sharp speed angle)
    z_poly = [
        (268 * s, 162 * s),
        (386 * s, 162 * s),
        (386 * s, 196 * s),
        (312 * s, 316 * s),
        (386 * s, 316 * s),
        (386 * s, 350 * s),
        (262 * s, 350 * s),
        (262 * s, 316 * s),
        (336 * s, 196 * s),
        (268 * s, 196 * s),
    ]
    draw.polygon(z_poly, fill=(0, 232, 255, 255))

    # Speed accent bar & top chevron
    draw.rounded_rectangle(
        [int(188 * s), int(382 * s), int(324 * s), int(394 * s)],
        radius=max(2, int(6 * s)),
        fill=(0, 229, 255, 230),
    )
    draw.polygon(
        [(244 * s, 114 * s), (268 * s, 114 * s), (256 * s, 140 * s)],
        fill=(125, 249, 255, 240),
    )

    if not simplified:
        # Precision tech corner ticks
        for angle_deg in (30, 150, 210, 330):
            rad = math.radians(angle_deg)
            px = 256 * s + math.cos(rad) * 176 * s
            py = 256 * s + math.sin(rad) * 176 * s
            r = max(2, int(4 * s))
            draw.ellipse([px - r, py - r, px + r, py + r], fill=(0, 229, 255, 190))

    return img


def _render_horizontal_logo(emblem_hi: Image.Image) -> Image.Image:
    w, h = 960, 240
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))

    bg = _create_gradient((w, h), (9, 19, 40), (14, 29, 58))
    mask = Image.new("L", (w, h), 0)
    ImageDraw.Draw(mask).rounded_rectangle([6, 6, w - 6, h - 6], radius=34, fill=255)
    img.paste(bg, (0, 0), mask)

    draw = ImageDraw.Draw(img)
    draw.rounded_rectangle([6, 6, w - 6, h - 6], radius=34, outline=(0, 212, 255, 125), width=3)

    emblem_small = emblem_hi.resize((184, 184), Image.Resampling.LANCZOS)
    img.paste(emblem_small, (28, 28), emblem_small)

    font_title = _load_font(42, bold=True)
    font_badge = _load_font(22, bold=True)
    font_sub = _load_font(20, bold=False)

    draw.text((242, 62), "GAMELOOP PRO OPTIMIZER", font=font_title, fill=(248, 250, 252, 255))

    # DZ EDITION pill
    draw.rounded_rectangle([242, 130, 428, 174], radius=12, fill=(9, 36, 74, 240), outline=(0, 229, 255, 220), width=2)
    draw.text((266, 139), "DZ EDITION", font=font_badge, fill=(0, 232, 255, 255))
    draw.text((448, 140), "LIQUID GLASS PERFORMANCE SUITE", font=font_sub, fill=(148, 163, 184, 255))

    return img


def _render_splash_banner(emblem_hi: Image.Image) -> Image.Image:
    w, h = 760, 440
    img = _create_gradient((w, h), (6, 12, 26), (11, 23, 46))

    # Soft cyan & deep blue ambient light orbs
    orbs = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    odraw = ImageDraw.Draw(orbs)
    odraw.ellipse([40, 20, 340, 320], fill=(0, 136, 255, 48))
    odraw.ellipse([440, 120, 740, 420], fill=(0, 229, 255, 40))
    orbs = orbs.filter(ImageFilter.GaussianBlur(radius=60))
    img = Image.alpha_composite(img, orbs)

    # Frosted inner glass card
    card = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    cdraw = ImageDraw.Draw(card)
    cdraw.rounded_rectangle([24, 24, w - 24, h - 24], radius=28, fill=(14, 25, 48, 185), outline=(120, 215, 255, 72), width=2)
    img = Image.alpha_composite(img, card)

    emblem = emblem_hi.resize((144, 144), Image.Resampling.LANCZOS)
    img.paste(emblem, ((w - 144) // 2, 54), emblem)

    draw = ImageDraw.Draw(img)
    f_title = _load_font(30, bold=True)
    f_edition = _load_font(18, bold=True)
    f_tag = _load_font(15, bold=False)

    title_text = "GAMELOOP PRO OPTIMIZER"
    tb = draw.textbbox((0, 0), title_text, font=f_title)
    draw.text(((w - (tb[2] - tb[0])) // 2, 216), title_text, font=f_title, fill=(248, 250, 252, 255))

    pill_w = 176
    px0 = (w - pill_w) // 2
    draw.rounded_rectangle([px0, 264, px0 + pill_w, 298], radius=12, fill=(9, 36, 74, 240), outline=(0, 229, 255, 220), width=2)
    ed_text = "DZ EDITION"
    eb = draw.textbbox((0, 0), ed_text, font=f_edition)
    draw.text(((w - (eb[2] - eb[0])) // 2, 270), ed_text, font=f_edition, fill=(0, 232, 255, 255))

    sub_text = "Premium Liquid Glass Diagnostics, Process & Performance Suite"
    sb = draw.textbbox((0, 0), sub_text, font=f_tag)
    draw.text(((w - (sb[2] - sb[0])) // 2, 316), sub_text, font=f_tag, fill=(148, 163, 184, 255))

    return img


def generate_assets(output_dir: Path) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)

    (output_dir / "app_icon.svg").write_text(SQUARE_SVG, encoding="utf-8")
    (output_dir / "dz_logo_square.svg").write_text(SQUARE_SVG, encoding="utf-8")
    (output_dir / "dz_logo_horizontal.svg").write_text(HORIZONTAL_SVG, encoding="utf-8")

    hi_res = _render_dz_emblem(1024, simplified=False)
    small_hi = _render_dz_emblem(512, simplified=True)

    hi_res.resize((512, 512), Image.Resampling.LANCZOS).save(output_dir / "dz_logo_square.png", format="PNG")
    hi_res.resize((256, 256), Image.Resampling.LANCZOS).save(output_dir / "app_icon.png", format="PNG")
    small_hi.resize((64, 64), Image.Resampling.LANCZOS).save(output_dir / "dz_logo_small.png", format="PNG")

    # Multi-resolution ICO for Windows EXE & taskbar
    ico_sizes = [(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)]
    small_hi.save(output_dir / "app_icon.ico", format="ICO", sizes=ico_sizes)

    horiz = _render_horizontal_logo(hi_res)
    horiz.save(output_dir / "dz_logo_horizontal.png", format="PNG")

    splash = _render_splash_banner(hi_res)
    splash.save(output_dir / "dz_splash.png", format="PNG")

    print(f"[OK] Generated DZ Edition visual assets in {output_dir}")


if __name__ == "__main__":
    root = Path(__file__).resolve().parent.parent
    generate_assets(root / "assets")
