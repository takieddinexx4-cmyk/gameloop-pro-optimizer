"""Ultra-lightweight rolling line chart built with QPainter (zero heavy dependencies)."""

from __future__ import annotations

from collections import deque

from PySide6.QtCore import QPointF, Qt
from PySide6.QtGui import QColor, QLinearGradient, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import QWidget


class RollingLineChart(QWidget):
    def __init__(
        self,
        title: str = "",
        color_hex: str = "#00D4FF",
        max_points: int = 60,
        y_max: float = 100.0,
        unit: str = "%",
        parent=None,
    ) -> None:
        super().__init__(parent)
        self._title = title
        self._color = QColor(color_hex)
        self._max_points = max(10, max_points)
        self._y_max = max(1.0, y_max)
        self._unit = unit
        self._values: deque[float | None] = deque(maxlen=self._max_points)
        self.setMinimumHeight(130)

    def set_window_size(self, max_points: int) -> None:
        new_deque: deque[float | None] = deque(self._values, maxlen=max(10, max_points))
        self._max_points = max(10, max_points)
        self._values = new_deque
        self.update()

    def set_title(self, title: str) -> None:
        self._title = title
        self.update()

    def push_value(self, value: float | None) -> None:
        self._values.append(value)
        self.update()

    def paintEvent(self, event) -> None:  # noqa: N802 - Qt override
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)

        rect = self.rect().adjusted(6, 6, -6, -6)
        painter.setPen(QPen(QColor(255, 255, 255, 24), 1))
        painter.setBrush(QColor(15, 23, 42, 230))
        painter.drawRoundedRect(rect, 10, 10)

        plot = rect.adjusted(12, 28, -12, -12)

        # Horizontal gridlines
        grid_pen = QPen(QColor(255, 255, 255, 18), 1, Qt.PenStyle.DashLine)
        painter.setPen(grid_pen)
        for frac in (0.25, 0.5, 0.75):
            y = plot.top() + plot.height() * frac
            painter.drawLine(int(plot.left()), int(y), int(plot.right()), int(y))

        # Title and latest value
        latest = self._values[-1] if self._values else None
        latest_text = f"{latest:.1f}{self._unit}" if latest is not None else "--"
        painter.setPen(QColor("#CBD5E1"))
        painter.drawText(rect.adjusted(12, 6, -12, 0), Qt.AlignmentFlag.AlignLeft, self._title)
        painter.setPen(self._color)
        painter.drawText(rect.adjusted(12, 6, -12, 0), Qt.AlignmentFlag.AlignRight, latest_text)

        valid_points = [(i, v) for i, v in enumerate(self._values) if v is not None]
        if len(valid_points) < 2:
            painter.end()
            return

        step_x = plot.width() / max(1, self._max_points - 1)
        offset = self._max_points - len(self._values)

        pts: list[QPointF] = []
        for idx, val in valid_points:
            clamped = max(0.0, min(self._y_max, float(val)))
            x = plot.left() + (offset + idx) * step_x
            y = plot.bottom() - (clamped / self._y_max) * plot.height()
            pts.append(QPointF(x, y))

        line_path = QPainterPath()
        line_path.moveTo(pts[0])
        for pt in pts[1:]:
            line_path.lineTo(pt)

        # Subtle area fill under curve
        fill_path = QPainterPath(line_path)
        fill_path.lineTo(QPointF(pts[-1].x(), plot.bottom()))
        fill_path.lineTo(QPointF(pts[0].x(), plot.bottom()))
        fill_path.closeSubpath()

        gradient = QLinearGradient(0, plot.top(), 0, plot.bottom())
        top_color = QColor(self._color)
        top_color.setAlpha(75)
        bottom_color = QColor(self._color)
        bottom_color.setAlpha(5)
        gradient.setColorAt(0.0, top_color)
        gradient.setColorAt(1.0, bottom_color)
        painter.fillPath(fill_path, gradient)

        painter.setPen(QPen(self._color, 2))
        painter.drawPath(line_path)
        painter.end()
