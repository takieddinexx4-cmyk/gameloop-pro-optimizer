"""Crash, stuttering, lag, Event Log, and GameLoop log diagnostics."""
