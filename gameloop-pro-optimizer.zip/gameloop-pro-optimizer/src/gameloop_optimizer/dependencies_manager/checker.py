"""Inspects required Windows gaming runtimes without silent installations."""

from __future__ import annotations

import os
import sys
import webbrowser
from pathlib import Path

from gameloop_optimizer.app_core.models import DependencyStatus
from gameloop_optimizer.backup_restore.registry_io import RegistryBackend, WindowsRegistryBackend

_OFFICIAL_VC_URL = "https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist"
_OFFICIAL_DX_URL = "https://www.microsoft.com/en-us/download/details.aspx?id=35"
_OFFICIAL_DOTNET_URL = "https://dotnet.microsoft.com/en-us/download/dotnet-framework"


class DependenciesChecker:
    def __init__(self, registry: RegistryBackend | None = None) -> None:
        self._reg = registry or WindowsRegistryBackend()

    def check_all(self, progress_cb=None, cancel_token=None) -> list[DependencyStatus]:
        results: list[DependencyStatus] = []
        if progress_cb:
            progress_cb(20, "Checking Visual C++ Redistributables...")
        results.append(self._check_vc_redist("x64"))
        results.append(self._check_vc_redist("x86"))

        if progress_cb:
            progress_cb(55, "Checking DirectX runtime files...")
        results.append(self._check_directx())

        if progress_cb:
            progress_cb(80, "Checking .NET Framework & Virtualization status...")
        results.append(self._check_dotnet())
        results.append(self._check_virtualization_readonly())

        if progress_cb:
            progress_cb(100, "Dependency check complete.")
        return results

    def _check_vc_redist(self, arch: str) -> DependencyStatus:
        keys = (
            [r"SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\x64"]
            if arch == "x64"
            else [
                r"SOFTWARE\WOW6432Node\Microsoft\VisualStudio\14.0\VC\Runtimes\x86",
                r"SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\x86",
            ]
        )
        for subkey in keys:
            inst = self._reg.read_value("HKLM", subkey, "Installed")
            ver = self._reg.read_value("HKLM", subkey, "Version")
            if inst.existed and inst.value == 1:
                return DependencyStatus(
                    dep_id=f"vcredist_{arch}",
                    name=f"Microsoft Visual C++ 2015-2022 Redistributable ({arch})",
                    installed=True,
                    version=str(ver.value) if ver.existed else "Installed",
                    details="Detected via Windows Registry.",
                    official_url=_OFFICIAL_VC_URL,
                    status_level="ok",
                )
        return DependencyStatus(
            dep_id=f"vcredist_{arch}",
            name=f"Microsoft Visual C++ 2015-2022 Redistributable ({arch})",
            installed=False,
            version="Missing",
            details="Not detected in Registry. GameLoop requires both x86 and x64 VC++ runtimes.",
            official_url=_OFFICIAL_VC_URL,
            status_level="missing",
        )

    def _check_directx(self) -> DependencyStatus:
        dx_ver = self._reg.read_value("HKLM", r"SOFTWARE\Microsoft\DirectX", "Version")
        sys_root = Path(os.environ.get("SystemRoot", r"C:\Windows"))
        d3d11 = (sys_root / "System32" / "d3d11.dll").is_file()
        d3d12 = (sys_root / "System32" / "d3d12.dll").is_file()

        if dx_ver.existed or d3d11:
            features = []
            if d3d11:
                features.append("D3D11")
            if d3d12:
                features.append("D3D12")
            return DependencyStatus(
                dep_id="directx",
                name="DirectX Graphics Runtime",
                installed=True,
                version=str(dx_ver.value) if dx_ver.existed else "Present",
                details=f"Detected libraries: {', '.join(features) if features else 'Registry entry found'}.",
                official_url=_OFFICIAL_DX_URL,
                status_level="ok",
            )
        return DependencyStatus(
            dep_id="directx",
            name="DirectX Graphics Runtime",
            installed=False,
            version="Unavailable",
            details="DirectX runtime could not be verified on this OS.",
            official_url=_OFFICIAL_DX_URL,
            status_level="warning",
        )

    def _check_dotnet(self) -> DependencyStatus:
        rel = self._reg.read_value("HKLM", r"SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full", "Release")
        if rel.existed and isinstance(rel.value, int) and rel.value >= 528040:
            return DependencyStatus(
                dep_id="dotnet48",
                name=".NET Framework 4.8+",
                installed=True,
                version=f"Release {rel.value}",
                details="Up-to-date .NET Framework 4.8+ detected.",
                official_url=_OFFICIAL_DOTNET_URL,
                status_level="ok",
            )
        if rel.existed:
            return DependencyStatus(
                dep_id="dotnet48",
                name=".NET Framework 4.x",
                installed=True,
                version=f"Release {rel.value}",
                details="Older .NET 4.x build detected; 4.8+ is recommended.",
                official_url=_OFFICIAL_DOTNET_URL,
                status_level="warning",
            )
        return DependencyStatus(
            dep_id="dotnet48",
            name=".NET Framework 4.8+",
            installed=False,
            version="Unavailable",
            details="Registry entry not found (only applicable on Windows).",
            official_url=_OFFICIAL_DOTNET_URL,
            status_level="info",
        )

    @staticmethod
    def _check_virtualization_readonly() -> DependencyStatus:
        """Read-only informational check for VT-x/AMD-V without altering security settings."""
        if sys.platform != "win32":
            return DependencyStatus(
                dep_id="virtualization",
                name="Hardware Virtualization (VT-x / AMD-V)",
                installed=False,
                version="Unavailable",
                details="Virtualization status check requires Windows WMI.",
                status_level="info",
            )
        try:
            import pythoncom
            import wmi

            pythoncom.CoInitialize()
            try:
                cpus = wmi.WMI().Win32_Processor()
                enabled = bool(getattr(cpus[0], "VirtualizationFirmwareEnabled", False)) if cpus else False
                return DependencyStatus(
                    dep_id="virtualization",
                    name="Hardware Virtualization (VT-x / AMD-V)",
                    installed=enabled,
                    version="Enabled" if enabled else "Disabled / Hidden by Hypervisor",
                    details=(
                        "Firmware virtualization is enabled."
                        if enabled
                        else "Enable VT-x/AMD-V in BIOS/UEFI for emulator stability (never disable Windows Defender)."
                    ),
                    status_level="ok" if enabled else "warning",
                )
            finally:
                pythoncom.CoUninitialize()
        except Exception as exc:  # noqa: BLE001
            return DependencyStatus(
                dep_id="virtualization",
                name="Hardware Virtualization (VT-x / AMD-V)",
                installed=False,
                version="Unavailable",
                details=f"Could not query WMI virtualization state: {exc}",
                status_level="info",
            )

    @staticmethod
    def open_official_download(url: str) -> tuple[bool, str]:
        if not url.startswith("https://"):
            return False, "Only official HTTPS URLs are allowed."
        webbrowser.open(url)
        return True, f"Opened official page: {url}"
