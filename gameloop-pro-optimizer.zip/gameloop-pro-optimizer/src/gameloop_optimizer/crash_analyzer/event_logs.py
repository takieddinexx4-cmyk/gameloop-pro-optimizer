"""Read-only Windows Event Log scanner for GameLoop and GPU driver crashes."""

from __future__ import annotations

import sys
from dataclasses import dataclass

from gameloop_optimizer.logging.logger import get_logger

logger = get_logger("crash_analyzer.event_logs")

_GAMELOOP_KEYWORDS = ("androidemulator", "appmarket", "txgameassistant", "aow_exe", "gameloop")
_GPU_DRIVER_KEYWORDS = ("nvlddmkm", "amdkmdag", "igdkmd", "dxgkrnl", "display driver")


@dataclass
class EventLogHit:
    channel: str
    source: str
    event_id: int
    time_generated: str
    message_excerpt: str
    category: str  # gameloop_crash | gpu_driver_crash


def scan_windows_event_logs(max_events_per_log: int = 120) -> tuple[list[EventLogHit], str]:
    """Inspect recent Application and System error events without shell commands."""
    if sys.platform != "win32":
        return [], "Windows Event Log is only available on Windows."
    try:
        import win32evtlog
        import win32evtlogutil
    except ImportError:
        return [], "pywin32 event log module is unavailable."

    hits: list[EventLogHit] = []
    flags = win32evtlog.EVENTLOG_BACKWARDS_READ | win32evtlog.EVENTLOG_SEQUENTIAL_READ
    notes: list[str] = []

    for channel in ("Application", "System"):
        hand = None
        try:
            hand = win32evtlog.OpenEventLog(None, channel)
            scanned = 0
            while scanned < max_events_per_log:
                events = win32evtlog.ReadEventLog(hand, flags, 0)
                if not events:
                    break
                for ev in events:
                    scanned += 1
                    if scanned > max_events_per_log:
                        break
                    # EventType 1 = Error, 2 = Warning
                    if ev.EventType not in (1, 2):
                        continue
                    source = str(ev.SourceName or "")
                    try:
                        msg = win32evtlogutil.SafeFormatMessage(ev, channel) or ""
                    except Exception:  # noqa: BLE001
                        msg = " ".join(str(s) for s in (ev.StringInserts or ()))
                    combined = f"{source} {msg}".lower()

                    cat = ""
                    if any(k in combined for k in _GAMELOOP_KEYWORDS):
                        cat = "gameloop_crash"
                    elif any(k in combined for k in _GPU_DRIVER_KEYWORDS):
                        cat = "gpu_driver_crash"

                    if cat:
                        hits.append(
                            EventLogHit(
                                channel=channel,
                                source=source,
                                event_id=int(ev.EventID & 0xFFFF),
                                time_generated=str(ev.TimeGenerated),
                                message_excerpt=msg.strip().replace("\r\n", " ")[:240],
                                category=cat,
                            )
                        )
        except PermissionError:
            notes.append(f"Access denied reading '{channel}' event log.")
        except Exception as exc:  # noqa: BLE001
            notes.append(f"Could not read '{channel}' log: {exc}")
        finally:
            if hand is not None:
                try:
                    win32evtlog.CloseEventLog(hand)
                except Exception:  # noqa: BLE001
                    pass

    return hits, "; ".join(notes)
