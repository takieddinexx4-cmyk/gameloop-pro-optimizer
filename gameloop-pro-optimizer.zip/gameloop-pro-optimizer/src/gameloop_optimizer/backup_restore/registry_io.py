"""Safe Windows Registry abstraction with in-memory test backend."""

from __future__ import annotations

import sys
from dataclasses import dataclass
from typing import Any, Protocol

REG_SZ = 1
REG_EXPAND_SZ = 2
REG_BINARY = 3
REG_DWORD = 4
REG_QWORD = 11


@dataclass
class RegistryValueSnapshot:
    root: str  # "HKCU" or "HKLM"
    subkey: str
    name: str
    existed: bool
    value: Any = None
    reg_type: int = REG_SZ


class RegistryBackend(Protocol):
    def read_value(self, root: str, subkey: str, name: str) -> RegistryValueSnapshot: ...

    def write_value(
        self, root: str, subkey: str, name: str, value: Any, reg_type: int
    ) -> tuple[bool, str]: ...

    def delete_value(self, root: str, subkey: str, name: str) -> tuple[bool, str]: ...

    def list_values(self, root: str, subkey: str) -> list[RegistryValueSnapshot]: ...


class WindowsRegistryBackend:
    """Real winreg backend for Windows (never runs shell commands)."""

    @staticmethod
    def _resolve_root(root: str):
        import winreg

        mapping = {
            "HKCU": winreg.HKEY_CURRENT_USER,
            "HKLM": winreg.HKEY_LOCAL_MACHINE,
        }
        if root not in mapping:
            raise ValueError(f"Unsupported registry hive: {root}")
        return mapping[root]

    def read_value(self, root: str, subkey: str, name: str) -> RegistryValueSnapshot:
        if sys.platform != "win32":
            return RegistryValueSnapshot(root=root, subkey=subkey, name=name, existed=False)
        import winreg

        hive = self._resolve_root(root)
        try:
            with winreg.OpenKey(hive, subkey, 0, winreg.KEY_READ) as key:
                val, reg_type = winreg.QueryValueEx(key, name)
                return RegistryValueSnapshot(
                    root=root, subkey=subkey, name=name, existed=True, value=val, reg_type=reg_type
                )
        except FileNotFoundError:
            return RegistryValueSnapshot(root=root, subkey=subkey, name=name, existed=False)
        except OSError:
            return RegistryValueSnapshot(root=root, subkey=subkey, name=name, existed=False)

    def write_value(
        self, root: str, subkey: str, name: str, value: Any, reg_type: int
    ) -> tuple[bool, str]:
        if sys.platform != "win32":
            return False, "Windows Registry is only available on Windows."
        import winreg

        hive = self._resolve_root(root)
        try:
            with winreg.CreateKeyEx(hive, subkey, 0, winreg.KEY_SET_VALUE) as key:
                winreg.SetValueEx(key, name, 0, reg_type, value)
            return True, "OK"
        except PermissionError:
            return False, f"Administrator privileges required to modify {root}\\{subkey}."
        except OSError as exc:
            return False, str(exc)

    def delete_value(self, root: str, subkey: str, name: str) -> tuple[bool, str]:
        if sys.platform != "win32":
            return False, "Windows Registry is only available on Windows."
        import winreg

        hive = self._resolve_root(root)
        try:
            with winreg.OpenKey(hive, subkey, 0, winreg.KEY_SET_VALUE) as key:
                winreg.DeleteValue(key, name)
            return True, "Deleted"
        except FileNotFoundError:
            return True, "Already absent"
        except PermissionError:
            return False, f"Administrator privileges required to delete {root}\\{subkey}\\{name}."
        except OSError as exc:
            return False, str(exc)

    def list_values(self, root: str, subkey: str) -> list[RegistryValueSnapshot]:
        if sys.platform != "win32":
            return []
        import winreg

        hive = self._resolve_root(root)
        results: list[RegistryValueSnapshot] = []
        try:
            with winreg.OpenKey(hive, subkey, 0, winreg.KEY_READ) as key:
                idx = 0
                while True:
                    try:
                        name, val, rtype = winreg.EnumValue(key, idx)
                        results.append(
                            RegistryValueSnapshot(
                                root=root, subkey=subkey, name=name, existed=True, value=val, reg_type=rtype
                            )
                        )
                        idx += 1
                    except OSError:
                        break
        except OSError:
            pass
        return results


class InMemoryRegistryBackend:
    """Deterministic in-memory registry store used for unit tests."""

    def __init__(self, initial: dict[tuple[str, str, str], tuple[Any, int]] | None = None) -> None:
        self._store: dict[tuple[str, str, str], tuple[Any, int]] = dict(initial or {})
        self.require_admin_hklm: bool = False
        self.is_admin: bool = True

    def read_value(self, root: str, subkey: str, name: str) -> RegistryValueSnapshot:
        key = (root, subkey, name)
        if key not in self._store:
            return RegistryValueSnapshot(root=root, subkey=subkey, name=name, existed=False)
        val, rtype = self._store[key]
        return RegistryValueSnapshot(
            root=root, subkey=subkey, name=name, existed=True, value=val, reg_type=rtype
        )

    def write_value(
        self, root: str, subkey: str, name: str, value: Any, reg_type: int
    ) -> tuple[bool, str]:
        if root == "HKLM" and self.require_admin_hklm and not self.is_admin:
            return False, "Administrator privileges required for HKLM."
        self._store[(root, subkey, name)] = (value, reg_type)
        return True, "OK"

    def delete_value(self, root: str, subkey: str, name: str) -> tuple[bool, str]:
        if root == "HKLM" and self.require_admin_hklm and not self.is_admin:
            return False, "Administrator privileges required for HKLM."
        self._store.pop((root, subkey, name), None)
        return True, "Deleted"

    def list_values(self, root: str, subkey: str) -> list[RegistryValueSnapshot]:
        out: list[RegistryValueSnapshot] = []
        for (r, sk, name), (val, rtype) in self._store.items():
            if r == root and sk == subkey:
                out.append(
                    RegistryValueSnapshot(
                        root=r, subkey=sk, name=name, existed=True, value=val, reg_type=rtype
                    )
                )
        return out
