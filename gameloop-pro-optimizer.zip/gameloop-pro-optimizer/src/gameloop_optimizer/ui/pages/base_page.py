"""Base class for all pages providing translation and background task execution."""

from __future__ import annotations

from typing import Any, Callable

from PySide6.QtWidgets import QMessageBox, QVBoxLayout, QWidget

from gameloop_optimizer.app_core.service_container import ServiceContainer
from gameloop_optimizer.app_core.workers import WorkerThread
from gameloop_optimizer.ui.widgets.dialogs import ProgressDialog


class BasePage(QWidget):
    def __init__(self, services: ServiceContainer, parent=None) -> None:
        super().__init__(parent)
        self.services = services
        self._active_workers: list[WorkerThread] = []

        self.page_layout = QVBoxLayout(self)
        self.page_layout.setContentsMargins(20, 18, 20, 18)
        self.page_layout.setSpacing(14)

    def t(self, key: str, **kwargs: object) -> str:
        return self.services.translator.t(key, **kwargs)

    def retranslate_ui(self) -> None:
        """Override in subclasses to refresh translated texts dynamically."""

    def on_page_activated(self) -> None:
        """Override in subclasses to refresh view when navigated to."""

    def shutdown(self) -> None:
        """Gracefully cancel running workers on application exit."""
        for worker in list(self._active_workers):
            worker.cancel()
            worker.wait(1500)

    def run_background_task(
        self,
        title: str,
        fn: Callable[..., Any],
        on_success: Callable[[Any], None],
        on_error: Callable[[str], None] | None = None,
        *args: Any,
        **kwargs: Any,
    ) -> None:
        dialog = ProgressDialog(title, self.t("common.cancel"), parent=self)
        worker = WorkerThread(fn, *args, **kwargs)
        self._active_workers.append(worker)

        def cleanup() -> None:
            if worker in self._active_workers:
                self._active_workers.remove(worker)
            dialog.accept()
            worker.deleteLater()

        def handle_success(result: Any) -> None:
            cleanup()
            on_success(result)

        def handle_failure(err: str) -> None:
            cleanup()
            if on_error:
                on_error(err)
            else:
                QMessageBox.warning(self, self.t("common.error"), err)

        def handle_cancel() -> None:
            cleanup()

        worker.progress.connect(dialog.update_progress)
        worker.finished_result.connect(handle_success)
        worker.failed.connect(handle_failure)
        worker.cancelled.connect(handle_cancel)
        dialog.cancel_btn.clicked.connect(worker.cancel)

        worker.start()
        dialog.exec()
