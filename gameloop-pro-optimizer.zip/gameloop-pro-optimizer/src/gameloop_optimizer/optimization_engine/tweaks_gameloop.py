"""Safe, reversible GameLoop-specific GPU preference and compatibility tweaks."""

from __future__ import annotations

from gameloop_optimizer.app_core.models import TweakActionResult, TweakState
from gameloop_optimizer.backup_restore.manager import BackupManager
from gameloop_optimizer.backup_restore.registry_io import REG_SZ, RegistryBackend
from gameloop_optimizer.gameloop_manager.discovery import GameLoopDiscovery
from gameloop_optimizer.logging.audit import AuditLogger
from gameloop_optimizer.optimization_engine.tweaks_base import BaseTweak


class GameLoopGpuPreferenceTweak(BaseTweak):
    tweak_id = "gameloop_gpu_preference"
    name = "Assign High-Performance GPU to GameLoop"
    category = "safe"
    risk_level = "low"
    requires_admin = False
    description = "Configures official Windows Graphics Settings (HKCU) to run GameLoop on the discrete/high-performance GPU."
    proposed_display = "GpuPreference=2; (High Performance)"

    _ROOT = "HKCU"
    _SUBKEY = r"Software\Microsoft\DirectX\UserGpuPreferences"

    def __init__(self, registry: RegistryBackend, discovery: GameLoopDiscovery) -> None:
        self._reg = registry
        self._discovery = discovery

    def _target_exe(self) -> str:
        info = self._discovery.discover()
        return info.emulator_exe if info.installed else ""

    def read_state(self) -> TweakState:
        exe = self._target_exe()
        if not exe:
            return TweakState(
                current_value="Unavailable",
                available=False,
                reason="GameLoop emulator executable not detected.",
            )
        snap = self._reg.read_value(self._ROOT, self._SUBKEY, exe)
        val = str(snap.value) if snap.existed else "System Default (Not Set)"
        optimized = snap.existed and "GpuPreference=2" in str(snap.value)
        return TweakState(current_value=val, available=True, is_optimized=optimized)

    def apply(self, backup_manager: BackupManager, audit_logger: AuditLogger) -> TweakActionResult:
        exe = self._target_exe()
        if not exe:
            return TweakActionResult(self.tweak_id, False, "GameLoop emulator executable not detected.")

        before_snap = self._reg.read_value(self._ROOT, self._SUBKEY, exe)
        record = backup_manager.create_backup(
            category="tweak",
            description=f"Backup before {self.tweak_id}",
            registry_snapshots=[before_snap],
        )
        target_val = "GpuPreference=2;"
        ok, msg = self._reg.write_value(self._ROOT, self._SUBKEY, exe, target_val, REG_SZ)
        if not ok:
            audit_logger.record("tweak_apply", self.tweak_id, before_snap.value, target_val, record.backup_id, False, msg)
            return TweakActionResult(self.tweak_id, False, msg, backup_id=record.backup_id)

        after_snap = self._reg.read_value(self._ROOT, self._SUBKEY, exe)
        verified = after_snap.existed and after_snap.value == target_val
        audit_logger.record(
            "tweak_apply", self.tweak_id, before_snap.value, after_snap.value, record.backup_id, verified
        )
        return TweakActionResult(
            tweak_id=self.tweak_id,
            success=verified,
            message="GameLoop assigned to High-Performance GPU." if verified else "Verification failed.",
            verified=verified,
            backup_id=record.backup_id,
            before_value=before_snap.value,
            after_value=after_snap.value,
        )


class GameLoopCompatibilityFlagsTweak(BaseTweak):
    tweak_id = "gameloop_fullscreen_dpi"
    name = "Disable Fullscreen Optimizations & Override High DPI"
    category = "advanced"
    risk_level = "low"
    requires_admin = False
    description = "Applies official Windows Compatibility flags (HKCU) to prevent DPI blur and DWM fullscreen stutter."
    proposed_display = "~ DISABLEDXMAXIMIZEDWINDOWEDMODE HIGHDPIAWARE"

    _ROOT = "HKCU"
    _SUBKEY = r"Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers"
    _TARGET_VAL = "~ DISABLEDXMAXIMIZEDWINDOWEDMODE HIGHDPIAWARE"

    def __init__(self, registry: RegistryBackend, discovery: GameLoopDiscovery) -> None:
        self._reg = registry
        self._discovery = discovery

    def _target_exe(self) -> str:
        info = self._discovery.discover()
        return info.emulator_exe if info.installed else ""

    def read_state(self) -> TweakState:
        exe = self._target_exe()
        if not exe:
            return TweakState(
                current_value="Unavailable",
                available=False,
                reason="GameLoop emulator executable not detected.",
            )
        snap = self._reg.read_value(self._ROOT, self._SUBKEY, exe)
        val = str(snap.value) if snap.existed else "Default (None)"
        optimized = snap.existed and "HIGHDPIAWARE" in str(snap.value)
        return TweakState(current_value=val, available=True, is_optimized=optimized)

    def apply(self, backup_manager: BackupManager, audit_logger: AuditLogger) -> TweakActionResult:
        exe = self._target_exe()
        if not exe:
            return TweakActionResult(self.tweak_id, False, "GameLoop emulator executable not detected.")

        before_snap = self._reg.read_value(self._ROOT, self._SUBKEY, exe)
        record = backup_manager.create_backup(
            category="tweak",
            description=f"Backup before {self.tweak_id}",
            registry_snapshots=[before_snap],
        )
        ok, msg = self._reg.write_value(self._ROOT, self._SUBKEY, exe, self._TARGET_VAL, REG_SZ)
        if not ok:
            audit_logger.record("tweak_apply", self.tweak_id, before_snap.value, self._TARGET_VAL, record.backup_id, False, msg)
            return TweakActionResult(self.tweak_id, False, msg, backup_id=record.backup_id)

        after_snap = self._reg.read_value(self._ROOT, self._SUBKEY, exe)
        verified = after_snap.existed and after_snap.value == self._TARGET_VAL
        audit_logger.record(
            "tweak_apply", self.tweak_id, before_snap.value, after_snap.value, record.backup_id, verified
        )
        return TweakActionResult(
            tweak_id=self.tweak_id,
            success=verified,
            message="Compatibility flags applied and verified." if verified else "Verification failed.",
            verified=verified,
            backup_id=record.backup_id,
            before_value=before_snap.value,
            after_value=after_snap.value,
        )
