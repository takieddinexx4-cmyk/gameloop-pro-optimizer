"""Base class for all pages providing translation, lifecycle, and unified task execution."""

from __future__ import annotations

from typing import Any, Callable

from PySide6.QtWidgets import QMessageBox, QVBoxLayout, QWidget

from gameloop_optimizer.app_core.service_container import ServiceContainer
from gameloop_optimizer.app_core.task_manager import (
    OP_STATUS_CANCELLED,
    OP_STATUS_COMPLETED,
    OP_STATUS_FAILED,
)
from gameloop_optimizer.app_core.workers import WorkerThread
from gameloop_optimizer.ui.widgets.dialogs import ProgressDialog


class BasePage(QWidget):
    def __init__(self, services: ServiceContainer, parent=None) -> None:
        super().__init__(parent)
        self.services = services
        self._active_workers: list[WorkerThread] = []

        self.page_layout = QVBoxLayout(self)
        self.page_layout.setContentsMargins(20, 18, 20, 18)
        self.page_layout.setSpacing(14)

    def t(self, key: str, **kwargs: object) -> str:
        return self.services.translator.t(key, **kwargs)

    def retranslate_ui(self) -> None:
        """Override in subclasses to refresh translated texts dynamically."""

    def on_page_activated(self) -> None:
        """Override in subclasses to refresh view when navigated to."""

    def on_page_deactivated(self) -> None:
        """Override in subclasses to pause lightweight timers when hidden."""

    def shutdown(self) -> None:
        """Gracefully cancel running workers on application exit."""
        for worker in list(self._active_workers):
            worker.cancel()
            worker.wait(1500)

    def run_background_task(
        self,
        title: str,
        fn: Callable[..., Any],
        on_success: Callable[[Any], None],
        on_error: Callable[[str], None] | None = None,
        *args: Any,
        **kwargs: Any,
    ) -> None:
        if self.services.task_manager.has_running_operation(title):
            QMessageBox.information(
                self,
                self.t("common.info"),
                self.t("ops.already_running", name=title),
            )
            return

        dialog = ProgressDialog(title, self.t("common.cancel"), parent=self)
        worker = WorkerThread(fn, *args, **kwargs)
        self._active_workers.append(worker)

        op = self.services.task_manager.start_operation(
            name=title,
            description=title,
            cancellable=True,
            cancel_callback=worker.cancel,
        )

        def cleanup() -> None:
            if worker in self._active_workers:
                self._active_workers.remove(worker)
            dialog.accept()
            worker.deleteLater()

        def handle_progress(percent: int, message: str) -> None:
            self.services.task_manager.update_progress(op.op_id, progress=percent, message=message)
            dialog.update_progress(percent, message)

        def handle_success(result: Any) -> None:
            self.services.task_manager.finish_operation(
                op.op_id,
                status=OP_STATUS_COMPLETED,
                result_summary=self.t("common.success"),
            )
            cleanup()
            on_success(result)

        def handle_failure(err: str) -> None:
            self.services.task_manager.finish_operation(
                op.op_id,
                status=OP_STATUS_FAILED,
                result_summary=err,
            )
            cleanup()
            if on_error:
                on_error(err)
            else:
                QMessageBox.warning(self, self.t("common.error"), err)

        def handle_cancel() -> None:
            self.services.task_manager.finish_operation(
                op.op_id,
                status=OP_STATUS_CANCELLED,
                result_summary=self.t("common.cancel"),
            )
            cleanup()

        worker.progress.connect(handle_progress)
        worker.finished_result.connect(handle_success)
        worker.failed.connect(handle_failure)
        worker.cancelled.connect(handle_cancel)
        dialog.cancel_btn.clicked.connect(lambda: self.services.task_manager.request_cancel(op.op_id))

        worker.start()
        dialog.exec()
