"""Comprehensive Crash & Lag Center diagnostics and evidence-based reporting."""

from __future__ import annotations

import json
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

import psutil

from gameloop_optimizer.adb_manager.manager import AdbManager
from gameloop_optimizer.app_core.models import DiagnosticFinding
from gameloop_optimizer.app_core.paths import get_reports_dir
from gameloop_optimizer.crash_analyzer.event_logs import EventLogHit, scan_windows_event_logs
from gameloop_optimizer.crash_analyzer.gameloop_logs import scan_gameloop_logs
from gameloop_optimizer.gameloop_manager.discovery import GameLoopDiscovery
from gameloop_optimizer.hardware_detection.detector import HardwareDetector


class CrashLagAnalyzer:
    def __init__(
        self,
        gameloop_discovery: GameLoopDiscovery,
        adb_manager: AdbManager,
        hardware_detector: HardwareDetector,
        event_log_scanner: Callable[[], tuple[list[EventLogHit], str]] | None = None,
        reports_dir: Path | None = None,
    ) -> None:
        self._discovery = gameloop_discovery
        self._adb = adb_manager
        self._hw_detector = hardware_detector
        self._event_scanner = event_log_scanner or scan_windows_event_logs
        self._reports_dir = reports_dir or get_reports_dir()

    def run_full_scan(self, progress_cb=None, cancel_token=None) -> list[DiagnosticFinding]:
        findings: list[DiagnosticFinding] = []
        if progress_cb:
            progress_cb(10, "Checking GameLoop installation and logs...")

        gl = self._discovery.discover()
        if not gl.installed:
            findings.append(
                DiagnosticFinding(
                    finding_id="gameloop_missing",
                    category="installation",
                    title="GameLoop Installation Not Found",
                    severity="high",
                    cause="GameLoop was not detected in Registry, running processes, or standard folders.",
                    evidence=f"Detection source: {gl.detection_source}",
                    solution="Install GameLoop or set a custom GameLoop path in Settings.",
                    can_auto_fix=False,
                )
            )
        else:
            for hit in scan_gameloop_logs(gl.logs_dirs):
                findings.append(
                    DiagnosticFinding(
                        finding_id=f"log_{hit.signature_id}",
                        category="gameloop_logs",
                        title=f"GameLoop Log Issue ({hit.signature_id})",
                        severity=hit.severity,
                        cause=hit.cause,
                        evidence=f"{Path(hit.file_path).name}: {hit.evidence_line}",
                        solution=hit.solution,
                        can_auto_fix=(hit.signature_id == "adb_socket_error"),
                        fix_action_id="repair_adb" if hit.signature_id == "adb_socket_error" else "",
                    )
                )

        if cancel_token and cancel_token.is_cancelled:
            return findings

        if progress_cb:
            progress_cb(35, "Checking Windows Event Logs...")
        evt_hits, evt_note = self._event_scanner()
        for idx, hit in enumerate(evt_hits[:6]):
            findings.append(
                DiagnosticFinding(
                    finding_id=f"evt_{hit.category}_{idx}",
                    category="windows_event_log",
                    title=f"Windows Event Log: {hit.source} (ID {hit.event_id})",
                    severity="critical" if hit.category == "gpu_driver_crash" else "high",
                    cause=(
                        "GPU driver crash/reset (TDR) detected."
                        if hit.category == "gpu_driver_crash"
                        else "GameLoop application error logged by Windows."
                    ),
                    evidence=f"[{hit.channel} @ {hit.time_generated}] {hit.message_excerpt}",
                    solution=(
                        "Perform a clean GPU driver update/reinstall from official vendor site and verify GPU temperatures."
                        if hit.category == "gpu_driver_crash"
                        else "Verify GameLoop rendering engine, check VC++/DirectX dependencies, and avoid aggressive overclocks."
                    ),
                    can_auto_fix=False,
                )
            )
        if evt_note:
            findings.append(
                DiagnosticFinding(
                    finding_id="evt_note",
                    category="windows_event_log",
                    title="Event Log Access Note",
                    severity="info",
                    cause=evt_note,
                    evidence="Windows Event Log reader note.",
                    solution="Run as Administrator only if you want full System Event Log access.",
                )
            )

        if progress_cb:
            progress_cb(60, "Checking ADB health...")
        adb_status = self._adb.get_status()
        if not adb_status.adb_available:
            findings.append(
                DiagnosticFinding(
                    finding_id="adb_missing",
                    category="adb",
                    title="ADB Binary Unavailable",
                    severity="medium",
                    cause="adb.exe could not be located.",
                    evidence=adb_status.error or "No adb.exe path found.",
                    solution="Verify GameLoop installation integrity or point Settings to your GameLoop folder.",
                )
            )
        elif adb_status.error or any(d.state != "device" for d in adb_status.devices):
            findings.append(
                DiagnosticFinding(
                    finding_id="adb_unhealthy",
                    category="adb",
                    title="ADB Connection / Daemon Issue",
                    severity="medium",
                    cause="ADB reported an error or an offline/unauthorized device.",
                    evidence=adb_status.error or str([(d.serial, d.state) for d in adb_status.devices]),
                    solution="Run Repair ADB to cleanly restart the ADB server and reconnect.",
                    can_auto_fix=True,
                    fix_action_id="repair_adb",
                )
            )

        if progress_cb:
            progress_cb(80, "Evaluating RAM, CPU, GPU driver, and disk pressure...")
        findings.extend(self.diagnose_lag_checks())

        if not findings:
            findings.append(
                DiagnosticFinding(
                    finding_id="all_clear",
                    category="health",
                    title="No Active Crash or Resource Issues Detected",
                    severity="info",
                    cause="Scanned logs, ADB status, memory pressure, CPU load, and storage space.",
                    evidence="All inspected indicators are within normal bounds.",
                    solution="Keep GPU drivers updated and test stability in Live Monitor during gameplay.",
                )
            )

        if progress_cb:
            progress_cb(100, "Diagnostic scan complete.")
        return findings

    def diagnose_lag_checks(self) -> list[DiagnosticFinding]:
        findings: list[DiagnosticFinding] = []
        vm = psutil.virtual_memory()
        if vm.percent >= 82.0:
            findings.append(
                DiagnosticFinding(
                    finding_id="high_ram_pressure",
                    category="memory",
                    title="High RAM Pressure Causing Stuttering",
                    severity="high" if vm.percent >= 90 else "medium",
                    cause="System memory usage is critically high, triggering Windows pagefile swapping.",
                    evidence=f"RAM usage: {vm.percent:.1f}% ({vm.available / (1024**3):.2f} GB free of {vm.total / (1024**3):.2f} GB)",
                    solution="Close heavy browsers/overlays in Process Manager and lower GameLoop RAM allocation if needed.",
                )
            )

        cpu_pct = psutil.cpu_percent(interval=0.25)
        if cpu_pct >= 85.0:
            findings.append(
                DiagnosticFinding(
                    finding_id="high_cpu_load",
                    category="cpu",
                    title="High Background CPU Contention",
                    severity="high",
                    cause="CPU utilization is near saturation before or during gameplay.",
                    evidence=f"Measured CPU utilization: {cpu_pct:.1f}%",
                    solution="Inspect top CPU consumers in Process Manager and avoid recording/transcoding while playing.",
                )
            )

        hw = self._hw_detector.detect()
        if hw.system_drive_free_gb.available and float(hw.system_drive_free_gb.value) < 15.0:
            findings.append(
                DiagnosticFinding(
                    finding_id="low_sys_disk",
                    category="storage",
                    title="Low Free Space on System Drive",
                    severity="high",
                    cause="Windows pagefile and shader cache require adequate free space.",
                    evidence=f"System drive free space: {hw.system_drive_free_gb.value} GB",
                    solution="Free at least 15–20 GB on the Windows drive.",
                )
            )
        if hw.gameloop_drive_free_gb.available and float(hw.gameloop_drive_free_gb.value) < 10.0:
            findings.append(
                DiagnosticFinding(
                    finding_id="low_gl_disk",
                    category="storage",
                    title="Low Free Space on GameLoop Drive",
                    severity="high",
                    cause="Low free disk space causes texture streaming and cache write stalls.",
                    evidence=f"GameLoop drive free space: {hw.gameloop_drive_free_gb.value} GB",
                    solution="Free space on the GameLoop drive or preview old log cleanup in Cleaner PRO.",
                )
            )
        if not hw.gpu_driver_version.available:
            findings.append(
                DiagnosticFinding(
                    finding_id="gpu_driver_unknown",
                    category="gpu",
                    title="GPU Driver Version Unavailable",
                    severity="low",
                    cause="Could not read GPU driver version via WMI.",
                    evidence=hw.gpu_driver_version.reason or "WMI query returned no driver version.",
                    solution="Verify your NVIDIA/AMD/Intel graphics driver is installed properly in Device Manager.",
                )
            )
        return findings

    def execute_fix(self, fix_action_id: str) -> tuple[bool, str]:
        if fix_action_id == "repair_adb":
            return self._adb.repair()
        return False, f"No automated fix is registered for action '{fix_action_id}'."

    def generate_report(self, findings: list[DiagnosticFinding]) -> Path:
        self._reports_dir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        report_path = self._reports_dir / f"diagnostic_report_{stamp}.json"
        payload = {
            "generated_at_utc": datetime.now(timezone.utc).isoformat(),
            "finding_count": len(findings),
            "findings": [asdict(f) for f in findings],
        }
        report_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
        return report_path
