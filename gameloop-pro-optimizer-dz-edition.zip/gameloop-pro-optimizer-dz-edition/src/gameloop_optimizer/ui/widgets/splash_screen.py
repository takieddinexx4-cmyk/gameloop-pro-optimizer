"""Frameless Liquid Glass Splash Screen with DZ branding and smooth fade-in."""

from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import QEasingCurve, QPropertyAnimation, Qt
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QProgressBar,
    QVBoxLayout,
    QWidget,
)

from gameloop_optimizer.app_core.constants import APP_EDITION, APP_SHORT_NAME, APP_VERSION


class DzSplashScreen(QWidget):
    """Lightweight startup splash screen showing real initialization steps."""

    def __init__(self, assets_dir: Path, parent=None) -> None:
        super().__init__(parent)
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.SplashScreen
            | Qt.WindowType.WindowStaysOnTopHint
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setFixedSize(560, 340)

        root = QVBoxLayout(self)
        root.setContentsMargins(10, 10, 10, 10)

        card = QFrame()
        card.setObjectName("HeroGlassCard")
        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(28, 26, 28, 24)
        card_layout.setSpacing(10)

        logo_label = QLabel()
        logo_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        logo_label.setStyleSheet("background: transparent;")
        logo_path = assets_dir / "dz_logo_square.png"
        if not logo_path.exists():
            logo_path = assets_dir / "app_icon.png"
        if logo_path.exists():
            pix = QPixmap(str(logo_path)).scaled(
                96,
                96,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )
            logo_label.setPixmap(pix)
        else:
            logo_label.setText("DZ")
            logo_label.setObjectName("HeroMetricValue")
        card_layout.addWidget(logo_label)

        title = QLabel(APP_SHORT_NAME)
        title.setObjectName("PageTitle")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        card_layout.addWidget(title)

        badge_row = QHBoxLayout()
        badge_row.addStretch(1)
        edition_badge = QLabel(f"{APP_EDITION}  •  v{APP_VERSION}")
        edition_badge.setObjectName("EditionBadge")
        badge_row.addWidget(edition_badge)
        badge_row.addStretch(1)
        card_layout.addLayout(badge_row)

        card_layout.addStretch(1)

        self.status_label = QLabel("Initializing core modules...")
        self.status_label.setObjectName("MutedLabel")
        self.status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        card_layout.addWidget(self.status_label)

        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setFixedHeight(8)
        card_layout.addWidget(self.progress_bar)

        root.addWidget(card)

        self._fade_anim: QPropertyAnimation | None = None
        self.setWindowOpacity(0.0)

    def show_animated(self) -> None:
        self.show()
        self._fade_anim = QPropertyAnimation(self, b"windowOpacity", self)
        self._fade_anim.setDuration(260)
        self._fade_anim.setStartValue(0.0)
        self._fade_anim.setEndValue(1.0)
        self._fade_anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._fade_anim.start()

    def set_stage(self, percent: int | None, message: str) -> None:
        if percent is None:
            self.progress_bar.setRange(0, 0)
        else:
            if self.progress_bar.maximum() == 0:
                self.progress_bar.setRange(0, 100)
            self.progress_bar.setValue(max(0, min(100, int(percent))))
        self.status_label.setText(message)
