"""Main application window with 14-item navigation sidebar and true RTL/LTR support."""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QApplication,
    QFrame,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)

from gameloop_optimizer.app_core.constants import APP_NAME, APP_VERSION
from gameloop_optimizer.app_core.permissions import is_admin, request_elevation
from gameloop_optimizer.app_core.service_container import ServiceContainer
from gameloop_optimizer.ui.pages.about_page import AboutPage
from gameloop_optimizer.ui.pages.backup_restore_page import BackupRestorePage
from gameloop_optimizer.ui.pages.base_page import BasePage
from gameloop_optimizer.ui.pages.cleaner_page import CleanerPage
from gameloop_optimizer.ui.pages.crash_lag_page import CrashLagPage
from gameloop_optimizer.ui.pages.dashboard_page import DashboardPage
from gameloop_optimizer.ui.pages.dependencies_page import DependenciesPage
from gameloop_optimizer.ui.pages.gameloop_center_page import GameLoopCenterPage
from gameloop_optimizer.ui.pages.gaming_tools_page import GamingToolsPage
from gameloop_optimizer.ui.pages.live_monitor_page import LiveMonitorPage
from gameloop_optimizer.ui.pages.optimization_page import OptimizationPage
from gameloop_optimizer.ui.pages.pc_analysis_page import PcAnalysisPage
from gameloop_optimizer.ui.pages.process_manager_page import ProcessManagerPage
from gameloop_optimizer.ui.pages.profiles_page import ProfilesPage
from gameloop_optimizer.ui.pages.settings_page import SettingsPage
from gameloop_optimizer.ui.widgets.cards import StatusBadge


class MainWindow(QMainWindow):
    def __init__(self, services: ServiceContainer) -> None:
        super().__init__()
        self.services = services
        self._nav_buttons: dict[str, QPushButton] = {}
        self._pages: dict[str, BasePage] = {}
        self._nav_specs: list[tuple[str, str]] = []
        self._current_page_key = "dashboard"

        self.setWindowTitle(f"{APP_NAME} v{APP_VERSION}")
        self.resize(1280, 820)
        self.setMinimumSize(1020, 680)

        self._build_ui()
        self.services.translator.subscribe(self._on_language_changed)
        self._retranslate_all()
        self.navigate_to("dashboard")

    def _build_ui(self) -> None:
        central = QWidget(self)
        self.setCentralWidget(central)
        root = QHBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # Sidebar
        sidebar = QFrame()
        sidebar.setObjectName("Sidebar")
        sidebar.setFixedWidth(238)
        sb_layout = QVBoxLayout(sidebar)
        sb_layout.setContentsMargins(12, 16, 12, 14)
        sb_layout.setSpacing(8)

        brand = QLabel(APP_NAME)
        brand.setObjectName("AppBrand")
        brand.setWordWrap(True)
        sb_layout.addWidget(brand)

        ver_label = QLabel(f"v{APP_VERSION}")
        ver_label.setObjectName("MutedLabel")
        sb_layout.addWidget(ver_label)

        nav_scroll = QScrollArea()
        nav_scroll.setWidgetResizable(True)
        nav_container = QWidget()
        nav_container.setStyleSheet("background: transparent;")
        nav_layout = QVBoxLayout(nav_container)
        nav_layout.setContentsMargins(0, 6, 0, 6)
        nav_layout.setSpacing(4)

        self._nav_specs = [
            ("dashboard", "nav.dashboard"),
            ("pc_analysis", "nav.pc_analysis"),
            ("optimization", "nav.smart_optimization"),
            ("gameloop_center", "nav.gameloop_center"),
            ("profiles", "nav.pubg_profiles"),
            ("crash_lag", "nav.crash_lag_center"),
            ("live_monitor", "nav.live_monitor"),
            ("gaming_tools", "nav.gaming_tools"),
            ("dependencies", "nav.dependencies"),
            ("process_manager", "nav.process_manager"),
            ("cleaner", "nav.cleaner_pro"),
            ("backup_restore", "nav.backup_restore"),
            ("settings", "nav.settings"),
            ("about", "nav.about"),
        ]

        for key, _label_key in self._nav_specs:
            btn = QPushButton()
            btn.setObjectName("NavButton")
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.clicked.connect(lambda _checked=False, k=key: self.navigate_to(k))
            self._nav_buttons[key] = btn
            nav_layout.addWidget(btn)

        nav_layout.addStretch(1)
        nav_scroll.setWidget(nav_container)
        sb_layout.addWidget(nav_scroll, 1)

        root.addWidget(sidebar)

        # Main right/left content column
        content_col = QVBoxLayout()
        content_col.setContentsMargins(0, 0, 0, 0)
        content_col.setSpacing(0)

        top_bar = QFrame()
        top_bar.setObjectName("TopBar")
        top_bar.setFixedHeight(58)
        tb_layout = QHBoxLayout(top_bar)
        tb_layout.setContentsMargins(20, 8, 20, 8)
        tb_layout.setSpacing(10)

        self.page_title_label = QLabel()
        self.page_title_label.setObjectName("PageTitle")
        tb_layout.addWidget(self.page_title_label)
        tb_layout.addStretch(1)

        self.admin_badge = StatusBadge()
        tb_layout.addWidget(self.admin_badge)

        self.elevate_btn = QPushButton()
        self.elevate_btn.clicked.connect(self._on_request_elevation)
        self.elevate_btn.setVisible(not is_admin())
        tb_layout.addWidget(self.elevate_btn)

        self.lang_btn = QPushButton()
        self.lang_btn.clicked.connect(self._toggle_language)
        tb_layout.addWidget(self.lang_btn)

        content_col.addWidget(top_bar)

        self.stack = QStackedWidget()
        page_instances: dict[str, BasePage] = {
            "dashboard": DashboardPage(self.services, navigate_cb=self.navigate_to),
            "pc_analysis": PcAnalysisPage(self.services),
            "optimization": OptimizationPage(self.services),
            "gameloop_center": GameLoopCenterPage(self.services),
            "profiles": ProfilesPage(self.services),
            "crash_lag": CrashLagPage(self.services),
            "live_monitor": LiveMonitorPage(self.services),
            "gaming_tools": GamingToolsPage(self.services),
            "dependencies": DependenciesPage(self.services),
            "process_manager": ProcessManagerPage(self.services),
            "cleaner": CleanerPage(self.services),
            "backup_restore": BackupRestorePage(self.services),
            "settings": SettingsPage(self.services),
            "about": AboutPage(self.services),
        }

        for key, page in page_instances.items():
            self._pages[key] = page
            self.stack.addWidget(page)

        content_col.addWidget(self.stack, 1)
        root.addLayout(content_col, 1)

    def navigate_to(self, page_key: str) -> None:
        if page_key not in self._pages:
            return
        self._current_page_key = page_key
        for key, btn in self._nav_buttons.items():
            btn.setProperty("active", key == page_key)
            btn.style().unpolish(btn)
            btn.style().polish(btn)

        page = self._pages[page_key]
        self.stack.setCurrentWidget(page)
        self._update_header_title()
        page.on_page_activated()

    def _update_header_title(self) -> None:
        key_map = dict(self._nav_specs)
        title_key = key_map.get(self._current_page_key, "nav.dashboard")
        self.page_title_label.setText(self.services.translator.t(title_key))

    def _toggle_language(self) -> None:
        next_lang = "en" if self.services.translator.language == "ar" else "ar"
        self.services.config_manager.config.language = next_lang
        self.services.config_manager.save()
        self.services.translator.set_language(next_lang)

    def _on_language_changed(self, _lang: str) -> None:
        app = QApplication.instance()
        if app is not None:
            direction = (
                Qt.LayoutDirection.RightToLeft
                if self.services.translator.is_rtl
                else Qt.LayoutDirection.LeftToRight
            )
            app.setLayoutDirection(direction)
            self.setLayoutDirection(direction)
        self._retranslate_all()

    def _retranslate_all(self) -> None:
        tr = self.services.translator.t
        align_css = "text-align: right;" if self.services.translator.is_rtl else "text-align: left;"
        for key, label_key in self._nav_specs:
            btn = self._nav_buttons[key]
            btn.setText(tr(label_key))
            btn.setStyleSheet(align_css)

        if is_admin():
            self.admin_badge.setText(tr("topbar.admin_yes"))
            self.admin_badge.set_level("ok")
        else:
            self.admin_badge.setText(tr("topbar.admin_no"))
            self.admin_badge.set_level("warning")

        self.elevate_btn.setText(tr("topbar.run_as_admin"))
        self.lang_btn.setText("English" if self.services.translator.is_rtl else "العربية")
        self._update_header_title()

        for page in self._pages.values():
            page.retranslate_ui()

    def _on_request_elevation(self) -> None:
        tr = self.services.translator.t
        answer = QMessageBox.question(
            self,
            tr("topbar.run_as_admin"),
            tr("topbar.elevation_confirm"),
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        ok, msg = request_elevation()
        if ok:
            self.close()
        else:
            QMessageBox.information(self, tr("common.info"), msg)

    def closeEvent(self, event) -> None:  # noqa: N802 - Qt override
        for page in self._pages.values():
            page.shutdown()
        super().closeEvent(event)
