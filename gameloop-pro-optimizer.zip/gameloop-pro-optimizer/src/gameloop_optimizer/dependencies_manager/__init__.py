"""Read-only DirectX, Visual C++, .NET, and virtualization runtime checker."""
