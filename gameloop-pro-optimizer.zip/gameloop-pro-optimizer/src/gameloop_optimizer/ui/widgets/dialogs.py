"""Confirmation, preview, and cancellable progress dialogs."""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QDialog,
    QHBoxLayout,
    QLabel,
    QPlainTextEdit,
    QProgressBar,
    QPushButton,
    QVBoxLayout,
)


class ChangeConfirmationDialog(QDialog):
    """Mandatory review & consent dialog before modifying any system or GameLoop setting."""

    def __init__(
        self,
        title: str,
        summary_lines: list[str],
        approve_text: str,
        cancel_text: str,
        parent=None,
    ) -> None:
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setMinimumWidth(520)

        layout = QVBoxLayout(self)
        layout.setSpacing(12)

        header = QLabel(title)
        header.setObjectName("SectionTitle")
        layout.addWidget(header)

        details = QPlainTextEdit()
        details.setReadOnly(True)
        details.setPlainText("\n".join(summary_lines))
        details.setMinimumHeight(200)
        layout.addWidget(details)

        buttons = QHBoxLayout()
        buttons.addStretch(1)

        cancel_btn = QPushButton(cancel_text)
        cancel_btn.clicked.connect(self.reject)

        approve_btn = QPushButton(approve_text)
        approve_btn.setObjectName("PrimaryButton")
        approve_btn.clicked.connect(self.accept)

        buttons.addWidget(cancel_btn)
        buttons.addWidget(approve_btn)
        layout.addLayout(buttons)


class ProgressDialog(QDialog):
    """Non-freezing task progress dialog with explicit Cancel button."""

    def __init__(self, title: str, cancel_text: str, parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setMinimumWidth(420)
        self.setModal(True)
        self.setWindowFlag(Qt.WindowType.WindowCloseButtonHint, False)

        layout = QVBoxLayout(self)
        layout.setSpacing(10)

        self.status_label = QLabel(title)
        self.status_label.setWordWrap(True)
        layout.addWidget(self.status_label)

        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        layout.addWidget(self.progress_bar)

        btn_row = QHBoxLayout()
        btn_row.addStretch(1)
        self.cancel_btn = QPushButton(cancel_text)
        btn_row.addWidget(self.cancel_btn)
        layout.addLayout(btn_row)

    def update_progress(self, percent: int, message: str) -> None:
        self.progress_bar.setValue(percent)
        if message:
            self.status_label.setText(message)
