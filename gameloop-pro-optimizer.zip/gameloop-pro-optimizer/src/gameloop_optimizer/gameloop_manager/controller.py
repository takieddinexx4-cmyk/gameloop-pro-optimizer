"""Safe GameLoop process lifecycle control and folder navigation."""

from __future__ import annotations

import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

import psutil

from gameloop_optimizer.app_core.constants import GAMELOOP_PROCESS_NAMES
from gameloop_optimizer.app_core.models import GameLoopInstallInfo
from gameloop_optimizer.gameloop_manager.discovery import GameLoopDiscovery
from gameloop_optimizer.logging.logger import get_logger

logger = get_logger("gameloop_manager.controller")


class GameLoopController:
    def __init__(self, discovery: GameLoopDiscovery) -> None:
        self._discovery = discovery

    def get_install_info(self) -> GameLoopInstallInfo:
        return self._discovery.discover()

    def list_running_processes(self) -> list[dict[str, Any]]:
        running: list[dict[str, Any]] = []
        for proc in psutil.process_iter(["pid", "name", "memory_info"]):
            try:
                name = proc.info.get("name") or ""
                if name.lower() in GAMELOOP_PROCESS_NAMES:
                    mem = proc.info.get("memory_info")
                    ram_mb = round(mem.rss / (1024 * 1024), 1) if mem else 0.0
                    running.append(
                        {
                            "pid": proc.info["pid"],
                            "name": name,
                            "ram_mb": ram_mb,
                        }
                    )
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        return running

    def start_gameloop(self) -> tuple[bool, str]:
        info = self.get_install_info()
        if not info.installed:
            return False, "GameLoop installation not found."

        target_exe = info.appmarket_exe or info.emulator_exe
        if not target_exe or not Path(target_exe).is_file():
            return False, "No valid GameLoop executable found."

        try:
            subprocess.Popen(
                [target_exe],
                cwd=str(Path(target_exe).parent),
                shell=False,
            )
            logger.info("Launched GameLoop executable: %s", target_exe)
            return True, f"Started: {Path(target_exe).name}"
        except OSError as exc:
            logger.error("Failed to start GameLoop: %s", exc)
            return False, str(exc)

    def stop_gameloop(self, force: bool = False) -> tuple[bool, str]:
        procs: list[psutil.Process] = []
        for proc in psutil.process_iter(["name"]):
            try:
                if (proc.info.get("name") or "").lower() in GAMELOOP_PROCESS_NAMES:
                    procs.append(proc)
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        if not procs:
            return True, "No GameLoop processes are currently running."

        denied: list[str] = []
        for proc in procs:
            try:
                proc.terminate()
            except psutil.AccessDenied:
                denied.append(f"{proc.name()} (PID {proc.pid})")
            except psutil.NoSuchProcess:
                pass

        _gone, alive = psutil.wait_procs(procs, timeout=4.0)
        if alive and force:
            for proc in alive:
                try:
                    proc.kill()
                except psutil.AccessDenied:
                    denied.append(f"{proc.name()} (PID {proc.pid})")
                except psutil.NoSuchProcess:
                    pass
            _gone2, alive = psutil.wait_procs(alive, timeout=2.0)

        if denied:
            return False, f"Access denied (try running as Administrator): {', '.join(denied)}"
        if alive:
            names = ", ".join(p.name() for p in alive)
            return False, f"Some processes are still running ({names}). Use Force Stop if needed."
        return True, f"Stopped {len(procs)} GameLoop process(es)."

    def restart_gameloop(self, force_stop: bool = False) -> tuple[bool, str]:
        ok, msg = self.stop_gameloop(force=force_stop)
        if not ok:
            return False, f"Restart aborted during stop: {msg}"
        time.sleep(1.0)
        return self.start_gameloop()

    @staticmethod
    def open_folder(folder_path: str) -> tuple[bool, str]:
        if not folder_path:
            return False, "Folder path is unavailable."
        target = Path(folder_path)
        if not target.exists() or not target.is_dir():
            return False, f"Directory does not exist: {folder_path}"
        if sys.platform != "win32":
            return False, "Opening folders in Explorer is only supported on Windows."
        try:
            os.startfile(str(target))  # noqa: S606 - validated existing directory only
            return True, str(target)
        except OSError as exc:
            return False, str(exc)
