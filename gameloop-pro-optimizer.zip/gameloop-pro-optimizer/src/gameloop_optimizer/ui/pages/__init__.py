"""Application UI pages."""
