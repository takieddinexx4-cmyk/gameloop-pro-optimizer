"""Liquid Glass (iOS 27 + Windows 11 + Premium Gaming) QSS theme for DZ EDITION."""

from __future__ import annotations


def build_stylesheet() -> str:
    return """
    /* === Base Canvas (Deep Dark Navy) === */
    QWidget {
        background-color: #060B16;
        color: #EDF2FA;
        font-family: "Segoe UI", "Cairo", "Tahoma", sans-serif;
        font-size: 13px;
    }

    QMainWindow {
        background-color: qlineargradient(
            x1: 0, y1: 0, x2: 1, y2: 1,
            stop: 0 #060B16,
            stop: 0.5 #091225,
            stop: 1 #050914
        );
    }

    /* === Translucent Liquid Glass Sidebar === */
    QFrame#Sidebar {
        background-color: qlineargradient(
            x1: 0, y1: 0, x2: 0, y2: 1,
            stop: 0 rgba(11, 20, 39, 0.96),
            stop: 1 rgba(7, 13, 27, 0.98)
        );
        border-right: 1px solid rgba(100, 200, 255, 0.14);
        border-left: 1px solid rgba(100, 200, 255, 0.14);
    }

    /* === Floating Top Bar === */
    QFrame#TopBar {
        background-color: rgba(11, 20, 38, 0.88);
        border-bottom: 1px solid rgba(120, 210, 255, 0.14);
    }

    /* === Layered Liquid Glass Cards === */
    QFrame#GlassCard {
        background-color: qlineargradient(
            x1: 0, y1: 0, x2: 0, y2: 1,
            stop: 0 rgba(22, 36, 64, 0.82),
            stop: 1 rgba(13, 22, 42, 0.88)
        );
        border: 1px solid rgba(148, 215, 255, 0.14);
        border-top: 1px solid rgba(255, 255, 255, 0.22);
        border-radius: 16px;
    }

    QFrame#GlassCard:hover {
        border: 1px solid rgba(0, 229, 255, 0.36);
        border-top: 1px solid rgba(0, 229, 255, 0.50);
    }

    QFrame#GlassCard[accent="cyan"] {
        border-top: 2px solid rgba(0, 229, 255, 0.70);
    }

    QFrame#GlassCard[accent="blue"] {
        border-top: 2px solid rgba(0, 149, 255, 0.72);
    }

    QFrame#GlassCard[accent="emerald"] {
        border-top: 2px solid rgba(16, 185, 129, 0.72);
    }

    QFrame#GlassCard[accent="amber"] {
        border-top: 2px solid rgba(245, 158, 11, 0.72);
    }

    QFrame#GlassCard[accent="red"] {
        border-top: 2px solid rgba(239, 68, 68, 0.72);
    }

    QFrame#HeroGlassCard {
        background-color: qlineargradient(
            x1: 0, y1: 0, x2: 1, y2: 1,
            stop: 0 rgba(16, 35, 70, 0.90),
            stop: 0.55 rgba(12, 24, 48, 0.88),
            stop: 1 rgba(8, 29, 54, 0.90)
        );
        border: 1px solid rgba(0, 229, 255, 0.28);
        border-top: 1px solid rgba(255, 255, 255, 0.28);
        border-radius: 18px;
    }

    QFrame#SubGlassPanel {
        background-color: rgba(9, 16, 32, 0.72);
        border: 1px solid rgba(148, 215, 255, 0.10);
        border-radius: 12px;
    }

    /* === Typography === */
    QLabel#AppBrand {
        color: #F8FAFC;
        font-size: 13px;
        font-weight: 800;
        letter-spacing: 0.6px;
        background: transparent;
    }

    QLabel#EditionBadge {
        color: #00E5FF;
        background-color: rgba(0, 149, 255, 0.20);
        border: 1px solid rgba(0, 229, 255, 0.45);
        border-radius: 8px;
        padding: 2px 8px;
        font-size: 10px;
        font-weight: 800;
        letter-spacing: 1px;
    }

    QLabel#NavGroupLabel {
        color: #64748B;
        font-size: 10px;
        font-weight: 700;
        letter-spacing: 1px;
        padding: 6px 10px 2px 10px;
        background: transparent;
    }

    QLabel#PageTitle {
        color: #F8FAFC;
        font-size: 20px;
        font-weight: 800;
        background: transparent;
    }

    QLabel#SectionTitle {
        color: #E2E8F0;
        font-size: 15px;
        font-weight: 700;
        background: transparent;
    }

    QLabel#MutedLabel {
        color: #94A3B8;
        font-size: 12px;
        background: transparent;
    }

    QLabel#MetricValue {
        color: #F8FAFC;
        font-size: 22px;
        font-weight: 800;
        background: transparent;
    }

    QLabel#HeroMetricValue {
        color: #00E5FF;
        font-size: 30px;
        font-weight: 800;
        background: transparent;
    }

    /* === Navigation Buttons === */
    QPushButton#NavButton {
        background-color: transparent;
        color: #94A3B8;
        border: 1px solid transparent;
        border-radius: 11px;
        padding: 9px 12px;
        text-align: left;
        font-weight: 600;
        font-size: 13px;
    }

    QPushButton#NavButton:hover {
        background-color: rgba(0, 180, 255, 0.11);
        border: 1px solid rgba(0, 229, 255, 0.18);
        color: #F1F5F9;
    }

    QPushButton#NavButton:pressed {
        background-color: rgba(0, 180, 255, 0.18);
    }

    QPushButton#NavButton[active="true"] {
        background-color: qlineargradient(
            x1: 0, y1: 0, x2: 1, y2: 0,
            stop: 0 rgba(0, 149, 255, 0.28),
            stop: 1 rgba(0, 229, 255, 0.14)
        );
        color: #00E5FF;
        border: 1px solid rgba(0, 229, 255, 0.44);
        font-weight: 700;
    }

    QPushButton#IconGhostButton {
        background-color: rgba(255, 255, 255, 0.05);
        color: #CBD5E1;
        border: 1px solid rgba(148, 215, 255, 0.14);
        border-radius: 10px;
        padding: 6px 10px;
        font-weight: 700;
    }

    QPushButton#IconGhostButton:hover {
        background-color: rgba(0, 229, 255, 0.14);
        border: 1px solid rgba(0, 229, 255, 0.40);
        color: #FFFFFF;
    }

    /* === Action Buttons === */
    QPushButton {
        background-color: rgba(23, 37, 66, 0.88);
        color: #E6EFFA;
        border: 1px solid rgba(148, 215, 255, 0.16);
        border-top: 1px solid rgba(255, 255, 255, 0.22);
        border-radius: 10px;
        padding: 8px 16px;
        font-weight: 600;
    }

    QPushButton:hover {
        background-color: rgba(31, 51, 90, 0.95);
        border: 1px solid rgba(0, 229, 255, 0.45);
        color: #FFFFFF;
    }

    QPushButton:pressed {
        background-color: rgba(16, 28, 52, 0.98);
        border: 1px solid rgba(0, 229, 255, 0.65);
    }

    QPushButton:disabled {
        background-color: rgba(16, 24, 40, 0.55);
        color: #475569;
        border: 1px solid rgba(255, 255, 255, 0.04);
    }

    QPushButton#PrimaryButton {
        background-color: qlineargradient(
            x1: 0, y1: 0, x2: 1, y2: 0,
            stop: 0 #0088FF,
            stop: 1 #00D4FF
        );
        color: #04101E;
        border: 1px solid rgba(125, 249, 255, 0.55);
        font-weight: 800;
    }

    QPushButton#PrimaryButton:hover {
        background-color: qlineargradient(
            x1: 0, y1: 0, x2: 1, y2: 0,
            stop: 0 #1A9BFF,
            stop: 1 #33E3FF
        );
        color: #020812;
    }

    QPushButton#PrimaryButton:pressed {
        background-color: #0077DD;
    }

    QPushButton#DangerButton {
        background-color: rgba(239, 68, 68, 0.18);
        color: #FCA5A5;
        border: 1px solid rgba(239, 68, 68, 0.45);
        font-weight: 700;
    }

    QPushButton#DangerButton:hover {
        background-color: rgba(239, 68, 68, 0.34);
        color: #FEE2E2;
        border: 1px solid rgba(248, 113, 113, 0.72);
    }

    QPushButton#DangerButton:pressed {
        background-color: rgba(220, 38, 38, 0.42);
    }

    QPushButton#WarningButton {
        background-color: rgba(245, 158, 11, 0.18);
        color: #FCD34D;
        border: 1px solid rgba(245, 158, 11, 0.45);
        font-weight: 700;
    }

    QPushButton#WarningButton:hover {
        background-color: rgba(245, 158, 11, 0.30);
    }

    QPushButton#SuccessButton {
        background-color: rgba(16, 185, 129, 0.20);
        color: #6EE7B7;
        border: 1px solid rgba(16, 185, 129, 0.48);
        font-weight: 700;
    }

    QPushButton#SuccessButton:hover {
        background-color: rgba(16, 185, 129, 0.32);
    }

    /* === Inputs & Editors === */
    QLineEdit, QComboBox, QSpinBox, QPlainTextEdit, QTextEdit {
        background-color: rgba(10, 17, 33, 0.90);
        color: #EDF2FA;
        border: 1px solid rgba(148, 215, 255, 0.16);
        border-radius: 10px;
        padding: 7px 11px;
        selection-background-color: rgba(0, 180, 255, 0.40);
    }

    QLineEdit:focus, QComboBox:focus, QSpinBox:focus, QPlainTextEdit:focus {
        border: 1px solid #00E5FF;
        background-color: rgba(13, 22, 42, 0.96);
    }

    QComboBox::drop-down {
        border: none;
        width: 22px;
    }

    QComboBox QAbstractItemView {
        background-color: #0D172B;
        color: #EDF2FA;
        border: 1px solid rgba(0, 229, 255, 0.30);
        selection-background-color: rgba(0, 149, 255, 0.32);
    }

    /* === Tables, Lists & Trees === */
    QTableWidget, QTreeWidget, QListWidget {
        background-color: rgba(10, 17, 33, 0.86);
        alternate-background-color: rgba(16, 27, 50, 0.72);
        border: 1px solid rgba(148, 215, 255, 0.14);
        border-radius: 12px;
        gridline-color: rgba(148, 215, 255, 0.07);
        outline: none;
    }

    QTableWidget::item, QListWidget::item {
        padding: 6px 8px;
    }

    QTableWidget::item:selected, QListWidget::item:selected {
        background-color: rgba(0, 149, 255, 0.28);
        color: #FFFFFF;
    }

    QHeaderView::section {
        background-color: rgba(18, 30, 56, 0.95);
        color: #CBD5E1;
        padding: 9px 10px;
        border: none;
        border-bottom: 1px solid rgba(0, 229, 255, 0.20);
        font-weight: 700;
        font-size: 12px;
    }

    /* === Tabs === */
    QTabWidget::pane {
        border: 1px solid rgba(148, 215, 255, 0.14);
        border-radius: 12px;
        background-color: rgba(11, 19, 36, 0.86);
    }

    QTabBar::tab {
        background-color: rgba(16, 26, 48, 0.80);
        color: #94A3B8;
        padding: 9px 18px;
        border-top-left-radius: 10px;
        border-top-right-radius: 10px;
        margin-right: 4px;
        font-weight: 600;
    }

    QTabBar::tab:selected {
        background-color: rgba(0, 149, 255, 0.24);
        color: #00E5FF;
        border-bottom: 2px solid #00E5FF;
        font-weight: 700;
    }

    /* === Progress Bars === */
    QProgressBar {
        background-color: rgba(13, 23, 44, 0.92);
        border: 1px solid rgba(148, 215, 255, 0.16);
        border-radius: 8px;
        text-align: center;
        color: #F8FAFC;
        font-weight: 700;
        font-size: 11px;
        min-height: 16px;
    }

    QProgressBar::chunk {
        background-color: qlineargradient(
            x1: 0, y1: 0, x2: 1, y2: 0,
            stop: 0 #0088FF,
            stop: 1 #00E5FF
        );
        border-radius: 6px;
    }

    /* === Scroll Areas & Scrollbars === */
    QScrollArea {
        border: none;
        background: transparent;
    }

    QScrollBar:vertical {
        background: rgba(6, 11, 22, 0.4);
        width: 8px;
        margin: 2px 0;
    }

    QScrollBar::handle:vertical {
        background: rgba(100, 160, 220, 0.34);
        border-radius: 4px;
        min-height: 28px;
    }

    QScrollBar::handle:vertical:hover {
        background: rgba(0, 229, 255, 0.55);
    }

    QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
        height: 0px;
    }

    QScrollBar:horizontal {
        background: rgba(6, 11, 22, 0.4);
        height: 8px;
    }

    QScrollBar::handle:horizontal {
        background: rgba(100, 160, 220, 0.34);
        border-radius: 4px;
        min-width: 28px;
    }

    /* === Dialogs & Checkboxes === */
    QDialog {
        background-color: #081020;
    }

    QCheckBox {
        spacing: 8px;
        background: transparent;
    }

    QCheckBox::indicator {
        width: 17px;
        height: 17px;
        border-radius: 5px;
        border: 1px solid rgba(148, 215, 255, 0.35);
        background-color: rgba(10, 18, 34, 0.90);
    }

    QCheckBox::indicator:checked {
        background-color: #00A8FF;
        border: 1px solid #00E5FF;
    }
    """
