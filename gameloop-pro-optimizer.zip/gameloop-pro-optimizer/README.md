# GAMELOOP PRO OPTIMIZER

برنامج سطح مكتب احترافي لنظام Windows مبني بـ **Python 3.11 + PySide6** لتشخيص ومعالجة مشاكل **GameLoop / PUBG Mobile** (اللاج، هبوط الإطارات، التقطيع، التجميد، زمن الاستجابة، الأعطال، استهلاك الموارد، وأخطاء ADB) بطريقة علمية آمنة وقابلة للتراجع بالكامل.

A diagnostic-driven, safety-first Windows desktop suite built with **Python 3.11 + PySide6** to diagnose and mitigate **GameLoop / PUBG Mobile** stability, stuttering, crash, resource, and ADB issues — with zero telemetry and full SHA-256 verified rollback.

---

## مبادئ الأمان والصدق الهندسي | Security & Honesty Principles

- **لا تضحية بأمان Windows:** لا يقوم البرنامج إطلاقاً بتعطيل Windows Defender أو الجدار الناري أو Windows Update، ولا يغيّر إعدادات الإقلاع (`bcdedit`).
- **سلسلة التعديل الآمنة:** كل تعديل يمر بـ: قراءة الحالة الحالية → معاينة التغيير → موافقة صريحة من المستخدم → نسخة احتياطية موثقة بـ SHA-256 → تطبيق → تحقق → إمكانية تراجع فوري أو فردي.
- **لا قياسات وهمية:** أي مستشعر غير متاح (مثل الحرارة بدون LibreHardwareMonitor/OpenHardwareMonitor، أو FPS بدون RTSS) يُعرض بوضوح كـ **«غير متاح / Unavailable»** مع ذكر السبب، ولا يتم اختراع أرقام أو وعود وهمية بزيادة الإطارات.
- **تنظيف آمن:** منظّف Cleaner PRO يعرض معاينة إلزامية قبل أي إجراء، ويحظر تماماً المساس بملفات `.sav` و`.ini` و`.cfg` و`.pak` و`.obb` وملفات المستخدم، وينقل الملفات المؤقتة/السجلات القديمة إلى **سلة المحذوفات (Recycle Bin)** فقط.
- **بلا `shell=True` وبلا تنزيلات صامتة:** جميع الأوامر تُنفّذ بقوائم معاملات آمنة (`shell=False`)، ولا توجد أي تنزيلات تنفيذية تلقائية أو تيليمتري.

---

## حالة الاختبار (قاعدة الصدق) | Testing Status

- الاختبارات الآلية غير المرتبطة بالواجهة (`pytest -v -m "not gui"`) تغطي الوحدات الخلفية باستخدام Mocks معزولة (GameLoop غير مثبّت، مسار غير قياسي، ADB مقطوع، غياب المستشعرات، تشغيل بدون صلاحيات Admin، التراجع الكامل، سلامة SHA-256، وحماية Cleaner PRO).
- **مهم — غير مُختبر على جهاز حقيقي:** الميزات المتفاعلة مباشرة مع WMI وWindows Registry وWindows Event Log و`adb.exe` و`RTSSSharedMemoryV2` وGameLoop الفعلي لم تُشغَّل على جهاز Windows فعلي أثناء التطوير؛ يُرجى تنفيذ قائمة الاختبار اليدوي أدناه عند أول تشغيل.

### قائمة الاختبار اليدوي على جهاز Windows حقيقي | Manual Test Checklist
1. شغّل `GAMELOOP PRO OPTIMIZER.exe` كمستخدم عادي (بدون Admin) وتأكد من عرض شارة **مستخدم عادي (وضع آمن)** وسقوط تعديل `HKLM` (مثل HAGS) بأمان إلى حالة «غير متاح».
2. افتح **PC Analysis** واضغط تحليل، وتأكد من مطابقة CPU/RAM/GPU/VRAM/دقة الشاشة/التردد لبيانات جهازك، وأن الحرارة تظهر «غير متاح» في حال عدم تشغيل LibreHardwareMonitor.
3. افتح **GameLoop Center** وتأكد من كشف مسار GameLoop (أو حدّد مساراً مخصّصاً في **Settings**)، وجرّب فحص وإصلاح ADB مع تشغيل المحاكي.
4. افتح **Smart Optimization** (وضع Safe)، طبّق **Windows Game Mode** بعد مراجعة نافذة التأكيد، ثم جرّب **Rollback Selected** وتأكد من عودة القيمة الأصلية.
5. افتح **Cleaner PRO**، اضغط معاينة وتأكد من عدم ظهور أي ملف `.sav` أو `.ini`، وجرّب نقل ملف سجل قديم وتأكد من وجوده في سلة المحذوفات.
6. بدّل اللغة بين العربية والإنجليزية من الشريط العلوي وتأكد من انعكاس اتجاه الواجهة بالكامل (RTL / LTR).
7. افتح **Live Monitor** لمدة دقيقة وتحقق من انخفاض استهلاك CPU للبرنامج نفسه ومن عمل نافذتي 60 ثانية و5 دقائق، وتحقق من قراءة RTSS فقط عند تشغيل RivaTuner.

---

## البناء المحلي على Windows | Local Windows Build

```bat
build.bat
```

الناتج:
- `dist\GAMELOOP PRO OPTIMIZER.exe`
- `dist\GAMELOOP PRO OPTIMIZER.exe.sha256`

---

## البناء التلقائي عبر GitHub Actions | Automated GitHub Actions Build

يحتوي المستودع على `.github/workflows/build.yml` الذي يعمل على `windows-latest`:
- يثبّت Python 3.11 والاعتماديات المثبتة في `requirements.txt`.
- يشغّل `pytest -v -m "not gui"`.
- يولّد الأيقونة برمجياً (`scripts/generate_icon.py`).
- يبني `GAMELOOP PRO OPTIMIZER.exe` عبر PyInstaller مع الأيقونة ومعلومات الإصدار.
- يحسب ملف التحقق `.sha256` ويرفعه مع الـ EXE كـ Artifact.
- عند دفع وسم إصدار مثل `v1.0.0` ينشئ GitHub Release تلقائياً ويرفق الـ EXE وملف SHA256.
