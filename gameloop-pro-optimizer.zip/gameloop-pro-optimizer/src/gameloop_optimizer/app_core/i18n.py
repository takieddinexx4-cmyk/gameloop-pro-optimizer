"""Internationalization loader with Arabic RTL and English LTR support."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Callable

from gameloop_optimizer.app_core.constants import DEFAULT_LANGUAGE, SUPPORTED_LANGUAGES
from gameloop_optimizer.app_core.paths import get_locales_dir


class Translator:
    def __init__(
        self,
        language: str = DEFAULT_LANGUAGE,
        locales_dir: Path | None = None,
    ) -> None:
        self._locales_dir = locales_dir or get_locales_dir()
        self._catalogs: dict[str, dict[str, str]] = {}
        self._language = language if language in SUPPORTED_LANGUAGES else DEFAULT_LANGUAGE
        self._listeners: list[Callable[[str], None]] = []
        self._load_all()

    def _load_all(self) -> None:
        for lang in SUPPORTED_LANGUAGES:
            path = self._locales_dir / f"{lang}.json"
            if path.exists():
                try:
                    self._catalogs[lang] = json.loads(path.read_text(encoding="utf-8"))
                except (OSError, ValueError):
                    self._catalogs[lang] = {}
            else:
                self._catalogs[lang] = {}

    @property
    def language(self) -> str:
        return self._language

    @property
    def is_rtl(self) -> bool:
        return self._language == "ar"

    def set_language(self, language: str) -> None:
        if language not in SUPPORTED_LANGUAGES or language == self._language:
            return
        self._language = language
        for callback in list(self._listeners):
            callback(language)

    def subscribe(self, callback: Callable[[str], None]) -> None:
        if callback not in self._listeners:
            self._listeners.append(callback)

    def t(self, key: str, **kwargs: object) -> str:
        text = self._catalogs.get(self._language, {}).get(key)
        if text is None:
            text = self._catalogs.get("en", {}).get(key, key)
        if kwargs:
            try:
                return text.format(**kwargs)
            except (KeyError, ValueError):
                return text
        return text
