"""Modern Liquid Glass Process Manager with live non-freezing refresh, search, filter, and strict safety."""

from __future__ import annotations

from PySide6.QtCore import Qt, QThread, QTimer, Signal
from PySide6.QtGui import QBrush, QColor
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QGridLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
)

from gameloop_optimizer.app_core.service_container import ServiceContainer
from gameloop_optimizer.ui.pages.base_page import BasePage
from gameloop_optimizer.ui.widgets.cards import GlassCard, MetricCard


class _ProcessPollWorker(QThread):
    loaded = Signal(dict, list)

    def __init__(self, process_tools, limit: int = 250) -> None:
        super().__init__()
        self._tools = process_tools
        self._limit = limit

    def run(self) -> None:
        try:
            summary = self._tools.get_system_summary()
            rows = self._tools.list_processes(limit=self._limit)
            self.loaded.emit(summary, rows)
        except Exception:  # noqa: BLE001
            return


class ProcessManagerPage(BasePage):
    def __init__(self, services: ServiceContainer, parent=None) -> None:
        super().__init__(services, parent)
        self._all_rows: list[dict] = []
        self._visible_rows: list[dict] = []
        self._poll_worker: _ProcessPollWorker | None = None
        self._auto_timer = QTimer(self)
        self._auto_timer.setInterval(3000)
        self._auto_timer.timeout.connect(self._refresh_async)
        self._build_ui()

    def _build_ui(self) -> None:
        # === Top Stat Cards (4 Glass Metrics) ===
        stats_grid = QGridLayout()
        stats_grid.setSpacing(12)
        self.total_card = MetricCard("", "--", "", accent="blue")
        self.cpu_card = MetricCard("", "--", "", accent="cyan", show_bar=True)
        self.ram_card = MetricCard("", "--", "", accent="emerald", show_bar=True)
        self.gl_card = MetricCard("", "--", "", accent="cyan")

        stats_grid.addWidget(self.total_card, 0, 0)
        stats_grid.addWidget(self.cpu_card, 0, 1)
        stats_grid.addWidget(self.ram_card, 0, 2)
        stats_grid.addWidget(self.gl_card, 0, 3)
        self.page_layout.addLayout(stats_grid)

        # === Search, Filter, Sort & Auto-Refresh Toolbar ===
        toolbar_card = GlassCard()
        tb_row = QHBoxLayout()
        tb_row.setSpacing(10)

        self.search_input = QLineEdit()
        self.search_input.setClearButtonEnabled(True)
        self.search_input.textChanged.connect(self._apply_filters_and_render)

        self.filter_combo = QComboBox()
        self.filter_combo.addItem("", "all")
        self.filter_combo.addItem("", "gameloop")
        self.filter_combo.addItem("", "user")
        self.filter_combo.addItem("", "protected")
        self.filter_combo.currentIndexChanged.connect(self._apply_filters_and_render)

        self.sort_combo = QComboBox()
        self.sort_combo.addItem("", "ram")
        self.sort_combo.addItem("", "cpu")
        self.sort_combo.addItem("", "name")
        self.sort_combo.addItem("", "pid")
        self.sort_combo.currentIndexChanged.connect(self._apply_filters_and_render)

        self.auto_refresh_cb = QCheckBox()
        self.auto_refresh_cb.setChecked(True)
        self.auto_refresh_cb.toggled.connect(self._on_auto_refresh_toggled)

        self.refresh_btn = QPushButton()
        self.refresh_btn.setObjectName("PrimaryButton")
        self.refresh_btn.clicked.connect(self._refresh_async)

        tb_row.addWidget(self.search_input, 2)
        tb_row.addWidget(self.filter_combo, 1)
        tb_row.addWidget(self.sort_combo, 1)
        tb_row.addWidget(self.auto_refresh_cb)
        tb_row.addWidget(self.refresh_btn)
        toolbar_card.root_layout.addLayout(tb_row)
        self.page_layout.addWidget(toolbar_card)

        # === Process Table (6 Columns) ===
        self.table = QTableWidget(0, 6)
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(5, QHeaderView.ResizeMode.Stretch)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        self.table.currentCellChanged.connect(self._on_selection_changed)
        self.page_layout.addWidget(self.table, 3)

        # === Selected Process Details + Safe Actions Bar ===
        action_card = GlassCard()

        actions_row = QHBoxLayout()
        actions_row.setSpacing(8)
        self.details_btn = QPushButton()
        self.details_btn.clicked.connect(self._view_details)

        self.open_loc_btn = QPushButton()
        self.open_loc_btn.clicked.connect(self._open_file_location)

        self.prio_norm_btn = QPushButton()
        self.prio_norm_btn.clicked.connect(lambda: self._set_priority("normal"))
        self.prio_above_btn = QPushButton()
        self.prio_above_btn.clicked.connect(lambda: self._set_priority("above_normal"))
        self.prio_high_btn = QPushButton()
        self.prio_high_btn.clicked.connect(lambda: self._set_priority("high"))

        self.affinity_btn = QPushButton()
        self.affinity_btn.clicked.connect(self._eval_affinity)

        self.term_btn = QPushButton()
        self.term_btn.setObjectName("DangerButton")
        self.term_btn.clicked.connect(self._terminate_selected)

        for b in (
            self.details_btn,
            self.open_loc_btn,
            self.prio_norm_btn,
            self.prio_above_btn,
            self.prio_high_btn,
            self.affinity_btn,
            self.term_btn,
        ):
            actions_row.addWidget(b)
        actions_row.addStretch(1)
        action_card.root_layout.addLayout(actions_row)

        self.details_preview = QPlainTextEdit()
        self.details_preview.setReadOnly(True)
        self.details_preview.setMaximumHeight(82)
        action_card.root_layout.addWidget(self.details_preview)

        self.safety_note = QLabel()
        self.safety_note.setObjectName("MutedLabel")
        self.safety_note.setWordWrap(True)
        action_card.root_layout.addWidget(self.safety_note)

        self.page_layout.addWidget(action_card)

    def on_page_activated(self) -> None:
        self._refresh_async()
        if self.auto_refresh_cb.isChecked() and not self._auto_timer.isActive():
            self._auto_timer.start()

    def on_page_deactivated(self) -> None:
        if self._auto_timer.isActive():
            self._auto_timer.stop()

    def shutdown(self) -> None:
        if self._auto_timer.isActive():
            self._auto_timer.stop()
        if self._poll_worker and self._poll_worker.isRunning():
            self._poll_worker.wait(1500)
        super().shutdown()

    def retranslate_ui(self) -> None:
        self.total_card.title_label.setText(self.t("proc.stat_total"))
        self.cpu_card.title_label.setText(self.t("monitor.cpu"))
        self.ram_card.title_label.setText(self.t("monitor.ram"))
        self.gl_card.title_label.setText(self.t("proc.stat_gameloop"))

        self.search_input.setPlaceholderText(self.t("proc.search_placeholder"))
        self.filter_combo.setItemText(0, self.t("proc.filter_all"))
        self.filter_combo.setItemText(1, self.t("proc.filter_gameloop"))
        self.filter_combo.setItemText(2, self.t("proc.filter_user"))
        self.filter_combo.setItemText(3, self.t("proc.filter_protected"))

        self.sort_combo.setItemText(0, self.t("proc.sort_ram"))
        self.sort_combo.setItemText(1, self.t("proc.sort_cpu"))
        self.sort_combo.setItemText(2, self.t("proc.sort_name"))
        self.sort_combo.setItemText(3, self.t("proc.sort_pid"))

        self.auto_refresh_cb.setText(self.t("proc.auto_refresh"))
        self.refresh_btn.setText(self.t("proc.refresh"))
        self.details_btn.setText(self.t("proc.view_details"))
        self.open_loc_btn.setText(self.t("proc.open_location"))
        self.prio_norm_btn.setText(self.t("proc.priority_normal"))
        self.prio_above_btn.setText(self.t("proc.priority_above"))
        self.prio_high_btn.setText(self.t("proc.priority_high"))
        self.affinity_btn.setText(self.t("proc.check_affinity"))
        self.term_btn.setText(self.t("proc.terminate"))
        self.safety_note.setText(self.t("proc.safety_notice"))

        self.table.setHorizontalHeaderLabels(
            [
                self.t("proc.col_name"),
                "PID",
                self.t("proc.col_cpu"),
                self.t("proc.col_ram"),
                self.t("proc.col_status"),
                self.t("proc.col_path_tag"),
            ]
        )

    def _on_auto_refresh_toggled(self, enabled: bool) -> None:
        if enabled:
            self._auto_timer.start()
        else:
            self._auto_timer.stop()

    def _refresh_async(self) -> None:
        if self._poll_worker is not None and self._poll_worker.isRunning():
            return
        self._poll_worker = _ProcessPollWorker(self.services.process_tools, limit=250)
        self._poll_worker.loaded.connect(self._on_data_loaded)
        self._poll_worker.finished.connect(self._cleanup_poll_worker)
        self._poll_worker.start()

    def _cleanup_poll_worker(self) -> None:
        if self._poll_worker is not None:
            self._poll_worker.deleteLater()
            self._poll_worker = None

    def _on_data_loaded(self, summary: dict, rows: list[dict]) -> None:
        self.total_card.update_metric(None, str(summary.get("total_processes", 0)), self.t("proc.stat_active_sub"))
        cpu_pct = float(summary.get("cpu_percent", 0.0))
        self.cpu_card.update_metric(None, f"{cpu_pct:.1f}%", "", bar_percent=int(cpu_pct))
        ram_pct = float(summary.get("ram_percent", 0.0))
        ram_sub = f"{summary.get('ram_used_gb', 0):.1f} / {summary.get('ram_total_gb', 0):.1f} GB"
        self.ram_card.update_metric(None, f"{ram_pct:.1f}%", ram_sub, bar_percent=int(ram_pct))

        gl_cnt = int(summary.get("gameloop_processes", 0))
        self.gl_card.update_metric(
            None,
            str(gl_cnt),
            self.t("dashboard.emu_running") if gl_cnt > 0 else self.t("dashboard.emu_stopped"),
            badge_text="ACTIVE" if gl_cnt > 0 else "IDLE",
            badge_level="cyan" if gl_cnt > 0 else "muted",
        )

        self._all_rows = rows
        self._apply_filters_and_render()

    def _apply_filters_and_render(self) -> None:
        selected_pid = None
        cur_row = self.table.currentRow()
        if 0 <= cur_row < len(self._visible_rows):
            selected_pid = self._visible_rows[cur_row]["pid"]

        query = self.search_input.text().strip().lower()
        filt = self.filter_combo.currentData() or "all"
        sort_by = self.sort_combo.currentData() or "ram"

        filtered = []
        for row in self._all_rows:
            if filt == "gameloop" and not row["is_gameloop"]:
                continue
            if filt == "user" and (row["is_protected"] or row["is_gameloop"]):
                continue
            if filt == "protected" and not row["is_protected"]:
                continue
            if query:
                hay = f"{row['name']} {row['pid']} {row.get('exe_path', '')}".lower()
                if query not in hay:
                    continue
            filtered.append(row)

        if sort_by == "cpu":
            filtered.sort(key=lambda r: (not r["is_gameloop"], -r["cpu_percent"], -r["ram_mb"]))
        elif sort_by == "name":
            filtered.sort(key=lambda r: (not r["is_gameloop"], r["name"].lower()))
        elif sort_by == "pid":
            filtered.sort(key=lambda r: r["pid"])
        else:
            filtered.sort(key=lambda r: (not r["is_gameloop"], -r["ram_mb"]))

        self._visible_rows = filtered
        self.table.setUpdatesEnabled(False)
        self.table.setRowCount(len(filtered))

        gl_fg = QBrush(QColor("#00E5FF"))
        gl_bg = QBrush(QColor(0, 149, 255, 34))
        prot_fg = QBrush(QColor("#FBBF24"))

        restore_idx = -1
        for idx, row in enumerate(filtered):
            if selected_pid is not None and row["pid"] == selected_pid:
                restore_idx = idx
            tag = (
                "[GAMELOOP]"
                if row["is_gameloop"]
                else ("[PROTECTED]" if row["is_protected"] else "[USER]")
            )
            path_or_tag = f"{tag} {row.get('exe_path') or ''}".strip()

            items = [
                QTableWidgetItem(row["name"]),
                QTableWidgetItem(str(row["pid"])),
                QTableWidgetItem(f"{row['cpu_percent']:.1f}%"),
                QTableWidgetItem(f"{row['ram_mb']:.1f}"),
                QTableWidgetItem(str(row.get("status", "running"))),
                QTableWidgetItem(path_or_tag),
            ]
            for col, item in enumerate(items):
                if row["is_gameloop"]:
                    item.setForeground(gl_fg)
                    item.setBackground(gl_bg)
                elif row["is_protected"] and col in (0, 5):
                    item.setForeground(prot_fg)
                self.table.setItem(idx, col, item)

        self.table.setUpdatesEnabled(True)
        if restore_idx >= 0:
            self.table.selectRow(restore_idx)

    def _selected_row(self, warn_if_missing: bool = True) -> dict | None:
        row_idx = self.table.currentRow()
        if 0 <= row_idx < len(self._visible_rows):
            return self._visible_rows[row_idx]
        if warn_if_missing:
            QMessageBox.information(self, self.t("common.info"), self.t("proc.select_first"))
        return None

    def _on_selection_changed(self, row_idx: int, *_args) -> None:
        if not (0 <= row_idx < len(self._visible_rows)):
            self.details_preview.clear()
            return
        row = self._visible_rows[row_idx]
        tag = "GAMELOOP" if row["is_gameloop"] else ("PROTECTED SYSTEM" if row["is_protected"] else "User")
        path = row.get("exe_path") or self.t("common.unavailable")
        self.details_preview.setPlainText(
            f"Name: {row['name']}  |  PID: {row['pid']}  |  Tag: {tag}\n"
            f"CPU: {row['cpu_percent']:.1f}%  |  RAM: {row['ram_mb']:.1f} MB  |  Status: {row.get('status', 'running')}\n"
            f"Path: {path}"
        )
        self.term_btn.setEnabled(not row["is_protected"])

    def _view_details(self) -> None:
        row = self._selected_row()
        if not row:
            return
        ok, data = self.services.process_tools.get_process_details(row["pid"])
        if not ok or not isinstance(data, dict):
            QMessageBox.warning(self, self.t("common.warning"), str(data))
            return
        lines = [
            f"Name: {data['name']}",
            f"PID: {data['pid']}",
            f"Status: {data['status']}",
            f"CPU: {data['cpu_percent']}%",
            f"RAM: {data['ram_mb']} MB",
            f"Threads: {data['num_threads']}",
            f"User: {data['username'] or self.t('common.unavailable')}",
            f"Path: {data['exe_path'] or self.t('common.unavailable')}",
            f"GameLoop Process: {'Yes' if data['is_gameloop'] else 'No'}",
            f"Protected System: {'Yes' if data['is_protected'] else 'No'}",
        ]
        QMessageBox.information(self, self.t("proc.view_details"), "\n".join(lines))

    def _open_file_location(self) -> None:
        row = self._selected_row()
        if not row:
            return
        ok, msg = self.services.process_tools.open_file_location(row.get("exe_path", ""))
        if not ok:
            QMessageBox.information(self, self.t("common.info"), msg)

    def _set_priority(self, level: str) -> None:
        row = self._selected_row()
        if not row:
            return
        ok, msg = self.services.process_tools.set_process_priority(row["pid"], level)
        QMessageBox.information(self, self.t("common.success" if ok else "common.warning"), msg)

    def _eval_affinity(self) -> None:
        row = self._selected_row()
        if not row:
            return
        rec, cpus, reason = self.services.process_tools.evaluate_cpu_affinity(row["pid"])
        if not rec:
            QMessageBox.information(self, self.t("common.info"), reason)
            return
        ans = QMessageBox.question(self, self.t("common.confirm"), f"{reason}\nApply affinity {cpus}?")
        if ans == QMessageBox.StandardButton.Yes:
            ok, msg = self.services.process_tools.apply_cpu_affinity(row["pid"], cpus)
            QMessageBox.information(self, self.t("common.success" if ok else "common.warning"), msg)

    def _terminate_selected(self) -> None:
        row = self._selected_row()
        if not row:
            return
        if row["is_protected"]:
            QMessageBox.warning(
                self,
                self.t("common.warning"),
                f"Blocked for Windows stability: '{row['name']}' is a protected system process.",
            )
            return
        ans = QMessageBox.question(
            self,
            self.t("common.confirm"),
            self.t("proc.terminate_confirm", name=row["name"], pid=row["pid"]),
        )
        if ans != QMessageBox.StandardButton.Yes:
            return
        ok, msg = self.services.process_tools.terminate_process(row["pid"])
        QMessageBox.information(self, self.t("common.success" if ok else "common.warning"), msg)
        self._refresh_async()
