"""Persistent JSON application configuration."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path

from gameloop_optimizer.app_core.constants import (
    DEFAULT_GITHUB_OWNER,
    DEFAULT_GITHUB_REPO,
    DEFAULT_LANGUAGE,
    SUPPORTED_LANGUAGES,
)
from gameloop_optimizer.app_core.paths import get_config_file


@dataclass
class AppConfig:
    language: str = DEFAULT_LANGUAGE
    monitor_interval_ms: int = 1000
    enable_ping_monitor: bool = False
    ping_target_host: str = "1.1.1.1"
    cleaner_log_min_age_days: int = 3
    github_owner: str = DEFAULT_GITHUB_OWNER
    github_repo: str = DEFAULT_GITHUB_REPO
    custom_gameloop_path: str = ""
    always_confirm_changes: bool = True

    def validate(self) -> None:
        if self.language not in SUPPORTED_LANGUAGES:
            self.language = DEFAULT_LANGUAGE
        self.monitor_interval_ms = max(500, min(5000, int(self.monitor_interval_ms)))
        self.cleaner_log_min_age_days = max(0, min(365, int(self.cleaner_log_min_age_days)))


class ConfigManager:
    def __init__(self, config_path: Path | None = None) -> None:
        self._path = config_path or get_config_file()
        self.config = self.load()

    def load(self) -> AppConfig:
        if not self._path.exists():
            cfg = AppConfig()
            self.save(cfg)
            return cfg
        try:
            raw = json.loads(self._path.read_text(encoding="utf-8"))
            valid_keys = {k for k in AppConfig.__dataclass_fields__}
            filtered = {k: v for k, v in raw.items() if k in valid_keys}
            cfg = AppConfig(**filtered)
            cfg.validate()
            return cfg
        except (OSError, ValueError, TypeError):
            return AppConfig()

    def save(self, cfg: AppConfig | None = None) -> None:
        target = cfg or self.config
        target.validate()
        self.config = target
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._path.write_text(
            json.dumps(asdict(target), indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
