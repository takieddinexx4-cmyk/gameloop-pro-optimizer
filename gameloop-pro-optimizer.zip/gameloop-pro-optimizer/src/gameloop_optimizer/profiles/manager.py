"""PUBG/GameLoop profile application (backed up & verified), save, import, and export."""

from __future__ import annotations

import json
from dataclasses import asdict
from pathlib import Path

from gameloop_optimizer.app_core.models import HardwareProfile, PubgProfile
from gameloop_optimizer.app_core.paths import get_profiles_dir
from gameloop_optimizer.backup_restore.manager import BackupManager
from gameloop_optimizer.backup_restore.registry_io import REG_DWORD
from gameloop_optimizer.logging.audit import AuditLogger
from gameloop_optimizer.profiles.presets import build_hardware_aware_presets

_ENGINE_CODE = {"Auto": 0, "OpenGL+": 1, "DirectX+": 2}
_GFX_CODE = {"Smooth": 0, "Balanced": 1, "HD": 2, "HDR": 3}
_AA_CODE = {"Close": 0, "Balanced": 1, "Ultra": 2}


class ProfileManager:
    _ROOT = "HKCU"
    _SUBKEY = r"Software\Tencent\MobileGamePC"

    def __init__(
        self,
        backup_manager: BackupManager,
        audit_logger: AuditLogger,
        profiles_dir: Path | None = None,
    ) -> None:
        self._backup = backup_manager
        self._reg = backup_manager.registry
        self._audit = audit_logger
        self._dir = profiles_dir or get_profiles_dir()
        self._dir.mkdir(parents=True, exist_ok=True)

    def get_presets(self, hw: HardwareProfile | None = None) -> list[PubgProfile]:
        presets = build_hardware_aware_presets(hw)
        for custom in self.list_saved_custom_profiles():
            presets.append(custom)
        return presets

    def read_current_gameloop_settings(self) -> dict[str, str]:
        keys = (
            "LocalEngine",
            "VMCpuCount",
            "VMMemorySizeInMB",
            "VMResWidth",
            "VMResHeight",
            "VMDPI",
            "FPSLevel",
            "RenderQuality",
        )
        out: dict[str, str] = {}
        for name in keys:
            snap = self._reg.read_value(self._ROOT, self._SUBKEY, name)
            out[name] = str(snap.value) if snap.existed else "Not Set"
        return out

    def apply_profile(self, profile: PubgProfile) -> tuple[bool, str, str]:
        """Backup existing GameLoop engine keys, apply profile, verify, and audit."""
        mapping = {
            "LocalEngine": _ENGINE_CODE.get(profile.engine_mode, 0),
            "VMCpuCount": max(1, min(8, int(profile.cpu_cores_alloc))),
            "VMMemorySizeInMB": max(1024, min(8192, int(profile.ram_mb_alloc))),
            "VMResWidth": max(800, min(3840, int(profile.resolution_width))),
            "VMResHeight": max(600, min(2160, int(profile.resolution_height))),
            "VMDPI": max(120, min(480, int(profile.dpi))),
            "FPSLevel": max(30, min(120, int(profile.target_fps))),
            "RenderQuality": _GFX_CODE.get(profile.graphics_quality, 0),
            "AntiAliasing": _AA_CODE.get(profile.anti_aliasing, 0),
        }

        before_snaps = [self._reg.read_value(self._ROOT, self._SUBKEY, k) for k in mapping]
        record = self._backup.create_backup(
            category="pubg_profile",
            description=f"Backup before applying PUBG profile '{profile.name}'",
            registry_snapshots=before_snaps,
        )

        for key_name, val in mapping.items():
            ok, msg = self._reg.write_value(self._ROOT, self._SUBKEY, key_name, val, REG_DWORD)
            if not ok:
                self._audit.record(
                    "profile_apply", profile.profile_id, None, mapping, record.backup_id, False, msg
                )
                return False, msg, record.backup_id

        verified = all(
            (snap := self._reg.read_value(self._ROOT, self._SUBKEY, k)).existed and snap.value == v
            for k, v in mapping.items()
        )
        self._audit.record(
            "profile_apply",
            profile.profile_id,
            {s.name: s.value for s in before_snaps},
            mapping,
            record.backup_id,
            verified,
        )
        return (
            verified,
            f"Profile '{profile.name}' applied and verified (restart GameLoop to take effect)."
            if verified
            else "Profile written, but post-write verification failed.",
            record.backup_id,
        )

    def save_custom_profile(self, profile: PubgProfile) -> Path:
        safe_name = "".join(c for c in profile.profile_id if c.isalnum() or c in ("_", "-")) or "custom"
        path = self._dir / f"{safe_name}.json"
        path.write_text(json.dumps(asdict(profile), indent=2, ensure_ascii=False), encoding="utf-8")
        return path

    def list_saved_custom_profiles(self) -> list[PubgProfile]:
        found: list[PubgProfile] = []
        for path in sorted(self._dir.glob("*.json")):
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
                found.append(self._deserialize(data))
            except (OSError, ValueError, TypeError, KeyError):
                continue
        return found

    def export_profile(self, profile: PubgProfile, destination: Path) -> Path:
        destination.write_text(json.dumps(asdict(profile), indent=2, ensure_ascii=False), encoding="utf-8")
        return destination

    def import_profile(self, source: Path) -> PubgProfile:
        data = json.loads(source.read_text(encoding="utf-8"))
        profile = self._deserialize(data)
        self.save_custom_profile(profile)
        return profile

    @staticmethod
    def _deserialize(data: dict) -> PubgProfile:
        return PubgProfile(
            profile_id=str(data["profile_id"]),
            name=str(data["name"]),
            tier=str(data.get("tier", "Custom")),
            description=str(data.get("description", "")),
            engine_mode=str(data.get("engine_mode", "Auto")),
            resolution_width=max(800, min(3840, int(data["resolution_width"]))),
            resolution_height=max(600, min(2160, int(data["resolution_height"]))),
            dpi=max(120, min(480, int(data["dpi"]))),
            target_fps=max(30, min(120, int(data["target_fps"]))),
            graphics_quality=str(data.get("graphics_quality", "Smooth")),
            anti_aliasing=str(data.get("anti_aliasing", "Close")),
            cpu_cores_alloc=max(1, min(8, int(data["cpu_cores_alloc"]))),
            ram_mb_alloc=max(1024, min(8192, int(data["ram_mb_alloc"]))),
            warnings=list(data.get("warnings", [])),
        )
