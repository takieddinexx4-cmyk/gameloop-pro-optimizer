"""Glassmorphism cards, metric tiles, and severity badges."""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QFrame, QHBoxLayout, QLabel, QVBoxLayout


class GlassCard(QFrame):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("GlassCard")
        self.root_layout = QVBoxLayout(self)
        self.root_layout.setContentsMargins(16, 14, 16, 14)
        self.root_layout.setSpacing(8)


class StatusBadge(QLabel):
    _STYLES = {
        "ok": ("rgba(16, 185, 129, 0.18)", "#34D399", "rgba(16, 185, 129, 0.4)"),
        "info": ("rgba(0, 212, 255, 0.16)", "#38BDF8", "rgba(0, 212, 255, 0.35)"),
        "warning": ("rgba(245, 158, 11, 0.18)", "#FBBF24", "rgba(245, 158, 11, 0.4)"),
        "high": ("rgba(249, 115, 22, 0.20)", "#FB923C", "rgba(249, 115, 22, 0.45)"),
        "critical": ("rgba(239, 68, 68, 0.20)", "#F87171", "rgba(239, 68, 68, 0.45)"),
        "muted": ("rgba(148, 163, 184, 0.14)", "#94A3B8", "rgba(148, 163, 184, 0.3)"),
    }

    def __init__(self, text: str = "", level: str = "info", parent=None) -> None:
        super().__init__(text, parent)
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.set_level(level)

    def set_level(self, level: str) -> None:
        bg, fg, border = self._STYLES.get(level, self._STYLES["info"])
        self.setStyleSheet(
            f"background-color: {bg}; color: {fg}; border: 1px solid {border};"
            "border-radius: 10px; padding: 3px 10px; font-weight: 600; font-size: 11px;"
        )


class MetricCard(GlassCard):
    def __init__(self, title: str, value: str = "--", subtitle: str = "", parent=None) -> None:
        super().__init__(parent)
        self.title_label = QLabel(title)
        self.title_label.setObjectName("MutedLabel")

        self.value_label = QLabel(value)
        self.value_label.setObjectName("MetricValue")
        self.value_label.setWordWrap(True)

        self.subtitle_label = QLabel(subtitle)
        self.subtitle_label.setObjectName("MutedLabel")
        self.subtitle_label.setWordWrap(True)

        self.root_layout.addWidget(self.title_label)
        self.root_layout.addWidget(self.value_label)
        self.root_layout.addWidget(self.subtitle_label)

    def update_metric(self, title: str | None, value: str, subtitle: str = "") -> None:
        if title is not None:
            self.title_label.setText(title)
        self.value_label.setText(value)
        self.subtitle_label.setText(subtitle)


class SectionHeader(QFrame):
    def __init__(self, title: str, subtitle: str = "", parent=None) -> None:
        super().__init__(parent)
        self.setStyleSheet("background: transparent; border: none;")
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 4, 0, 4)

        col = QVBoxLayout()
        col.setSpacing(2)
        self.title_label = QLabel(title)
        self.title_label.setObjectName("SectionTitle")
        self.subtitle_label = QLabel(subtitle)
        self.subtitle_label.setObjectName("MutedLabel")
        self.subtitle_label.setVisible(bool(subtitle))

        col.addWidget(self.title_label)
        col.addWidget(self.subtitle_label)
        layout.addLayout(col, 1)
        self.actions_layout = QHBoxLayout()
        self.actions_layout.setSpacing(8)
        layout.addLayout(self.actions_layout)
