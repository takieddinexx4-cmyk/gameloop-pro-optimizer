"""Rotating file and console logging setup."""

from __future__ import annotations

import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path

from gameloop_optimizer.app_core.paths import get_logs_dir

_ROOT_LOGGER_NAME = "gameloop_optimizer"
_INITIALIZED = False


def setup_logging(log_dir: Path | None = None, level: int = logging.INFO) -> Path:
    """Configure rotating UTF-8 log files and return primary log file path."""
    global _INITIALIZED
    target_dir = log_dir or get_logs_dir()
    target_dir.mkdir(parents=True, exist_ok=True)
    log_file = target_dir / "app.log"

    root_logger = logging.getLogger(_ROOT_LOGGER_NAME)
    root_logger.setLevel(level)

    if not _INITIALIZED:
        formatter = logging.Formatter(
            fmt="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
        file_handler = RotatingFileHandler(
            filename=str(log_file),
            maxBytes=5 * 1024 * 1024,
            backupCount=5,
            encoding="utf-8",
        )
        file_handler.setFormatter(formatter)
        root_logger.addHandler(file_handler)

        stream_handler = logging.StreamHandler()
        stream_handler.setFormatter(formatter)
        stream_handler.setLevel(logging.WARNING)
        root_logger.addHandler(stream_handler)
        _INITIALIZED = True

    return log_file


def get_logger(module_name: str) -> logging.Logger:
    return logging.getLogger(f"{_ROOT_LOGGER_NAME}.{module_name}")
