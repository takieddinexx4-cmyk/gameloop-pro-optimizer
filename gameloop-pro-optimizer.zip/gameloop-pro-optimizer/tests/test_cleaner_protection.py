"""Strict unit tests proving Cleaner PRO protects SAV/INI/user files and uses Recycle Bin."""

from __future__ import annotations

import os
import time
from pathlib import Path

from gameloop_optimizer.app_core.config import ConfigManager
from gameloop_optimizer.app_core.models import CleanerItem
from gameloop_optimizer.cleaner.cleaner_engine import CleanerEngine
from gameloop_optimizer.cleaner.rules import is_path_protected
from gameloop_optimizer.gameloop_manager.discovery import GameLoopDiscovery
from gameloop_optimizer.logging.audit import AuditLogger


def test_cleaner_never_touches_sav_ini_or_user_files(
    tmp_path: Path,
    config_manager: ConfigManager,
    audit_logger: AuditLogger,
) -> None:
    target_dir = tmp_path / "GameLoopTemp"
    target_dir.mkdir(parents=True)

    old_log = target_dir / "old_crash.log"
    old_log.write_text("old log content", encoding="utf-8")
    old_ts = time.time() - (7 * 86400)
    os.utime(old_log, (old_ts, old_ts))

    recent_log = target_dir / "active_session.log"
    recent_log.write_text("current log", encoding="utf-8")

    temp_file = target_dir / "shader.tmp"
    temp_file.write_text("temp bytes", encoding="utf-8")

    # Protected files that MUST NEVER be deleted
    sav_file = target_dir / "Active.sav"
    ini_file = target_dir / "UserCustom.ini"
    pak_file = target_dir / "game_patch.pak"
    cfg_file = target_dir / "engine.cfg"
    for pf in (sav_file, ini_file, pak_file, cfg_file):
        pf.write_text("critical game data", encoding="utf-8")

    # User Documents directory outside approved roots
    docs_dir = tmp_path / "Documents"
    docs_dir.mkdir()
    user_doc_log = docs_dir / "notes.log"
    user_doc_log.write_text("personal", encoding="utf-8")
    prot_doc, _ = is_path_protected(user_doc_log, [target_dir])
    assert prot_doc is True

    recycled_paths: list[str] = []

    def fake_recycle_bin(path_str: str) -> None:
        recycled_paths.append(path_str)
        Path(path_str).unlink()

    config_manager.config.cleaner_log_min_age_days = 3
    discovery = GameLoopDiscovery(config_manager=config_manager, registry_reader=lambda: ("", ""))
    cleaner = CleanerEngine(
        gameloop_discovery=discovery,
        config_manager=config_manager,
        audit_logger=audit_logger,
        trash_fn=fake_recycle_bin,
        extra_target_dirs=[target_dir],
    )

    preview = cleaner.scan_preview()
    preview_paths = {Path(i.path) for i in preview.items}

    assert old_log in preview_paths
    assert temp_file in preview_paths
    assert recent_log not in preview_paths
    assert sav_file not in preview_paths
    assert ini_file not in preview_paths
    assert pak_file not in preview_paths
    assert cfg_file not in preview_paths
    assert preview.skipped_protected_count >= 4

    # Defense-in-depth: even if a forged CleanerItem targets Active.sav, execute_clean MUST block it
    forged = list(preview.items) + [
        CleanerItem(path=str(sav_file), size_bytes=10, category="forged", reason="attack", selected=True)
    ]
    res = cleaner.execute_clean(forged)

    assert res.used_recycle_bin is True
    assert res.deleted_count == 2
    assert len(res.failed_items) == 1
    assert str(sav_file) in res.failed_items[0][0]
    assert sav_file.exists()
    assert ini_file.exists()
    assert pak_file.exists()
    assert cfg_file.exists()
    assert recent_log.exists()
    assert set(Path(p) for p in recycled_paths) == {old_log, temp_file}
