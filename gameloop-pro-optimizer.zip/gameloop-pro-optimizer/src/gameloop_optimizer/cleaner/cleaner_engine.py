"""Cleaner PRO engine: mandatory preview, strict protection guard, Recycle Bin deletion."""

from __future__ import annotations

import os
import time
from pathlib import Path
from typing import Callable

from send2trash import send2trash

from gameloop_optimizer.app_core.models import CleanerItem, CleanerPreview, CleanerResult
from gameloop_optimizer.cleaner.rules import is_path_protected
from gameloop_optimizer.gameloop_manager.discovery import GameLoopDiscovery
from gameloop_optimizer.logging.audit import AuditLogger
from gameloop_optimizer.logging.logger import get_logger

logger = get_logger("cleaner")


class CleanerEngine:
    def __init__(
        self,
        gameloop_discovery: GameLoopDiscovery,
        config_manager=None,
        audit_logger: AuditLogger | None = None,
        trash_fn: Callable[[str], None] | None = None,
        extra_target_dirs: list[Path] | None = None,
    ) -> None:
        self._discovery = gameloop_discovery
        self._config_manager = config_manager
        self._audit = audit_logger or AuditLogger()
        self._trash_fn = trash_fn or send2trash
        self._extra_target_dirs = extra_target_dirs

    def _approved_roots(self) -> list[tuple[Path, str]]:
        """Collect strictly scoped GameLoop temp/log directories."""
        if self._extra_target_dirs is not None:
            return [(p, "gameloop_temp") for p in self._extra_target_dirs if p.exists() and p.is_dir()]

        roots: list[tuple[Path, str]] = []
        info = self._discovery.discover()
        for log_dir in info.logs_dirs:
            p = Path(log_dir)
            if p.is_dir():
                roots.append((p, "gameloop_logs"))

        if info.installed and info.install_dir:
            base = Path(info.install_dir)
            for sub in ("ui/Temp", "ui/ShaderCache", "Temp", "AppMarket/Temp"):
                cand = base / sub
                if cand.is_dir():
                    roots.append((cand, "gameloop_temp"))

        temp_env = os.environ.get("TEMP", "")
        if temp_env:
            for folder_name in ("TxGameAssistant", "GameLoop", "AndroidEmulator"):
                cand = Path(temp_env) / folder_name
                if cand.is_dir():
                    roots.append((cand, "windows_gameloop_temp"))

        # Deduplicate resolved paths
        unique: list[tuple[Path, str]] = []
        seen: set[str] = set()
        for path, cat in roots:
            key = str(path.resolve()).lower()
            if key not in seen:
                seen.add(key)
                unique.append((path, cat))
        return unique

    def scan_preview(self, progress_cb=None, cancel_token=None) -> CleanerPreview:
        """Scan approved temp/log folders and return full mandatory preview without deleting anything."""
        min_age_days = (
            self._config_manager.config.cleaner_log_min_age_days if self._config_manager else 3
        )
        cutoff_ts = time.time() - (min_age_days * 86400)

        root_entries = self._approved_roots()
        root_paths = [p for p, _ in root_entries]
        preview = CleanerPreview()

        if not root_entries:
            preview.scan_notes.append(
                "No GameLoop temporary or log folders found (GameLoop may not be installed or no temp files exist)."
            )
            if progress_cb:
                progress_cb(100, "Scan finished (0 items).")
            return preview

        total_roots = max(1, len(root_entries))
        for idx, (root_dir, category) in enumerate(root_entries):
            if cancel_token and cancel_token.is_cancelled:
                break
            if progress_cb:
                progress_cb(int(idx / total_roots * 100), f"Scanning {root_dir}...")

            for entry in root_dir.rglob("*"):
                if cancel_token and cancel_token.is_cancelled:
                    break
                if not entry.is_file() or entry.is_symlink():
                    continue

                protected, _reason = is_path_protected(entry, root_paths)
                if protected:
                    preview.skipped_protected_count += 1
                    continue

                try:
                    stat = entry.stat()
                except OSError:
                    continue

                # For .log files, preserve recent active logs newer than min_age_days
                if entry.suffix.lower() == ".log" and min_age_days > 0 and stat.st_mtime > cutoff_ts:
                    continue

                preview.items.append(
                    CleanerItem(
                        path=str(entry),
                        size_bytes=stat.st_size,
                        category=category,
                        reason=f"Safe {category} file ({entry.suffix.lower()})",
                        selected=True,
                    )
                )
                preview.total_size_bytes += stat.st_size

        preview.items.sort(key=lambda i: i.size_bytes, reverse=True)
        if progress_cb:
            progress_cb(100, f"Preview ready: {len(preview.items)} safe item(s) found.")
        return preview

    def execute_clean(
        self,
        items: list[CleanerItem],
        progress_cb=None,
        cancel_token=None,
    ) -> CleanerResult:
        """Move explicitly approved items to the Windows Recycle Bin after re-verifying protection."""
        result = CleanerResult(used_recycle_bin=True)
        root_paths = [p for p, _ in self._approved_roots()]
        selected_items = [item for item in items if item.selected]
        total = max(1, len(selected_items))

        for idx, item in enumerate(selected_items, start=1):
            if cancel_token and cancel_token.is_cancelled:
                break
            if progress_cb:
                progress_cb(int((idx - 1) / total * 100), f"Moving to Recycle Bin ({idx}/{total})...")

            path = Path(item.path)
            protected, reason = is_path_protected(path, root_paths)
            if protected:
                result.failed_items.append((item.path, f"Blocked by protection guard: {reason}"))
                continue
            if not path.exists():
                continue

            try:
                self._trash_fn(str(path))
                result.deleted_count += 1
                result.freed_bytes += item.size_bytes
            except Exception as exc:  # noqa: BLE001
                result.failed_items.append((item.path, str(exc)))

        self._audit.record(
            action="cleaner_recycle",
            target="gameloop_temp_logs",
            before={"requested_count": len(selected_items)},
            after={
                "deleted_count": result.deleted_count,
                "freed_bytes": result.freed_bytes,
                "failed_count": len(result.failed_items),
            },
            success=len(result.failed_items) == 0,
        )
        if progress_cb:
            progress_cb(100, "Cleanup completed (moved to Recycle Bin).")
        return result
