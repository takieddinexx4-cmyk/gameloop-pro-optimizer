"""Dynamic GameLoop installation discovery and lifecycle controller."""
