"""Shared typed dataclasses across all optimizer modules."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class MetricValue:
    """Represents a measurable system metric with explicit availability honesty."""

    value: Any = None
    unit: str = ""
    available: bool = False
    reason: str = ""

    def display(self, unavailable_label: str = "Unavailable") -> str:
        if not self.available or self.value is None:
            return unavailable_label
        if self.unit:
            return f"{self.value} {self.unit}".strip()
        return str(self.value)


@dataclass
class HardwareProfile:
    cpu_name: MetricValue = field(default_factory=MetricValue)
    cpu_cores_physical: MetricValue = field(default_factory=MetricValue)
    cpu_cores_logical: MetricValue = field(default_factory=MetricValue)
    cpu_freq_mhz: MetricValue = field(default_factory=MetricValue)
    cpu_temp_c: MetricValue = field(default_factory=MetricValue)
    ram_total_gb: MetricValue = field(default_factory=MetricValue)
    ram_available_gb: MetricValue = field(default_factory=MetricValue)
    ram_usage_percent: MetricValue = field(default_factory=MetricValue)
    gpu_name: MetricValue = field(default_factory=MetricValue)
    gpu_vram_gb: MetricValue = field(default_factory=MetricValue)
    gpu_driver_version: MetricValue = field(default_factory=MetricValue)
    gpu_temp_c: MetricValue = field(default_factory=MetricValue)
    storage_summary: MetricValue = field(default_factory=MetricValue)
    system_drive_free_gb: MetricValue = field(default_factory=MetricValue)
    gameloop_drive_free_gb: MetricValue = field(default_factory=MetricValue)
    windows_version: MetricValue = field(default_factory=MetricValue)
    display_resolution: MetricValue = field(default_factory=MetricValue)
    display_refresh_hz: MetricValue = field(default_factory=MetricValue)
    gameloop_installed: bool = False
    gameloop_path: str = ""
    gameloop_version: MetricValue = field(default_factory=MetricValue)


@dataclass
class AnalysisReport:
    hardware: HardwareProfile
    hardware_score: int
    gaming_readiness: str
    bottleneck: str
    issues: list[str] = field(default_factory=list)
    recommendations: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)


@dataclass
class GameLoopInstallInfo:
    installed: bool = False
    install_dir: str = ""
    ui_dir: str = ""
    emulator_exe: str = ""
    appmarket_exe: str = ""
    adb_exe: str = ""
    logs_dirs: list[str] = field(default_factory=list)
    config_dirs: list[str] = field(default_factory=list)
    version: str = ""
    detection_source: str = ""


@dataclass
class AdbDeviceInfo:
    serial: str
    state: str


@dataclass
class AdbStatus:
    adb_available: bool = False
    adb_path: str = ""
    server_running: bool = False
    devices: list[AdbDeviceInfo] = field(default_factory=list)
    active_ports: list[int] = field(default_factory=list)
    error: str = ""


@dataclass
class TweakState:
    current_value: Any
    available: bool = True
    is_optimized: bool = False
    reason: str = ""
    raw_snapshot: dict[str, Any] = field(default_factory=dict)


@dataclass
class TweakPreview:
    tweak_id: str
    name: str
    category: str
    risk_level: str
    requires_admin: bool
    current_display: str
    proposed_display: str
    description: str
    available: bool = True
    unavailable_reason: str = ""


@dataclass
class TweakActionResult:
    tweak_id: str
    success: bool
    message: str
    verified: bool = False
    backup_id: str = ""
    before_value: Any = None
    after_value: Any = None


@dataclass
class DiagnosticFinding:
    finding_id: str
    category: str
    title: str
    severity: str  # critical, high, medium, low, info
    cause: str
    evidence: str
    solution: str
    can_auto_fix: bool = False
    fix_action_id: str = ""


@dataclass
class CleanerItem:
    path: str
    size_bytes: int
    category: str
    reason: str
    selected: bool = True


@dataclass
class CleanerPreview:
    items: list[CleanerItem] = field(default_factory=list)
    skipped_protected_count: int = 0
    total_size_bytes: int = 0
    scan_notes: list[str] = field(default_factory=list)


@dataclass
class CleanerResult:
    deleted_count: int = 0
    freed_bytes: int = 0
    failed_items: list[tuple[str, str]] = field(default_factory=list)
    used_recycle_bin: bool = True


@dataclass
class BackupRecord:
    backup_id: str
    created_at: str
    category: str
    description: str
    sha256: str
    item_count: int
    file_path: str
    verified: bool = True


@dataclass
class PubgProfile:
    profile_id: str
    name: str
    tier: str
    description: str
    engine_mode: str  # Auto, OpenGL+, DirectX+
    resolution_width: int
    resolution_height: int
    dpi: int
    target_fps: int
    graphics_quality: str  # Smooth, Balanced, HD, HDR
    anti_aliasing: str  # Close, Balanced, Ultra
    cpu_cores_alloc: int
    ram_mb_alloc: int
    warnings: list[str] = field(default_factory=list)


@dataclass
class MonitorSnapshot:
    timestamp: float
    cpu_percent: MetricValue = field(default_factory=MetricValue)
    ram_percent: MetricValue = field(default_factory=MetricValue)
    ram_used_gb: MetricValue = field(default_factory=MetricValue)
    gpu_percent: MetricValue = field(default_factory=MetricValue)
    gpu_vram_used_mb: MetricValue = field(default_factory=MetricValue)
    gpu_vram_total_mb: MetricValue = field(default_factory=MetricValue)
    cpu_temp_c: MetricValue = field(default_factory=MetricValue)
    gpu_temp_c: MetricValue = field(default_factory=MetricValue)
    gameloop_running: bool = False
    gameloop_cpu_percent: MetricValue = field(default_factory=MetricValue)
    gameloop_ram_mb: MetricValue = field(default_factory=MetricValue)
    ping_ms: MetricValue = field(default_factory=MetricValue)
    fps: MetricValue = field(default_factory=MetricValue)
    net_sent_kbps: MetricValue = field(default_factory=MetricValue)
    net_recv_kbps: MetricValue = field(default_factory=MetricValue)


@dataclass
class DependencyStatus:
    dep_id: str
    name: str
    installed: bool
    version: str = ""
    details: str = ""
    official_url: str = ""
    status_level: str = "info"  # ok, warning, missing, info


@dataclass
class VerificationResult:
    file_path: str
    exists: bool
    sha256: str = ""
    hash_matched: Optional[bool] = None
    signature_valid: Optional[bool] = None
    publisher: str = ""
    file_version: str = ""
    details: str = ""


@dataclass
class UpdateInfo:
    checked: bool = False
    current_version: str = ""
    latest_version: str = ""
    update_available: bool = False
    release_url: str = ""
    download_url: str = ""
    sha256_url: str = ""
    release_notes: str = ""
    error: str = ""
