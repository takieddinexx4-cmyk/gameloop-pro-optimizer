"""Live Monitor page: low-overhead background polling with Liquid Glass charts, VRAM, FPS & Network."""

from __future__ import annotations

import threading

from PySide6.QtCore import QThread, Signal
from PySide6.QtWidgets import QGridLayout, QHBoxLayout, QPushButton, QScrollArea, QVBoxLayout, QWidget

from gameloop_optimizer.app_core.models import MonitorSnapshot
from gameloop_optimizer.app_core.service_container import ServiceContainer
from gameloop_optimizer.ui.pages.base_page import BasePage
from gameloop_optimizer.ui.widgets.cards import GlassCard, MetricCard, StatusBadge
from gameloop_optimizer.ui.widgets.chart_widget import RollingLineChart


class _MonitorLoopThread(QThread):
    sampled = Signal(object)

    def __init__(self, monitor, interval_ms: int) -> None:
        super().__init__()
        self._monitor = monitor
        self._interval_sec = max(0.5, interval_ms / 1000.0)
        self._stop_event = threading.Event()
        self._pause_event = threading.Event()

    def set_paused(self, paused: bool) -> None:
        if paused:
            self._pause_event.set()
        else:
            self._pause_event.clear()

    def stop(self) -> None:
        self._stop_event.set()

    def run(self) -> None:
        while not self._stop_event.is_set():
            if not self._pause_event.is_set():
                snap = self._monitor.sample()
                self.sampled.emit(snap)
            self._stop_event.wait(self._interval_sec)


class LiveMonitorPage(BasePage):
    def __init__(self, services: ServiceContainer, parent=None) -> None:
        super().__init__(services, parent)
        self._thread: _MonitorLoopThread | None = None
        self._paused = False
        self._window_seconds = 60
        self._build_ui()

    def _build_ui(self) -> None:
        ctrl_card = GlassCard()
        controls = QHBoxLayout()
        controls.setSpacing(10)

        self.start_btn = QPushButton()
        self.start_btn.setObjectName("PrimaryButton")
        self.start_btn.clicked.connect(self._start_monitor)

        self.pause_btn = QPushButton()
        self.pause_btn.setEnabled(False)
        self.pause_btn.clicked.connect(self._toggle_pause)

        self.stop_btn = QPushButton()
        self.stop_btn.setObjectName("DangerButton")
        self.stop_btn.setEnabled(False)
        self.stop_btn.clicked.connect(self._stop_monitor)

        self.state_badge = StatusBadge("IDLE", "muted")

        self.win60_btn = QPushButton()
        self.win60_btn.clicked.connect(lambda: self._set_window(60))
        self.win5m_btn = QPushButton()
        self.win5m_btn.clicked.connect(lambda: self._set_window(300))

        controls.addWidget(self.start_btn)
        controls.addWidget(self.pause_btn)
        controls.addWidget(self.stop_btn)
        controls.addWidget(self.state_badge)
        controls.addStretch(1)
        controls.addWidget(self.win60_btn)
        controls.addWidget(self.win5m_btn)
        ctrl_card.root_layout.addLayout(controls)
        self.page_layout.addWidget(ctrl_card)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        body = QWidget()
        body.setStyleSheet("background: transparent;")
        body_layout = QVBoxLayout(body)
        body_layout.setContentsMargins(0, 0, 4, 0)
        body_layout.setSpacing(12)

        grid = QGridLayout()
        grid.setSpacing(10)
        self.cpu_card = MetricCard("", "--", accent="cyan", show_bar=True)
        self.ram_card = MetricCard("", "--", accent="emerald", show_bar=True)
        self.gpu_card = MetricCard("", "--", accent="blue", show_bar=True)
        self.vram_card = MetricCard("", "--", accent="blue")
        self.temp_card = MetricCard("", "--", accent="amber")
        self.gl_card = MetricCard("", "--", accent="cyan")
        self.fps_card = MetricCard("", "--", accent="emerald")
        self.net_card = MetricCard("", "--", accent="cyan")

        grid.addWidget(self.cpu_card, 0, 0)
        grid.addWidget(self.ram_card, 0, 1)
        grid.addWidget(self.gpu_card, 0, 2)
        grid.addWidget(self.vram_card, 0, 3)
        grid.addWidget(self.temp_card, 1, 0)
        grid.addWidget(self.gl_card, 1, 1)
        grid.addWidget(self.fps_card, 1, 2)
        grid.addWidget(self.net_card, 1, 3)
        body_layout.addLayout(grid)

        charts_grid = QGridLayout()
        charts_grid.setSpacing(10)
        self.cpu_chart = RollingLineChart("CPU %", "#00E5FF", max_points=60)
        self.ram_chart = RollingLineChart("RAM %", "#10B981", max_points=60)
        self.gpu_chart = RollingLineChart("GPU %", "#3B82F6", max_points=60)
        self.net_chart = RollingLineChart("Network KB/s", "#F59E0B", max_points=60, y_max=500.0, unit=" KB/s", auto_scale=True)

        charts_grid.addWidget(self.cpu_chart, 0, 0)
        charts_grid.addWidget(self.ram_chart, 0, 1)
        charts_grid.addWidget(self.gpu_chart, 1, 0)
        charts_grid.addWidget(self.net_chart, 1, 1)
        body_layout.addLayout(charts_grid, 1)

        scroll.setWidget(body)
        self.page_layout.addWidget(scroll, 1)

    def retranslate_ui(self) -> None:
        self.start_btn.setText(self.t("monitor.start"))
        self.pause_btn.setText(self.t("monitor.resume") if self._paused else self.t("monitor.pause"))
        self.stop_btn.setText(self.t("monitor.stop"))
        self.win60_btn.setText(self.t("monitor.window_60s"))
        self.win5m_btn.setText(self.t("monitor.window_5m"))

        self.cpu_card.title_label.setText(self.t("monitor.cpu"))
        self.ram_card.title_label.setText(self.t("monitor.ram"))
        self.gpu_card.title_label.setText(self.t("monitor.gpu"))
        self.vram_card.title_label.setText(self.t("monitor.vram"))
        self.temp_card.title_label.setText(self.t("monitor.temp"))
        self.gl_card.title_label.setText(self.t("monitor.gameloop"))
        self.fps_card.title_label.setText(self.t("monitor.fps"))
        self.net_card.title_label.setText(self.t("monitor.network"))

        self.cpu_chart.set_title(self.t("monitor.cpu"))
        self.ram_chart.set_title(self.t("monitor.ram"))
        self.gpu_chart.set_title(self.t("monitor.gpu"))
        self.net_chart.set_title(self.t("monitor.network"))

    def _set_window(self, seconds: int) -> None:
        self._window_seconds = seconds
        interval_s = max(0.5, self.services.config_manager.config.monitor_interval_ms / 1000.0)
        pts = max(15, int(seconds / interval_s))
        for chart in (self.cpu_chart, self.ram_chart, self.gpu_chart, self.net_chart):
            chart.set_window_size(pts)

    def _start_monitor(self) -> None:
        if self._thread and self._thread.isRunning():
            return
        interval_ms = self.services.config_manager.config.monitor_interval_ms
        self._set_window(self._window_seconds)
        self._paused = False
        self._thread = _MonitorLoopThread(self.services.performance_monitor, interval_ms)
        self._thread.sampled.connect(self._on_snapshot)
        self._thread.start()
        self.start_btn.setEnabled(False)
        self.pause_btn.setEnabled(True)
        self.pause_btn.setText(self.t("monitor.pause"))
        self.stop_btn.setEnabled(True)
        self.state_badge.setText("LIVE")
        self.state_badge.set_level("ok")

    def _toggle_pause(self) -> None:
        if not self._thread or not self._thread.isRunning():
            return
        self._paused = not self._paused
        self._thread.set_paused(self._paused)
        self.pause_btn.setText(self.t("monitor.resume") if self._paused else self.t("monitor.pause"))
        self.state_badge.setText("PAUSED" if self._paused else "LIVE")
        self.state_badge.set_level("warning" if self._paused else "ok")

    def _stop_monitor(self) -> None:
        if self._thread:
            self._thread.stop()
            self._thread.wait(2000)
            self._thread.deleteLater()
            self._thread = None
        self._paused = False
        self.start_btn.setEnabled(True)
        self.pause_btn.setEnabled(False)
        self.pause_btn.setText(self.t("monitor.pause"))
        self.stop_btn.setEnabled(False)
        self.state_badge.setText("IDLE")
        self.state_badge.set_level("muted")

    def _on_snapshot(self, snap: MonitorSnapshot) -> None:
        unavail = self.t("common.unavailable")
        cpu_v = float(snap.cpu_percent.value) if snap.cpu_percent.available else 0.0
        ram_v = float(snap.ram_percent.value) if snap.ram_percent.available else 0.0
        gpu_v = float(snap.gpu_percent.value) if snap.gpu_percent.available else 0.0

        self.cpu_card.update_metric(None, snap.cpu_percent.display(unavail), "", bar_percent=int(cpu_v))
        self.ram_card.update_metric(
            None,
            snap.ram_percent.display(unavail),
            snap.ram_used_gb.display(unavail),
            bar_percent=int(ram_v),
        )
        self.gpu_card.update_metric(
            None,
            snap.gpu_percent.display(unavail),
            "" if snap.gpu_percent.available else snap.gpu_percent.reason,
            bar_percent=int(gpu_v) if snap.gpu_percent.available else 0,
        )

        if snap.gpu_vram_used_mb.available and snap.gpu_vram_total_mb.available:
            self.vram_card.update_metric(
                None,
                f"{snap.gpu_vram_used_mb.value} MB",
                f"/ {snap.gpu_vram_total_mb.value} MB",
            )
        else:
            self.vram_card.update_metric(None, unavail, snap.gpu_vram_used_mb.reason)

        temp_val = f"{snap.cpu_temp_c.display(unavail)} / {snap.gpu_temp_c.display(unavail)}"
        temp_sub = "" if (snap.cpu_temp_c.available or snap.gpu_temp_c.available) else snap.cpu_temp_c.reason
        self.temp_card.update_metric(None, temp_val, temp_sub)

        if snap.gameloop_running:
            self.gl_card.update_metric(
                None,
                f"CPU {snap.gameloop_cpu_percent.display(unavail)}",
                f"RAM {snap.gameloop_ram_mb.display(unavail)}",
                badge_text="RUNNING",
                badge_level="cyan",
            )
        else:
            self.gl_card.update_metric(None, self.t("dashboard.emu_stopped"), "", badge_text="IDLE", badge_level="muted")

        self.fps_card.update_metric(
            None,
            snap.fps.display(unavail),
            "" if snap.fps.available else snap.fps.reason,
        )

        if snap.net_recv_kbps.available and snap.net_sent_kbps.available:
            net_total = float(snap.net_recv_kbps.value) + float(snap.net_sent_kbps.value)
            ping_sub = f"Ping: {snap.ping_ms.display(unavail)}" if snap.ping_ms.available else f"↑ {snap.net_sent_kbps.value} KB/s"
            self.net_card.update_metric(None, f"↓ {snap.net_recv_kbps.value} KB/s", ping_sub)
            self.net_chart.push_value(net_total)
        else:
            self.net_card.update_metric(None, unavail, snap.net_recv_kbps.reason)
            self.net_chart.push_value(None)

        self.cpu_chart.push_value(float(snap.cpu_percent.value) if snap.cpu_percent.available else None)
        self.ram_chart.push_value(float(snap.ram_percent.value) if snap.ram_percent.available else None)
        self.gpu_chart.push_value(float(snap.gpu_percent.value) if snap.gpu_percent.available else None)

    def shutdown(self) -> None:
        self._stop_monitor()
        super().shutdown()
