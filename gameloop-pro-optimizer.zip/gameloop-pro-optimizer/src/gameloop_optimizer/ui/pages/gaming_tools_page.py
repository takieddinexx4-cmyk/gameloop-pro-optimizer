"""Gaming Tools page: Process/GPU Tuning, Mouse & Input, and Verified External Tools."""

from __future__ import annotations

from PySide6.QtWidgets import (
    QFileDialog,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from gameloop_optimizer.app_core.service_container import ServiceContainer
from gameloop_optimizer.ui.pages.base_page import BasePage
from gameloop_optimizer.ui.widgets.cards import GlassCard
from gameloop_optimizer.ui.widgets.dialogs import ChangeConfirmationDialog


class GamingToolsPage(BasePage):
    def __init__(self, services: ServiceContainer, parent=None) -> None:
        super().__init__(services, parent)
        self._build_ui()

    def _build_ui(self) -> None:
        self.tabs = QTabWidget()
        self.page_layout.addWidget(self.tabs, 1)

        self._build_tuning_tab()
        self._build_mouse_tab()
        self._build_external_tab()

    def _build_tuning_tab(self) -> None:
        tab = QWidget()
        lay = QVBoxLayout(tab)
        lay.setSpacing(10)

        card = GlassCard()
        self.gl_tuning_info = QLabel()
        self.gl_tuning_info.setWordWrap(True)
        card.root_layout.addWidget(self.gl_tuning_info)

        row = QHBoxLayout()
        self.gpu_pref_btn = QPushButton("Assign High-Performance GPU (GameLoop)")
        self.gpu_pref_btn.setObjectName("PrimaryButton")
        self.gpu_pref_btn.clicked.connect(self._apply_gpu_pref)

        self.prio_high_btn = QPushButton("Set Running GameLoop Priority -> Above Normal")
        self.prio_high_btn.clicked.connect(lambda: self._set_gl_priority("above_normal"))

        self.prio_norm_btn = QPushButton("Restore GameLoop Priority -> Normal")
        self.prio_norm_btn.clicked.connect(lambda: self._set_gl_priority("normal"))

        self.affinity_btn = QPushButton("Evaluate CPU Affinity for GameLoop")
        self.affinity_btn.clicked.connect(self._evaluate_gl_affinity)

        for btn in (self.gpu_pref_btn, self.prio_high_btn, self.prio_norm_btn, self.affinity_btn):
            row.addWidget(btn)
        row.addStretch(1)
        card.root_layout.addLayout(row)
        lay.addWidget(card)
        lay.addStretch(1)
        self.tabs.addTab(tab, "")

    def _build_mouse_tab(self) -> None:
        tab = QWidget()
        lay = QVBoxLayout(tab)
        lay.setSpacing(10)

        row = QHBoxLayout()
        self.mouse_inspect_btn = QPushButton()
        self.mouse_inspect_btn.setObjectName("PrimaryButton")
        self.mouse_inspect_btn.clicked.connect(self._inspect_mouse)

        self.disable_epp_btn = QPushButton()
        self.disable_epp_btn.clicked.connect(lambda: self._toggle_epp(False))

        self.enable_epp_btn = QPushButton()
        self.enable_epp_btn.clicked.connect(lambda: self._toggle_epp(True))

        row.addWidget(self.mouse_inspect_btn)
        row.addWidget(self.disable_epp_btn)
        row.addWidget(self.enable_epp_btn)
        row.addStretch(1)
        lay.addLayout(row)

        self.mouse_output = QPlainTextEdit()
        self.mouse_output.setReadOnly(True)
        lay.addWidget(self.mouse_output, 1)
        self.tabs.addTab(tab, "")

    def _build_external_tab(self) -> None:
        tab = QWidget()
        lay = QVBoxLayout(tab)
        lay.setSpacing(10)

        self.ext_table = QTableWidget(0, 4)
        self.ext_table.setHorizontalHeaderLabels(["Tool", "Publisher", "Notes", "Official Link"])
        for col in range(3):
            self.ext_table.horizontalHeader().setSectionResizeMode(col, QHeaderView.ResizeMode.Stretch)
        self.ext_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        self.ext_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        lay.addWidget(self.ext_table, 1)

        verify_card = GlassCard()
        verify_row = QHBoxLayout()
        self.expected_hash_input = QLineEdit()
        self.expected_hash_input.setPlaceholderText("Optional expected SHA-256 hash to compare...")
        self.verify_file_btn = QPushButton()
        self.verify_file_btn.setObjectName("PrimaryButton")
        self.verify_file_btn.clicked.connect(self._verify_external_file)

        verify_row.addWidget(self.expected_hash_input, 1)
        verify_row.addWidget(self.verify_file_btn)
        verify_card.root_layout.addLayout(verify_row)

        self.verify_output = QPlainTextEdit()
        self.verify_output.setReadOnly(True)
        self.verify_output.setMaximumHeight(140)
        verify_card.root_layout.addWidget(self.verify_output)
        lay.addWidget(verify_card)

        self.tabs.addTab(tab, "")

    def on_page_activated(self) -> None:
        self._refresh_tuning_info()
        self._populate_external_tools()

    def retranslate_ui(self) -> None:
        self.tabs.setTabText(0, self.t("tools.tab_tuning"))
        self.tabs.setTabText(1, self.t("tools.tab_mouse"))
        self.tabs.setTabText(2, self.t("tools.tab_external"))
        self.mouse_inspect_btn.setText(self.t("tools.mouse_inspect"))
        self.disable_epp_btn.setText(self.t("tools.mouse_disable_epp"))
        self.enable_epp_btn.setText(self.t("tools.mouse_enable_epp"))
        self.verify_file_btn.setText(self.t("tools.verify_file"))
        self._populate_external_tools()

    def _refresh_tuning_info(self) -> None:
        procs = self.services.gameloop_controller.list_running_processes()
        tweak = self.services.optimization_engine.get_tweak("gameloop_gpu_preference")
        gpu_state = tweak.read_state() if tweak else None
        gpu_txt = gpu_state.current_value if (gpu_state and gpu_state.available) else self.t("common.unavailable")
        self.gl_tuning_info.setText(
            f"Running GameLoop processes: {len(procs)}\n"
            f"Current Windows GPU Preference for GameLoop: {gpu_txt}"
        )

    def _apply_gpu_pref(self) -> None:
        tweak = self.services.optimization_engine.get_tweak("gameloop_gpu_preference")
        if not tweak:
            return
        preview = tweak.preview()
        if not preview.available:
            QMessageBox.information(self, self.t("common.info"), preview.unavailable_reason)
            return
        dlg = ChangeConfirmationDialog(
            self.t("opt.confirm_title"),
            [f"Current: {preview.current_display}", f"Proposed: {preview.proposed_display}", "Backup will be created first."],
            self.t("common.approve_apply"),
            self.t("common.cancel"),
            parent=self,
        )
        if dlg.exec() != ChangeConfirmationDialog.DialogCode.Accepted:
            return
        res = self.services.optimization_engine.apply_tweak("gameloop_gpu_preference")
        QMessageBox.information(self, self.t("common.success" if res.success else "common.warning"), res.message)
        self._refresh_tuning_info()

    def _set_gl_priority(self, level: str) -> None:
        procs = self.services.gameloop_controller.list_running_processes()
        if not procs:
            QMessageBox.information(self, self.t("common.info"), "No running GameLoop processes detected.")
            return
        msgs = []
        for p in procs:
            ok, msg = self.services.process_tools.set_process_priority(p["pid"], level)
            msgs.append(f"[{'OK' if ok else 'FAIL'}] {msg}")
        QMessageBox.information(self, self.t("common.info"), "\n".join(msgs))

    def _evaluate_gl_affinity(self) -> None:
        procs = self.services.gameloop_controller.list_running_processes()
        if not procs:
            QMessageBox.information(self, self.t("common.info"), "Start GameLoop first to evaluate CPU affinity.")
            return
        pid = procs[0]["pid"]
        recommended, cpus, reason = self.services.process_tools.evaluate_cpu_affinity(pid)
        if not recommended:
            QMessageBox.information(self, self.t("common.info"), reason)
            return
        ans = QMessageBox.question(self, self.t("common.confirm"), f"{reason}\n\nApply CPU affinity {cpus}?")
        if ans == QMessageBox.StandardButton.Yes:
            ok, msg = self.services.process_tools.apply_cpu_affinity(pid, cpus)
            QMessageBox.information(self, self.t("common.success" if ok else "common.warning"), msg)

    def _inspect_mouse(self) -> None:
        rep = self.services.mouse_tools.inspect()
        lines = [
            f"Enhance Pointer Precision (Acceleration): {'ENABLED' if rep.enhance_pointer_precision_enabled else 'DISABLED'}",
            f"MouseSensitivity (read-only): {rep.mouse_sensitivity}",
            f"MouseSpeed / Threshold1 / Threshold2: {rep.mouse_speed} / {rep.threshold1} / {rep.threshold2}",
            "",
            "Diagnostics:",
            *[f"- {f}" for f in rep.findings],
            "",
            "Notes:",
            *[f"- {n}" for n in rep.notes],
        ]
        self.mouse_output.setPlainText("\n".join(lines))

    def _toggle_epp(self, enabled: bool) -> None:
        dlg = ChangeConfirmationDialog(
            self.t("opt.confirm_title"),
            [
                f"Target: HKCU\\Control Panel\\Mouse (MouseSpeed, MouseThreshold1, MouseThreshold2)",
                f"Action: {'Enable' if enabled else 'Disable'} Windows Enhance Pointer Precision",
                "Note: MouseSensitivity will NOT be modified. Original values will be backed up first.",
            ],
            self.t("common.approve_apply"),
            self.t("common.cancel"),
            parent=self,
        )
        if dlg.exec() != ChangeConfirmationDialog.DialogCode.Accepted:
            return
        ok, msg, bid = self.services.mouse_tools.set_pointer_precision(enabled)
        QMessageBox.information(self, self.t("common.success" if ok else "common.warning"), f"{msg}\nBackup ID: {bid}")
        self._inspect_mouse()

    def _populate_external_tools(self) -> None:
        tools = self.services.external_tools.list_tools()
        self.ext_table.setRowCount(len(tools))
        for row, tool in enumerate(tools):
            self.ext_table.setItem(row, 0, QTableWidgetItem(tool["name"]))
            self.ext_table.setItem(row, 1, QTableWidgetItem(tool["publisher"]))
            self.ext_table.setItem(row, 2, QTableWidgetItem(self.t(tool["description_key"])))
            btn = QPushButton(self.t("common.open_url"))
            btn.clicked.connect(lambda _c=False, tid=tool["id"]: self._open_tool_url(tid))
            self.ext_table.setCellWidget(row, 3, btn)
        self.ext_table.resizeRowsToContents()

    def _open_tool_url(self, tool_id: str) -> None:
        ans = QMessageBox.question(
            self,
            self.t("common.confirm"),
            "Open the official vendor webpage in your default browser? Nothing will be downloaded automatically.",
        )
        if ans == QMessageBox.StandardButton.Yes:
            self.services.external_tools.open_official_url(tool_id)

    def _verify_external_file(self) -> None:
        file_path, _ = QFileDialog.getOpenFileName(self, self.t("tools.verify_file"), "", "Executables (*.exe *.msi);;All (*.*)")
        if not file_path:
            return
        res = self.services.external_tools.verify_downloaded_file(
            file_path, self.expected_hash_input.text()
        )
        lines = [
            f"File       : {res.file_path}",
            f"SHA-256    : {res.sha256}",
            f"Hash Match : {res.hash_matched if res.hash_matched is not None else 'No expected hash provided'}",
            f"Signature  : {res.signature_valid if res.signature_valid is not None else 'Unavailable'}",
            f"Publisher  : {res.publisher}",
            f"Version    : {res.file_version}",
            f"Details    : {res.details}",
        ]
        self.verify_output.setPlainText("\n".join(lines))
