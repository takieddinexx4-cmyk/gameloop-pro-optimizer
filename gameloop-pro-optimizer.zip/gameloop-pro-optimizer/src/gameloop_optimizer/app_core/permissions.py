"""Windows privilege detection and explicit on-demand elevation."""

from __future__ import annotations

import ctypes
import sys


def is_admin() -> bool:
    """Return True if running with Windows Administrator token."""
    if sys.platform != "win32":
        return False
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except (AttributeError, OSError):
        return False


def request_elevation() -> tuple[bool, str]:
    """Prompt UAC to relaunch current application elevated (only on explicit user action)."""
    if sys.platform != "win32":
        return False, "Elevation is only supported on Windows."
    if is_admin():
        return True, "Already running with Administrator privileges."

    try:
        if getattr(sys, "frozen", False):
            executable = sys.executable
            params = ""
        else:
            executable = sys.executable
            params = f'"{sys.argv[0]}"'
        result = ctypes.windll.shell32.ShellExecuteW(
            None, "runas", executable, params, None, 1
        )
        if int(result) > 32:
            return True, "Elevation prompt launched."
        return False, f"Elevation cancelled or denied (code {result})."
    except (AttributeError, OSError) as exc:
        return False, str(exc)
