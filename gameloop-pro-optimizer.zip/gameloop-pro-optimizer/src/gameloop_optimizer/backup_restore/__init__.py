"""Integrity-verified backup, snapshot, and registry/file restoration."""
