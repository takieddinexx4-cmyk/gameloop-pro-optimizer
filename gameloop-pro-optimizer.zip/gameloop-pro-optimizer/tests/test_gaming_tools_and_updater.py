"""Tests for process safety guards, mouse backup, external hash checks, and updater."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import psutil
import pytest

from gameloop_optimizer.app_core.config import ConfigManager
from gameloop_optimizer.app_core.process_runner import run_command
from gameloop_optimizer.backup_restore.manager import BackupManager
from gameloop_optimizer.backup_restore.registry_io import REG_SZ, InMemoryRegistryBackend
from gameloop_optimizer.gaming_tools.external_tools import ExternalToolsManager
from gameloop_optimizer.gaming_tools.mouse_input import MouseInputDiagnostics
from gameloop_optimizer.gaming_tools.process_tools import ProcessTools
from gameloop_optimizer.logging.audit import AuditLogger
from gameloop_optimizer.update_manager.updater import UpdateManager, parse_semver


def test_process_runner_rejects_string_shell_commands() -> None:
    with pytest.raises(ValueError):
        run_command("echo unsafe")  # type: ignore[arg-type]


def test_process_tools_blocks_protected_windows_processes(
    audit_logger: AuditLogger, monkeypatch: pytest.MonkeyPatch
) -> None:
    class FakeDefenderProc:
        def __init__(self, pid: int) -> None:
            self.pid = pid

        def name(self) -> str:
            return "MsMpEng.exe"

    monkeypatch.setattr(psutil, "Process", FakeDefenderProc)
    tools = ProcessTools(audit_logger=audit_logger)

    ok_term, msg_term = tools.terminate_process(9999)
    assert ok_term is False
    assert "blocked" in msg_term.lower()

    ok_prio, msg_prio = tools.set_process_priority(9999, "high")
    assert ok_prio is False
    assert "blocked" in msg_prio.lower()


def test_mouse_diagnostics_preserves_sensitivity_and_backs_up(
    backup_manager: BackupManager,
    mem_registry: InMemoryRegistryBackend,
    audit_logger: AuditLogger,
) -> None:
    mem_registry.write_value("HKCU", r"Control Panel\Mouse", "MouseSensitivity", "12", REG_SZ)
    mem_registry.write_value("HKCU", r"Control Panel\Mouse", "MouseSpeed", "1", REG_SZ)

    mouse = MouseInputDiagnostics(backup_manager, audit_logger)
    rep = mouse.inspect()
    assert rep.enhance_pointer_precision_enabled is True
    assert rep.mouse_sensitivity == "12"

    ok, _msg, bid = mouse.set_pointer_precision(False)
    assert ok is True
    # Sensitivity MUST remain untouched
    assert mem_registry.read_value("HKCU", r"Control Panel\Mouse", "MouseSensitivity").value == "12"
    assert mem_registry.read_value("HKCU", r"Control Panel\Mouse", "MouseSpeed").value == "0"

    # Rollback restores MouseSpeed=1
    ok_rb, _ = backup_manager.restore_backup(bid)
    assert ok_rb is True
    assert mem_registry.read_value("HKCU", r"Control Panel\Mouse", "MouseSpeed").value == "1"


def test_external_tool_sha256_verification(tmp_path: Path) -> None:
    sample = tmp_path / "installer.exe"
    payload = b"sample-installer-bytes"
    sample.write_bytes(payload)
    expected = hashlib.sha256(payload).hexdigest()

    mgr = ExternalToolsManager()
    res_ok = mgr.verify_downloaded_file(str(sample), expected_sha256=expected)
    assert res_ok.exists is True
    assert res_ok.hash_matched is True

    res_bad = mgr.verify_downloaded_file(str(sample), expected_sha256="0" * 64)
    assert res_bad.hash_matched is False


def test_update_manager_checks_github_release_and_hash(
    tmp_path: Path, config_manager: ConfigManager
) -> None:
    assert parse_semver("v1.2.0") > parse_semver("1.0.0")

    # Default placeholder owner is refused cleanly
    updater_default = UpdateManager(config_manager=config_manager)
    info_default = updater_default.check_for_updates()
    assert info_default.checked is False

    # Configured repo with mocked GitHub JSON response
    config_manager.config.github_owner = "example-owner"
    config_manager.config.github_repo = "gameloop-pro-optimizer"

    fake_release = {
        "tag_name": "v1.1.0",
        "html_url": "https://github.com/example-owner/gameloop-pro-optimizer/releases/tag/v1.1.0",
        "body": "Stability improvements",
        "assets": [
            {
                "name": "GAMELOOP PRO OPTIMIZER.exe",
                "browser_download_url": "https://github.com/example-owner/gameloop-pro-optimizer/releases/download/v1.1.0/app.exe",
            },
            {
                "name": "GAMELOOP PRO OPTIMIZER.exe.sha256",
                "browser_download_url": "https://github.com/example-owner/gameloop-pro-optimizer/releases/download/v1.1.0/app.exe.sha256",
            },
        ],
    }

    updater = UpdateManager(
        config_manager=config_manager,
        http_getter=lambda url: json.dumps(fake_release).encode("utf-8"),
    )
    info = updater.check_for_updates()
    assert info.checked is True
    assert info.update_available is True
    assert info.latest_version == "1.1.0"

    # Verify SHA-256 helper
    f = tmp_path / "app.exe"
    f.write_bytes(b"binary-release")
    digest = hashlib.sha256(b"binary-release").hexdigest()
    ok_h, _ = updater.verify_file_sha256(f, f"{digest}  GAMELOOP PRO OPTIMIZER.exe")
    assert ok_h is True
    ok_bad, _ = updater.verify_file_sha256(f, f"{'f' * 64}  GAMELOOP PRO OPTIMIZER.exe")
    assert ok_bad is False
