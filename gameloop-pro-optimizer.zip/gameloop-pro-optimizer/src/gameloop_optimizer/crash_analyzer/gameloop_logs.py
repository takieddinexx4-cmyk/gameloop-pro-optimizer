"""Targeted GameLoop log parser detecting real crash/render/virtualization patterns."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

_PATTERNS = (
    (
        "render_init_error",
        "high",
        ("opengl", "directx", "d3d11", "eglcreatecontext", "shader compile", "render fail"),
        "Graphics renderer initialization or shader failure detected in GameLoop logs.",
        "Switch GameLoop Rendering Mode between OpenGL+ and DirectX+, and verify GPU driver health.",
    ),
    (
        "oom_memory_error",
        "critical",
        ("out of memory", "bad_alloc", "memory alloc fail", "insufficient memory"),
        "Emulator memory allocation failure detected.",
        "Reduce GameLoop RAM allocation to <= 50% of total RAM and close heavy background apps.",
    ),
    (
        "vt_disabled_warning",
        "high",
        ("vt is not enabled", "virtualization disabled", "svm disabled", "vmx not supported"),
        "Hardware virtualization (Intel VT-x / AMD-V) appears disabled or blocked.",
        "Enable VT-x/AMD-V in BIOS/UEFI and check whether Hyper-V / Memory Integrity conflicts with your GameLoop build.",
    ),
    (
        "adb_socket_error",
        "medium",
        ("adb disconnect", "adb connect fail", "cannot connect to daemon", "device offline"),
        "ADB bridge connection instability logged by GameLoop.",
        "Use the Repair ADB button to restart the ADB daemon cleanly.",
    ),
)

_MAX_READ_BYTES = 256 * 1024  # Read tail 256 KB max per file for speed and low RAM


@dataclass
class LogSignatureHit:
    signature_id: str
    severity: str
    file_path: str
    evidence_line: str
    cause: str
    solution: str


def scan_gameloop_logs(logs_dirs: list[str], max_files: int = 15) -> list[LogSignatureHit]:
    hits: list[LogSignatureHit] = []
    seen_sigs: set[str] = set()
    log_files: list[Path] = []

    for d in logs_dirs:
        p = Path(d)
        if not p.is_dir():
            continue
        for candidate in p.rglob("*"):
            if candidate.is_file() and candidate.suffix.lower() in (".log", ".txt"):
                log_files.append(candidate)

    # Sort newest first
    log_files.sort(key=lambda f: f.stat().st_mtime if f.exists() else 0, reverse=True)

    for lf in log_files[:max_files]:
        try:
            size = lf.stat().st_size
            with lf.open("rb") as fh:
                if size > _MAX_READ_BYTES:
                    fh.seek(size - _MAX_READ_BYTES)
                text = fh.read().decode("utf-8", errors="replace")
        except OSError:
            continue

        for line in text.splitlines():
            low = line.lower()
            if not any(word in low for word in ("error", "fail", "crash", "warn", "vt ", "adb", "alloc")):
                continue
            for sig_id, severity, keywords, cause, solution in _PATTERNS:
                if sig_id in seen_sigs:
                    continue
                if any(k in low for k in keywords):
                    seen_sigs.add(sig_id)
                    hits.append(
                        LogSignatureHit(
                            signature_id=sig_id,
                            severity=severity,
                            file_path=str(lf),
                            evidence_line=line.strip()[:220],
                            cause=cause,
                            solution=solution,
                        )
                    )
    return hits
