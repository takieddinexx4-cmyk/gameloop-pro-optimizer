"""Orchestrates Smart Optimization modes (Safe / Advanced / Pro Custom) with rollback."""

from __future__ import annotations

from typing import Callable, Sequence

from gameloop_optimizer.app_core.models import TweakActionResult, TweakPreview
from gameloop_optimizer.app_core.process_runner import CommandResult
from gameloop_optimizer.backup_restore.manager import BackupManager
from gameloop_optimizer.gameloop_manager.discovery import GameLoopDiscovery
from gameloop_optimizer.logging.audit import AuditLogger
from gameloop_optimizer.optimization_engine.tweaks_base import BaseTweak
from gameloop_optimizer.optimization_engine.tweaks_gameloop import (
    GameLoopCompatibilityFlagsTweak,
    GameLoopGpuPreferenceTweak,
)
from gameloop_optimizer.optimization_engine.tweaks_windows import (
    DisableGameDvrTweak,
    HardwareGpuSchedulingTweak,
    HighPerformancePowerPlanTweak,
    WindowsGameModeTweak,
)


class OptimizationEngine:
    def __init__(
        self,
        backup_manager: BackupManager,
        audit_logger: AuditLogger,
        gameloop_discovery: GameLoopDiscovery,
        command_runner: Callable[[Sequence[str], float], CommandResult] | None = None,
        admin_checker: Callable[[], bool] | None = None,
    ) -> None:
        self._backup = backup_manager
        self._audit = audit_logger
        reg = backup_manager.registry

        self._power_tweak = HighPerformancePowerPlanTweak(command_runner=command_runner)
        self._backup.register_custom_restorer("power_plan", self._power_tweak.restore_power_plan)

        self._tweaks: dict[str, BaseTweak] = {
            t.tweak_id: t
            for t in (
                WindowsGameModeTweak(reg),
                DisableGameDvrTweak(reg),
                self._power_tweak,
                GameLoopGpuPreferenceTweak(reg, gameloop_discovery),
                GameLoopCompatibilityFlagsTweak(reg, gameloop_discovery),
                HardwareGpuSchedulingTweak(reg, admin_checker=admin_checker),
            )
        }
        self._last_backup_by_tweak: dict[str, str] = {}

    def list_previews(self, mode: str = "pro") -> list[TweakPreview]:
        allowed = {
            "safe": {"safe"},
            "advanced": {"safe", "advanced"},
            "pro": {"safe", "advanced", "pro"},
        }.get(mode, {"safe", "advanced", "pro"})

        return [t.preview() for t in self._tweaks.values() if t.category in allowed]

    def get_tweak(self, tweak_id: str) -> BaseTweak | None:
        return self._tweaks.get(tweak_id)

    def get_last_backup_id(self, tweak_id: str) -> str:
        return self._last_backup_by_tweak.get(tweak_id, "")

    def apply_tweak(self, tweak_id: str) -> TweakActionResult:
        tweak = self._tweaks.get(tweak_id)
        if tweak is None:
            return TweakActionResult(tweak_id, False, f"Unknown tweak ID: {tweak_id}")

        result = tweak.apply(self._backup, self._audit)
        if result.backup_id:
            self._last_backup_by_tweak[tweak_id] = result.backup_id
        return result

    def apply_many(
        self, tweak_ids: list[str], progress_cb=None, cancel_token=None
    ) -> list[TweakActionResult]:
        results: list[TweakActionResult] = []
        total = max(1, len(tweak_ids))
        for idx, tid in enumerate(tweak_ids, start=1):
            if cancel_token and cancel_token.is_cancelled:
                break
            if progress_cb:
                progress_cb(int((idx - 1) / total * 100), f"Applying {tid}...")
            results.append(self.apply_tweak(tid))
        if progress_cb:
            progress_cb(100, "Optimization complete.")
        return results

    def rollback_tweak(self, tweak_id: str, backup_id: str | None = None) -> tuple[bool, list[str]]:
        bid = backup_id or self._last_backup_by_tweak.get(tweak_id, "")
        if not bid:
            return False, [f"No backup recorded for tweak '{tweak_id}' in this session (use Backup & Restore page)."]
        return self._backup.restore_backup(bid)
