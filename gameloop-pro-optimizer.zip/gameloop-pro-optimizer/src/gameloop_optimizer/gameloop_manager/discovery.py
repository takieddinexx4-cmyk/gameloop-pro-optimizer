"""Dynamic discovery of GameLoop across Registry, processes, custom paths, and drives."""

from __future__ import annotations

import os
import shutil
import sys
from pathlib import Path
from typing import Callable

import psutil

from gameloop_optimizer.app_core.constants import GAMELOOP_PROCESS_NAMES
from gameloop_optimizer.app_core.models import GameLoopInstallInfo
from gameloop_optimizer.logging.logger import get_logger

logger = get_logger("gameloop_manager.discovery")

_EMULATOR_CANDIDATES = (
    "AndroidEmulatorEx.exe",
    "AndroidEmulatorEn.exe",
    "AndroidEmulator.exe",
)


def _read_registry_gameloop() -> tuple[str, str]:
    """Read GameLoop install directory and version from Windows Registry."""
    if sys.platform != "win32":
        return "", ""
    try:
        import winreg
    except ImportError:
        return "", ""

    targets = [
        (winreg.HKEY_CURRENT_USER, r"Software\Tencent\MobileGamePC"),
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Tencent\MobileGamePC"),
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Tencent\MobileGamePC"),
    ]
    found_path = ""
    found_ver = ""
    for root, subkey in targets:
        try:
            with winreg.OpenKey(root, subkey) as key:
                for val_name in ("InstallPath", "AppMarketPath", "UIPath"):
                    try:
                        val, _ = winreg.QueryValueEx(key, val_name)
                        if isinstance(val, str) and val.strip() and not found_path:
                            found_path = val.strip()
                    except OSError:
                        pass
                for ver_name in ("Version", "AppMarketVersion", "UI_Version"):
                    try:
                        val, _ = winreg.QueryValueEx(key, ver_name)
                        if isinstance(val, str) and val.strip() and not found_ver:
                            found_ver = val.strip()
                    except OSError:
                        pass
        except OSError:
            continue
    return found_path, found_ver


class GameLoopDiscovery:
    def __init__(
        self,
        config_manager=None,
        registry_reader: Callable[[], tuple[str, str]] | None = None,
        extra_search_roots: list[Path] | None = None,
    ) -> None:
        self._config_manager = config_manager
        self._registry_reader = registry_reader or _read_registry_gameloop
        self._extra_search_roots = extra_search_roots or []

    def discover(self) -> GameLoopInstallInfo:
        candidates: list[tuple[Path, str, str]] = []  # (path, version, source)

        # 1. Explicit custom path configured by user
        if self._config_manager is not None:
            custom = self._config_manager.config.custom_gameloop_path.strip()
            if custom:
                candidates.append((Path(custom), "", "user_custom_path"))

        # 2. Running GameLoop processes
        for proc_dir in self._find_from_running_processes():
            candidates.append((proc_dir, "", "running_process"))

        # 3. Windows Registry
        reg_path, reg_ver = self._registry_reader()
        if reg_path:
            candidates.append((Path(reg_path), reg_ver, "windows_registry"))

        # 4. Standard & non-standard roots across mounted drives
        for root_path in self._drive_candidate_dirs():
            candidates.append((root_path, reg_ver, "filesystem_scan"))

        for cand_path, version, source in candidates:
            resolved = self._inspect_directory(cand_path, version, source)
            if resolved.installed:
                return resolved

        return GameLoopInstallInfo(installed=False, detection_source="not_found")

    def _find_from_running_processes(self) -> list[Path]:
        found: list[Path] = []
        try:
            for proc in psutil.process_iter(["name", "exe"]):
                name = (proc.info.get("name") or "").lower()
                exe = proc.info.get("exe") or ""
                if name in GAMELOOP_PROCESS_NAMES and exe:
                    p = Path(exe).parent
                    if p.name.lower() in ("ui", "appmarket"):
                        p = p.parent
                    if p not in found:
                        found.append(p)
        except Exception as exc:  # noqa: BLE001
            logger.debug("Process scan for GameLoop skipped: %s", exc)
        return found

    def _drive_candidate_dirs(self) -> list[Path]:
        paths: list[Path] = list(self._extra_search_roots)
        rel_layouts = (
            Path("Program Files") / "TxGameAssistant",
            Path("Program Files (x86)") / "TxGameAssistant",
            Path("TxGameAssistant"),
            Path("GameLoop") / "TxGameAssistant",
            Path("Games") / "TxGameAssistant",
        )
        try:
            for part in psutil.disk_partitions(all=False):
                mount = Path(part.mountpoint)
                for rel in rel_layouts:
                    paths.append(mount / rel)
        except OSError:
            pass
        return paths

    def _inspect_directory(
        self, raw_dir: Path, version: str, source: str
    ) -> GameLoopInstallInfo:
        if not raw_dir.exists() or not raw_dir.is_dir():
            return GameLoopInstallInfo(installed=False)

        # Normalize if user pointed directly at `ui` or `AppMarket` subfolder
        base_dir = raw_dir
        if base_dir.name.lower() in ("ui", "appmarket") and base_dir.parent.exists():
            base_dir = base_dir.parent

        ui_dir = base_dir / "ui" if (base_dir / "ui").is_dir() else base_dir
        emulator_exe = ""
        for exe_name in _EMULATOR_CANDIDATES:
            for folder in (ui_dir, base_dir):
                candidate = folder / exe_name
                if candidate.is_file():
                    emulator_exe = str(candidate)
                    break
            if emulator_exe:
                break

        appmarket_exe = ""
        for candidate in (
            base_dir / "AppMarket" / "AppMarket.exe",
            base_dir.parent / "AppMarket" / "AppMarket.exe",
            base_dir / "AppMarket.exe",
        ):
            if candidate.is_file():
                appmarket_exe = str(candidate)
                break

        if not emulator_exe and not appmarket_exe:
            return GameLoopInstallInfo(installed=False)

        adb_exe = ""
        for candidate in (ui_dir / "adb.exe", base_dir / "adb.exe", ui_dir / "adb"):
            if candidate.is_file():
                adb_exe = str(candidate)
                break
        if not adb_exe:
            sys_adb = shutil.which("adb")
            if sys_adb:
                adb_exe = sys_adb

        logs_dirs = self._collect_existing_dirs(
            [
                ui_dir / "log",
                ui_dir / "logs",
                base_dir / "log",
                base_dir / "logs",
                base_dir / "AppMarket" / "log",
                Path(os.environ.get("TEMP", "")) / "TxGameAssistant",
                Path(os.environ.get("LOCALAPPDATA", "")) / "Tencent" / "TxGameAssistant" / "log",
            ]
        )
        config_dirs = self._collect_existing_dirs(
            [
                ui_dir,
                base_dir / "AppMarket",
                Path(os.environ.get("APPDATA", "")) / "Tencent",
                Path(os.environ.get("LOCALAPPDATA", "")) / "Tencent",
            ]
        )

        return GameLoopInstallInfo(
            installed=True,
            install_dir=str(base_dir),
            ui_dir=str(ui_dir),
            emulator_exe=emulator_exe,
            appmarket_exe=appmarket_exe,
            adb_exe=adb_exe,
            logs_dirs=logs_dirs,
            config_dirs=config_dirs,
            version=version,
            detection_source=source,
        )

    @staticmethod
    def _collect_existing_dirs(candidates: list[Path]) -> list[str]:
        seen: list[str] = []
        for path in candidates:
            if str(path) and path.exists() and path.is_dir():
                resolved = str(path)
                if resolved not in seen:
                    seen.append(resolved)
        return seen
