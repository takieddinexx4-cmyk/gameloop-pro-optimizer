"""GAMELOOP PRO OPTIMIZER package."""

from gameloop_optimizer.app_core.constants import APP_NAME, APP_VERSION

__all__ = ["APP_NAME", "APP_VERSION"]
