"""Path resolution for bundled assets and persistent user data."""

from __future__ import annotations

import os
import sys
from pathlib import Path

from gameloop_optimizer.app_core.constants import APP_DATA_FOLDER


def get_bundle_root() -> Path:
    """Return root directory for read-only bundled resources."""
    meipass = getattr(sys, "_MEIPASS", None)
    if meipass:
        return Path(meipass)
    return Path(__file__).resolve().parents[3]


def get_locales_dir() -> Path:
    return get_bundle_root() / "locales"


def get_assets_dir() -> Path:
    return get_bundle_root() / "assets"


def get_app_data_dir() -> Path:
    """Return writable per-user application data directory."""
    override = os.environ.get("GAMELOOP_OPT_DATA_DIR")
    if override:
        base = Path(override)
    else:
        local_app_data = os.environ.get("LOCALAPPDATA")
        if local_app_data:
            base = Path(local_app_data) / APP_DATA_FOLDER
        else:
            base = Path.home() / f".{APP_DATA_FOLDER.lower()}"
    base.mkdir(parents=True, exist_ok=True)
    return base


def get_logs_dir() -> Path:
    path = get_app_data_dir() / "logs"
    path.mkdir(parents=True, exist_ok=True)
    return path


def get_backups_dir() -> Path:
    path = get_app_data_dir() / "backups"
    path.mkdir(parents=True, exist_ok=True)
    return path


def get_profiles_dir() -> Path:
    path = get_app_data_dir() / "profiles"
    path.mkdir(parents=True, exist_ok=True)
    return path


def get_reports_dir() -> Path:
    path = get_app_data_dir() / "reports"
    path.mkdir(parents=True, exist_ok=True)
    return path


def get_config_file() -> Path:
    return get_app_data_dir() / "config.json"
