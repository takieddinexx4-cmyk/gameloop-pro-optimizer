"""PUBG Mobile / GameLoop hardware-capped profile manager page."""

from __future__ import annotations

from pathlib import Path

from PySide6.QtWidgets import (
    QComboBox,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QSpinBox,
)

from gameloop_optimizer.app_core.models import PubgProfile
from gameloop_optimizer.app_core.service_container import ServiceContainer
from gameloop_optimizer.ui.pages.base_page import BasePage
from gameloop_optimizer.ui.widgets.cards import GlassCard
from gameloop_optimizer.ui.widgets.dialogs import ChangeConfirmationDialog


class ProfilesPage(BasePage):
    def __init__(self, services: ServiceContainer, parent=None) -> None:
        super().__init__(services, parent)
        self._presets: list[PubgProfile] = []
        self._build_ui()

    def _build_ui(self) -> None:
        self.subtitle_label = QLabel()
        self.subtitle_label.setObjectName("MutedLabel")
        self.subtitle_label.setWordWrap(True)
        self.page_layout.addWidget(self.subtitle_label)

        top_row = QHBoxLayout()
        self.preset_combo = QComboBox()
        self.preset_combo.currentIndexChanged.connect(self._on_preset_selected)
        self.import_btn = QPushButton()
        self.import_btn.clicked.connect(self._import_json)
        self.export_btn = QPushButton()
        self.export_btn.clicked.connect(self._export_json)

        top_row.addWidget(self.preset_combo, 1)
        top_row.addWidget(self.import_btn)
        top_row.addWidget(self.export_btn)
        self.page_layout.addLayout(top_row)

        editor_card = GlassCard()
        form = QFormLayout()
        self.name_input = QLineEdit()
        self.engine_combo = QComboBox()
        self.engine_combo.addItems(["Auto", "OpenGL+", "DirectX+"])
        self.width_spin = QSpinBox()
        self.width_spin.setRange(800, 3840)
        self.height_spin = QSpinBox()
        self.height_spin.setRange(600, 2160)
        self.dpi_spin = QSpinBox()
        self.dpi_spin.setRange(120, 480)
        self.fps_combo = QComboBox()
        self.fps_combo.addItems(["30", "45", "60", "90", "120"])
        self.gfx_combo = QComboBox()
        self.gfx_combo.addItems(["Smooth", "Balanced", "HD", "HDR"])
        self.aa_combo = QComboBox()
        self.aa_combo.addItems(["Close", "Balanced", "Ultra"])
        self.cores_spin = QSpinBox()
        self.cores_spin.setRange(1, 8)
        self.ram_spin = QSpinBox()
        self.ram_spin.setRange(1024, 8192)
        self.ram_spin.setSingleStep(512)

        form.addRow("Profile Name", self.name_input)
        form.addRow("Rendering Engine", self.engine_combo)
        form.addRow("Resolution Width", self.width_spin)
        form.addRow("Resolution Height", self.height_spin)
        form.addRow("DPI", self.dpi_spin)
        form.addRow("Target FPS", self.fps_combo)
        form.addRow("Graphics Quality", self.gfx_combo)
        form.addRow("Anti-Aliasing", self.aa_combo)
        form.addRow("CPU Cores Allocation", self.cores_spin)
        form.addRow("RAM Allocation (MB)", self.ram_spin)
        editor_card.root_layout.addLayout(form)

        self.warnings_label = QLabel()
        self.warnings_label.setStyleSheet("color: #FBBF24; background: transparent;")
        self.warnings_label.setWordWrap(True)
        editor_card.root_layout.addWidget(self.warnings_label)

        btn_row = QHBoxLayout()
        self.apply_btn = QPushButton()
        self.apply_btn.setObjectName("PrimaryButton")
        self.apply_btn.clicked.connect(self._apply_current)
        self.save_custom_btn = QPushButton()
        self.save_custom_btn.clicked.connect(self._save_custom)
        btn_row.addWidget(self.apply_btn)
        btn_row.addWidget(self.save_custom_btn)
        btn_row.addStretch(1)
        editor_card.root_layout.addLayout(btn_row)
        self.page_layout.addWidget(editor_card)

        self.current_reg_title = QLabel()
        self.current_reg_title.setObjectName("SectionTitle")
        self.page_layout.addWidget(self.current_reg_title)

        self.reg_box = QPlainTextEdit()
        self.reg_box.setReadOnly(True)
        self.reg_box.setMaximumHeight(130)
        self.page_layout.addWidget(self.reg_box)

    def on_page_activated(self) -> None:
        self._reload_presets()
        self._refresh_registry_preview()

    def retranslate_ui(self) -> None:
        self.subtitle_label.setText(self.t("profiles.subtitle"))
        self.apply_btn.setText(self.t("profiles.apply"))
        self.save_custom_btn.setText(self.t("profiles.save_custom"))
        self.import_btn.setText(self.t("profiles.import"))
        self.export_btn.setText(self.t("profiles.export"))
        self.current_reg_title.setText(self.t("profiles.current_reg"))

    def _reload_presets(self) -> None:
        hw = self.services.last_analysis.hardware if self.services.last_analysis else None
        self._presets = self.services.profile_manager.get_presets(hw)
        self.preset_combo.blockSignals(True)
        self.preset_combo.clear()
        for p in self._presets:
            self.preset_combo.addItem(f"[{p.tier}] {p.name}")
        self.preset_combo.blockSignals(False)
        if self._presets:
            self._populate_form(self._presets[0])

    def _on_preset_selected(self, idx: int) -> None:
        if 0 <= idx < len(self._presets):
            self._populate_form(self._presets[idx])

    def _populate_form(self, p: PubgProfile) -> None:
        self.name_input.setText(p.name)
        self.engine_combo.setCurrentText(p.engine_mode)
        self.width_spin.setValue(p.resolution_width)
        self.height_spin.setValue(p.resolution_height)
        self.dpi_spin.setValue(p.dpi)
        self.fps_combo.setCurrentText(str(p.target_fps))
        self.gfx_combo.setCurrentText(p.graphics_quality)
        self.aa_combo.setCurrentText(p.anti_aliasing)
        self.cores_spin.setValue(p.cpu_cores_alloc)
        self.ram_spin.setValue(p.ram_mb_alloc)
        self.warnings_label.setText("\n".join(p.warnings))

    def _collect_profile(self) -> PubgProfile:
        name = self.name_input.text().strip() or "Custom Profile"
        pid = "".join(c.lower() if c.isalnum() else "_" for c in name).strip("_") or "custom"
        return PubgProfile(
            profile_id=pid,
            name=name,
            tier="Custom",
            description="User configured profile",
            engine_mode=self.engine_combo.currentText(),
            resolution_width=self.width_spin.value(),
            resolution_height=self.height_spin.value(),
            dpi=self.dpi_spin.value(),
            target_fps=int(self.fps_combo.currentText()),
            graphics_quality=self.gfx_combo.currentText(),
            anti_aliasing=self.aa_combo.currentText(),
            cpu_cores_alloc=self.cores_spin.value(),
            ram_mb_alloc=self.ram_spin.value(),
        )

    def _refresh_registry_preview(self) -> None:
        cur = self.services.profile_manager.read_current_gameloop_settings()
        self.reg_box.setPlainText("\n".join(f"{k}: {v}" for k, v in cur.items()))

    def _apply_current(self) -> None:
        prof = self._collect_profile()
        cur = self.services.profile_manager.read_current_gameloop_settings()
        lines = [
            f"Profile: {prof.name}",
            "Original HKCU\\Software\\Tencent\\MobileGamePC values will be backed up first.",
            "",
            f"Engine      : {cur.get('LocalEngine')} -> {prof.engine_mode}",
            f"Resolution  : {cur.get('VMResWidth')}x{cur.get('VMResHeight')} -> {prof.resolution_width}x{prof.resolution_height}",
            f"DPI         : {cur.get('VMDPI')} -> {prof.dpi}",
            f"Target FPS  : {cur.get('FPSLevel')} -> {prof.target_fps}",
            f"CPU Cores   : {cur.get('VMCpuCount')} -> {prof.cpu_cores_alloc}",
            f"RAM (MB)    : {cur.get('VMMemorySizeInMB')} -> {prof.ram_mb_alloc}",
        ]
        dlg = ChangeConfirmationDialog(
            self.t("opt.confirm_title"),
            lines,
            self.t("common.approve_apply"),
            self.t("common.cancel"),
            parent=self,
        )
        if dlg.exec() != ChangeConfirmationDialog.DialogCode.Accepted:
            return

        ok, msg, bid = self.services.profile_manager.apply_profile(prof)
        QMessageBox.information(self, self.t("common.success" if ok else "common.warning"), f"{msg}\nBackup ID: {bid}")
        self._refresh_registry_preview()

    def _save_custom(self) -> None:
        prof = self._collect_profile()
        path = self.services.profile_manager.save_custom_profile(prof)
        QMessageBox.information(self, self.t("common.success"), f"Saved profile to {path}")
        self._reload_presets()

    def _export_json(self) -> None:
        file_path, _ = QFileDialog.getSaveFileName(self, self.t("profiles.export"), "pubg_profile.json", "JSON (*.json)")
        if not file_path:
            return
        self.services.profile_manager.export_profile(self._collect_profile(), Path(file_path))
        QMessageBox.information(self, self.t("common.success"), f"Exported to {file_path}")

    def _import_json(self) -> None:
        file_path, _ = QFileDialog.getOpenFileName(self, self.t("profiles.import"), "", "JSON (*.json)")
        if not file_path:
            return
        try:
            prof = self.services.profile_manager.import_profile(Path(file_path))
            QMessageBox.information(self, self.t("common.success"), f"Imported profile: {prof.name}")
            self._reload_presets()
        except Exception as exc:  # noqa: BLE001
            QMessageBox.warning(self, self.t("common.error"), str(exc))
