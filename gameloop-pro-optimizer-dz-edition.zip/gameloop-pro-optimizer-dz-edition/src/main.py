"""Application entry point for GAMELOOP PRO OPTIMIZER — DZ EDITION."""

from __future__ import annotations

import sys
from pathlib import Path

# Ensure `src` directory is on sys.path (never src/gameloop_optimizer to avoid shadowing stdlib)
_SRC_DIR = Path(__file__).resolve().parent
if str(_SRC_DIR) not in sys.path:
    sys.path.insert(0, str(_SRC_DIR))


def main() -> int:
    from PySide6.QtCore import Qt
    from PySide6.QtGui import QIcon
    from PySide6.QtWidgets import QApplication

    from gameloop_optimizer.app_core.constants import APP_NAME, APP_VERSION
    from gameloop_optimizer.app_core.paths import get_assets_dir
    from gameloop_optimizer.app_core.service_container import ServiceContainer
    from gameloop_optimizer.logging.logger import get_logger, setup_logging
    from gameloop_optimizer.ui.main_window import MainWindow
    from gameloop_optimizer.ui.theme import build_stylesheet
    from gameloop_optimizer.ui.widgets.splash_screen import DzSplashScreen

    setup_logging()
    logger = get_logger("main")
    logger.info("Starting %s v%s", APP_NAME, APP_VERSION)

    QApplication.setHighDpiScaleFactorRoundingPolicy(
        Qt.HighDpiScaleFactorRoundingPolicy.PassThrough
    )
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setApplicationVersion(APP_VERSION)
    app.setStyleSheet(build_stylesheet())

    assets_dir = get_assets_dir()
    icon_png = assets_dir / "app_icon.png"
    icon_ico = assets_dir / "app_icon.ico"
    if icon_png.exists():
        app.setWindowIcon(QIcon(str(icon_png)))
    elif icon_ico.exists():
        app.setWindowIcon(QIcon(str(icon_ico)))

    splash = DzSplashScreen(assets_dir)
    splash.show_animated()
    splash.set_stage(20, "Loading configuration & localization...")
    app.processEvents()

    services = ServiceContainer()
    direction = (
        Qt.LayoutDirection.RightToLeft
        if services.translator.is_rtl
        else Qt.LayoutDirection.LeftToRight
    )
    app.setLayoutDirection(direction)

    splash.set_stage(60, services.translator.t("splash.loading_ui"))
    app.processEvents()

    window = MainWindow(services)

    splash.set_stage(100, services.translator.t("splash.ready"))
    app.processEvents()

    window.show()
    splash.close()
    splash.deleteLater()

    exit_code = app.exec()
    logger.info("Application exited with code %s", exit_code)
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
