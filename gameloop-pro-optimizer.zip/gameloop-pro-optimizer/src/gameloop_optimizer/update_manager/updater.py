"""Update checker restricted strictly to this project's GitHub Releases."""

from __future__ import annotations

import hashlib
import json
import ssl
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Callable

from gameloop_optimizer.app_core.constants import APP_VERSION, DEFAULT_GITHUB_OWNER
from gameloop_optimizer.app_core.models import UpdateInfo

_ALLOWED_HOSTS = frozenset({"api.github.com", "github.com", "objects.githubusercontent.com"})


def parse_semver(version_str: str) -> tuple[int, ...]:
    cleaned = version_str.strip().lstrip("vV").split("-", 1)[0]
    parts: list[int] = []
    for piece in cleaned.split("."):
        try:
            parts.append(int(piece))
        except ValueError:
            parts.append(0)
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts)


class UpdateManager:
    def __init__(
        self,
        config_manager,
        http_getter: Callable[[str], bytes] | None = None,
    ) -> None:
        self._config_manager = config_manager
        self._http_getter = http_getter or self._default_https_get

    @staticmethod
    def _validate_url(url: str) -> None:
        parsed = urllib.parse.urlparse(url)
        if parsed.scheme != "https" or (parsed.hostname or "").lower() not in _ALLOWED_HOSTS:
            raise ValueError(f"Blocked untrusted update URL: {url}")

    def _default_https_get(self, url: str) -> bytes:
        self._validate_url(url)
        req = urllib.request.Request(
            url,
            headers={
                "User-Agent": f"GameLoopProOptimizer/{APP_VERSION}",
                "Accept": "application/vnd.github+json",
            },
        )
        ctx = ssl.create_default_context()
        with urllib.request.urlopen(req, timeout=10.0, context=ctx) as resp:
            return resp.read()

    def check_for_updates(self, progress_cb=None, cancel_token=None) -> UpdateInfo:
        owner = self._config_manager.config.github_owner.strip()
        repo = self._config_manager.config.github_repo.strip()
        if not owner or not repo or owner == DEFAULT_GITHUB_OWNER:
            return UpdateInfo(
                checked=False,
                current_version=APP_VERSION,
                error="Configure your GitHub owner and repository name in Settings before checking updates.",
            )

        if progress_cb:
            progress_cb(30, f"Checking GitHub Releases for {owner}/{repo}...")
        api_url = f"https://api.github.com/repos/{owner}/{repo}/releases/latest"

        try:
            raw = self._http_getter(api_url)
            data = json.loads(raw.decode("utf-8"))
        except (urllib.error.URLError, TimeoutError, ValueError, OSError) as exc:
            return UpdateInfo(
                checked=False,
                current_version=APP_VERSION,
                error=f"Update check failed: {exc}",
            )

        tag = str(data.get("tag_name", "")).strip()
        latest = tag.lstrip("vV")
        html_url = str(data.get("html_url", ""))
        notes = str(data.get("body", ""))[:1200]

        exe_url = ""
        sha_url = ""
        for asset in data.get("assets", []):
            name = str(asset.get("name", "")).lower()
            dl = str(asset.get("browser_download_url", ""))
            if name.endswith(".exe"):
                exe_url = dl
            elif name.endswith(".sha256"):
                sha_url = dl

        update_available = bool(latest) and parse_semver(latest) > parse_semver(APP_VERSION)
        if progress_cb:
            progress_cb(100, "Update check complete.")

        return UpdateInfo(
            checked=True,
            current_version=APP_VERSION,
            latest_version=latest or APP_VERSION,
            update_available=update_available,
            release_url=html_url,
            download_url=exe_url,
            sha256_url=sha_url,
            release_notes=notes,
        )

    def verify_file_sha256(self, file_path: Path, expected_sha256_text: str) -> tuple[bool, str]:
        """Verify downloaded release binary against official .sha256 checksum text."""
        tokens = expected_sha256_text.strip().split()
        if not tokens or len(tokens[0]) != 64:
            return False, "Invalid SHA-256 reference text."
        expected = tokens[0].lower()

        h = hashlib.sha256()
        with file_path.open("rb") as fh:
            for chunk in iter(lambda: fh.read(65536), b""):
                h.update(chunk)
        actual = h.hexdigest().lower()
        if actual == expected:
            return True, f"SHA-256 verified: {actual}"
        return False, f"SHA-256 MISMATCH! Expected {expected}, got {actual}."
