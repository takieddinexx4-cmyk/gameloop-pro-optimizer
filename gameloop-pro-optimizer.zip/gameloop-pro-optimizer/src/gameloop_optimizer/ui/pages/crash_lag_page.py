"""Crash & Lag Center: evidence-based findings with targeted Fix Now buttons."""

from __future__ import annotations

from PySide6.QtWidgets import (
    QHBoxLayout,
    QHeaderView,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
)

from gameloop_optimizer.app_core.models import DiagnosticFinding
from gameloop_optimizer.app_core.service_container import ServiceContainer
from gameloop_optimizer.ui.pages.base_page import BasePage


class CrashLagPage(BasePage):
    def __init__(self, services: ServiceContainer, parent=None) -> None:
        super().__init__(services, parent)
        self._findings: list[DiagnosticFinding] = []
        self._build_ui()

    def _build_ui(self) -> None:
        btn_row = QHBoxLayout()
        btn_row.setSpacing(8)

        self.scan_btn = QPushButton()
        self.scan_btn.setObjectName("PrimaryButton")
        self.scan_btn.clicked.connect(self._run_full_scan)

        self.fix_crash_btn = QPushButton()
        self.fix_crash_btn.setObjectName("SuccessButton")
        self.fix_crash_btn.clicked.connect(self._run_auto_fixes)

        self.lag_btn = QPushButton()
        self.lag_btn.clicked.connect(self._run_lag_check)

        self.repair_adb_btn = QPushButton()
        self.repair_adb_btn.clicked.connect(self._repair_adb)

        self.health_btn = QPushButton()
        self.health_btn.clicked.connect(self._run_full_scan)

        self.report_btn = QPushButton()
        self.report_btn.clicked.connect(self._generate_report)

        for btn in (
            self.scan_btn,
            self.fix_crash_btn,
            self.lag_btn,
            self.repair_adb_btn,
            self.health_btn,
            self.report_btn,
        ):
            btn_row.addWidget(btn)
        btn_row.addStretch(1)
        self.page_layout.addLayout(btn_row)

        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(
            ["Issue", "Severity", "Cause", "Evidence", "Solution", "Action"]
        )
        for col in range(5):
            self.table.horizontalHeader().setSectionResizeMode(col, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(5, QHeaderView.ResizeMode.ResizeToContents)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        self.page_layout.addWidget(self.table, 1)

    def retranslate_ui(self) -> None:
        self.scan_btn.setText(self.t("crash.scan"))
        self.fix_crash_btn.setText(self.t("crash.fix_crash"))
        self.lag_btn.setText(self.t("crash.diagnose_lag"))
        self.repair_adb_btn.setText(self.t("crash.repair_adb"))
        self.health_btn.setText(self.t("crash.health_check"))
        self.report_btn.setText(self.t("crash.generate_report"))
        self._render_findings()

    def _run_full_scan(self) -> None:
        def on_done(findings: list[DiagnosticFinding]) -> None:
            self._findings = findings
            self._render_findings()

        self.run_background_task(
            self.t("crash.scan"),
            self.services.crash_analyzer.run_full_scan,
            on_done,
        )

    def _run_lag_check(self) -> None:
        def task(progress_cb=None, cancel_token=None) -> list[DiagnosticFinding]:
            if progress_cb:
                progress_cb(40, "Evaluating RAM, CPU, and storage pressure...")
            out = self.services.crash_analyzer.diagnose_lag_checks()
            if progress_cb:
                progress_cb(100, "Lag diagnostics complete.")
            return out

        def on_done(findings: list[DiagnosticFinding]) -> None:
            self._findings = findings or [
                DiagnosticFinding(
                    finding_id="lag_ok",
                    category="lag",
                    title="No Immediate System Resource Bottleneck Detected",
                    severity="info",
                    cause="CPU, RAM, and disk free space are currently within healthy ranges.",
                    evidence="Real-time psutil/storage probe.",
                    solution="If lag occurs inside matches, record a Live Monitor session while playing.",
                )
            ]
            self._render_findings()

        self.run_background_task(self.t("crash.diagnose_lag"), task, on_done)

    def _repair_adb(self) -> None:
        def on_done(res: tuple[bool, str]) -> None:
            ok, msg = res
            QMessageBox.information(self, self.t("common.success" if ok else "common.warning"), msg)

        self.run_background_task(self.t("crash.repair_adb"), self.services.adb_manager.repair, on_done)

    def _run_auto_fixes(self) -> None:
        fixable = [f for f in self._findings if f.can_auto_fix and f.fix_action_id]
        if not fixable:
            QMessageBox.information(
                self,
                self.t("common.info"),
                "No safe automated fixes pending. Run a Full Scan first or follow manual guidance listed.",
            )
            return
        logs: list[str] = []
        for f in fixable:
            ok, msg = self.services.crash_analyzer.execute_fix(f.fix_action_id)
            logs.append(f"[{'OK' if ok else 'FAIL'}] {f.title}: {msg}")
        QMessageBox.information(self, self.t("common.info"), "\n".join(logs))

    def _trigger_single_fix(self, finding: DiagnosticFinding) -> None:
        ok, msg = self.services.crash_analyzer.execute_fix(finding.fix_action_id)
        QMessageBox.information(self, self.t("common.success" if ok else "common.warning"), msg)

    def _generate_report(self) -> None:
        if not self._findings:
            QMessageBox.information(self, self.t("common.info"), "Run a scan before generating a report.")
            return
        path = self.services.crash_analyzer.generate_report(self._findings)
        QMessageBox.information(self, self.t("common.success"), f"Diagnostic report saved to:\n{path}")

    def _render_findings(self) -> None:
        self.table.setRowCount(len(self._findings))
        for row, f in enumerate(self._findings):
            self.table.setItem(row, 0, QTableWidgetItem(f.title))
            self.table.setItem(row, 1, QTableWidgetItem(f.severity.upper()))
            self.table.setItem(row, 2, QTableWidgetItem(f.cause))
            self.table.setItem(row, 3, QTableWidgetItem(f.evidence))
            self.table.setItem(row, 4, QTableWidgetItem(f.solution))

            if f.can_auto_fix and f.fix_action_id:
                btn = QPushButton(self.t("crash.fix_now"))
                btn.setObjectName("PrimaryButton")
                btn.clicked.connect(lambda _c=False, item=f: self._trigger_single_fix(item))
                self.table.setCellWidget(row, 5, btn)
            else:
                self.table.setItem(row, 5, QTableWidgetItem(self.t("crash.manual_only")))
        self.table.resizeRowsToContents()
