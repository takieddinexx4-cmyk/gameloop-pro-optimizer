"""Lightweight live system, GameLoop, ping, and trusted FPS telemetry."""
