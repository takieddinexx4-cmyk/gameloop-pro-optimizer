"""Lightweight telemetry collector for 60s and 5m live performance charts."""

from __future__ import annotations

import socket
import time

import psutil

from gameloop_optimizer.app_core.constants import GAMELOOP_PROCESS_NAMES
from gameloop_optimizer.app_core.models import MetricValue, MonitorSnapshot
from gameloop_optimizer.hardware_detection.sensors import SensorProbe
from gameloop_optimizer.performance_monitor.fps_reader import RtssFpsReader


class PerformanceMonitor:
    def __init__(
        self,
        config_manager=None,
        sensor_probe: SensorProbe | None = None,
        fps_reader: RtssFpsReader | None = None,
    ) -> None:
        self._config_manager = config_manager
        self._sensors = sensor_probe or SensorProbe()
        self._fps_reader = fps_reader or RtssFpsReader()
        self._tick = 0
        self._cached_temps = (
            MetricValue(available=False, reason="Not sampled yet."),
            MetricValue(available=False, reason="Not sampled yet."),
        )
        self._cached_gpu_load = MetricValue(available=False, reason="Not sampled yet.")
        # Prime cpu_percent once so subsequent interval=None calls are non-blocking
        psutil.cpu_percent(interval=None)

    def sample(self) -> MonitorSnapshot:
        now = time.time()
        self._tick += 1

        cpu_pct = round(psutil.cpu_percent(interval=None), 1)
        vm = psutil.virtual_memory()
        ram_pct = round(vm.percent, 1)
        ram_used_gb = round(vm.used / (1024**3), 2)

        # Poll slower hardware sensors every 3 ticks to keep CPU overhead minimal
        if self._tick == 1 or self._tick % 3 == 0:
            self._cached_temps = self._sensors.read_temperatures()
            self._cached_gpu_load = self._sensors.read_gpu_utilization()

        gl_running, gl_cpu, gl_ram_mb = self._sample_gameloop_processes()
        ping_metric = self._sample_tcp_ping()
        fps_metric = self._fps_reader.read_fps()

        return MonitorSnapshot(
            timestamp=now,
            cpu_percent=MetricValue(value=cpu_pct, unit="%", available=True),
            ram_percent=MetricValue(value=ram_pct, unit="%", available=True),
            ram_used_gb=MetricValue(value=ram_used_gb, unit="GB", available=True),
            gpu_percent=self._cached_gpu_load,
            cpu_temp_c=self._cached_temps[0],
            gpu_temp_c=self._cached_temps[1],
            gameloop_running=gl_running,
            gameloop_cpu_percent=(
                MetricValue(value=round(gl_cpu, 1), unit="%", available=True)
                if gl_running
                else MetricValue(available=False, reason="GameLoop not running.")
            ),
            gameloop_ram_mb=(
                MetricValue(value=round(gl_ram_mb, 1), unit="MB", available=True)
                if gl_running
                else MetricValue(available=False, reason="GameLoop not running.")
            ),
            ping_ms=ping_metric,
            fps=fps_metric,
        )

    @staticmethod
    def _sample_gameloop_processes() -> tuple[bool, float, float]:
        running = False
        total_cpu = 0.0
        total_ram_mb = 0.0
        cores = max(1, psutil.cpu_count(logical=True) or 1)
        for proc in psutil.process_iter(["name", "memory_info"]):
            try:
                name = (proc.info.get("name") or "").lower()
                if name in GAMELOOP_PROCESS_NAMES:
                    running = True
                    total_cpu += proc.cpu_percent(interval=None) / cores
                    mem = proc.info.get("memory_info")
                    if mem:
                        total_ram_mb += mem.rss / (1024 * 1024)
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        return running, total_cpu, total_ram_mb

    def _sample_tcp_ping(self) -> MetricValue:
        if not self._config_manager or not self._config_manager.config.enable_ping_monitor:
            return MetricValue(available=False, reason="Ping monitor is disabled in Settings.")
        host = self._config_manager.config.ping_target_host.strip() or "1.1.1.1"
        t0 = time.perf_counter()
        try:
            with socket.create_connection((host, 443), timeout=1.0):
                ms = round((time.perf_counter() - t0) * 1000.0, 1)
                return MetricValue(value=ms, unit="ms", available=True)
        except OSError as exc:
            return MetricValue(available=False, reason=f"TCP ping to {host} failed: {exc}")
