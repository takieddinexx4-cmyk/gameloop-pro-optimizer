"""Read-only RivaTuner Statistics Server (RTSSSharedMemoryV2) FPS reader.

Never fabricates FPS. Returns Unavailable if RTSS shared memory is not active.
"""

from __future__ import annotations

import mmap
import struct
import sys

from gameloop_optimizer.app_core.constants import GAMELOOP_PROCESS_NAMES
from gameloop_optimizer.app_core.models import MetricValue


class RtssFpsReader:
    """Reads real framerate from RTSS shared memory when RTSS is running on Windows."""

    def read_fps(self) -> MetricValue:
        if sys.platform != "win32":
            return MetricValue(
                available=False,
                reason="Trusted FPS telemetry requires RTSS on Windows.",
            )
        try:
            # Open existing RTSSSharedMemoryV2 read-only without creating a blank mapping
            mm = mmap.mmap(-1, 65536, tagname="RTSSSharedMemoryV2", access=mmap.ACCESS_READ)
        except OSError:
            return MetricValue(
                available=False,
                reason="Unavailable (start RivaTuner Statistics Server / RTSS for trusted FPS telemetry).",
            )

        try:
            header = mm[:32]
            if len(header) < 32:
                return MetricValue(available=False, reason="RTSS shared memory header incomplete.")
            sig, _ver, arr_entry_size, arr_offset, arr_size = struct.unpack_from("<4sIIII", header, 0)
            if sig != b"RTSS" or arr_entry_size < 280 or arr_size == 0:
                return MetricValue(
                    available=False,
                    reason="RTSS shared memory inactive (run RTSS with GameLoop active).",
                )

            best_fps: float | None = None
            max_entries = min(arr_size, 64)
            for idx in range(max_entries):
                pos = arr_offset + idx * arr_entry_size
                if pos + 280 > len(mm):
                    break
                # RTSS_SHARED_MEMORY_APP_ENTRY starts with dwProcessID (I) + szName (260s) + dwFlags (I) +
                # dwTime0 (I) + dwTime1 (I) + dwFrames (I) + dwFrameTime (I)
                pid, raw_name = struct.unpack_from("<I260s", mm, pos)
                if pid == 0:
                    continue
                exe_name = raw_name.split(b"\x00", 1)[0].decode("mbcs", errors="ignore").lower()
                dw_time0, dw_time1, dw_frames, dw_frame_time = struct.unpack_from("<IIII", mm, pos + 268)

                fps_val = 0.0
                if dw_frame_time > 0:
                    fps_val = 1_000_000.0 / float(dw_frame_time)
                elif dw_time1 > dw_time0 and dw_frames > 0:
                    fps_val = (dw_frames * 1000.0) / float(dw_time1 - dw_time0)

                if fps_val > 0.5:
                    if any(gl in exe_name for gl in GAMELOOP_PROCESS_NAMES):
                        return MetricValue(value=round(fps_val, 1), unit="FPS (RTSS)", available=True)
                    best_fps = best_fps or round(fps_val, 1)

            if best_fps is not None:
                return MetricValue(value=best_fps, unit="FPS (RTSS)", available=True)
            return MetricValue(available=False, reason="RTSS active, but no 3D game frame telemetry yet.")
        except (struct.error, ValueError, OSError):
            return MetricValue(available=False, reason="Could not parse RTSS shared memory.")
        finally:
            mm.close()
