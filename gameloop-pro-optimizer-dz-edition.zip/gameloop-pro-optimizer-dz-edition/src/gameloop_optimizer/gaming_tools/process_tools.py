"""Safe process management with strict Windows system-process protection and rich telemetry."""

from __future__ import annotations

import os
from pathlib import Path
import subprocess
import sys
from typing import Any

import psutil

from gameloop_optimizer.app_core.constants import (
    GAMELOOP_PROCESS_NAMES,
    PROTECTED_SYSTEM_PROCESSES,
)
from gameloop_optimizer.logging.audit import AuditLogger

_PRIORITY_MAP_WIN = {
    "normal": getattr(psutil, "NORMAL_PRIORITY_CLASS", 0x20),
    "above_normal": getattr(psutil, "ABOVE_NORMAL_PRIORITY_CLASS", 0x8000),
    "high": getattr(psutil, "HIGH_PRIORITY_CLASS", 0x80),
}


class ProcessTools:
    def __init__(self, audit_logger: AuditLogger | None = None) -> None:
        self._audit = audit_logger or AuditLogger()

    def get_system_summary(self) -> dict[str, Any]:
        """Return real-time system summary metrics for Process Manager top stat cards."""
        total_procs = 0
        gameloop_procs = 0
        for proc in psutil.process_iter(["name"]):
            try:
                name = (proc.info.get("name") or "").lower()
                if not name:
                    continue
                total_procs += 1
                if name in GAMELOOP_PROCESS_NAMES:
                    gameloop_procs += 1
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        cpu_pct = round(float(psutil.cpu_percent(interval=None)), 1)
        vm = psutil.virtual_memory()
        ram_pct = round(float(vm.percent), 1)
        ram_used_gb = round(vm.used / (1024**3), 2)
        ram_total_gb = round(vm.total / (1024**3), 2)
        return {
            "total_processes": total_procs,
            "gameloop_processes": gameloop_procs,
            "cpu_percent": cpu_pct,
            "ram_percent": ram_pct,
            "ram_used_gb": ram_used_gb,
            "ram_total_gb": ram_total_gb,
        }

    def list_processes(self, limit: int = 200) -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        attrs = ["pid", "name", "memory_info", "cpu_percent", "status", "exe"]
        for proc in psutil.process_iter(attrs):
            try:
                name = proc.info.get("name") or ""
                if not name:
                    continue
                mem = proc.info.get("memory_info")
                ram_mb = round(mem.rss / (1024 * 1024), 1) if mem else 0.0
                exe_path = proc.info.get("exe") or ""
                status = str(proc.info.get("status") or "running")
                rows.append(
                    {
                        "pid": proc.info["pid"],
                        "name": name,
                        "cpu_percent": round(float(proc.info.get("cpu_percent") or 0.0), 1),
                        "ram_mb": ram_mb,
                        "status": status,
                        "exe_path": str(exe_path),
                        "is_gameloop": name.lower() in GAMELOOP_PROCESS_NAMES,
                        "is_protected": (
                            name.lower() in PROTECTED_SYSTEM_PROCESSES
                            or proc.info["pid"] in (0, 4, os.getpid())
                        ),
                    }
                )
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        rows.sort(key=lambda r: (not r["is_gameloop"], -r["ram_mb"]))
        return rows[:limit]

    def get_process_details(self, pid: int) -> tuple[bool, dict[str, Any] | str]:
        """Inspect detailed, real process metadata safely without mutating state."""
        try:
            proc = psutil.Process(pid)
            name = proc.name()
            exe_path = ""
            try:
                exe_path = proc.exe() or ""
            except (psutil.AccessDenied, psutil.NoSuchProcess, OSError):
                exe_path = ""
            username = ""
            try:
                username = proc.username() or ""
            except (psutil.AccessDenied, psutil.NoSuchProcess, OSError):
                username = ""
            mem = proc.memory_info()
            ram_mb = round(mem.rss / (1024 * 1024), 1) if mem else 0.0
            return True, {
                "pid": pid,
                "name": name,
                "status": str(proc.status()),
                "cpu_percent": round(float(proc.cpu_percent(interval=None)), 1),
                "ram_mb": ram_mb,
                "num_threads": int(proc.num_threads()),
                "username": username,
                "exe_path": exe_path,
                "is_gameloop": name.lower() in GAMELOOP_PROCESS_NAMES,
                "is_protected": (
                    name.lower() in PROTECTED_SYSTEM_PROCESSES
                    or pid in (0, 4, os.getpid())
                ),
            }
        except psutil.NoSuchProcess:
            return False, f"Process PID {pid} no longer exists."
        except psutil.AccessDenied:
            return False, f"Access denied inspecting PID {pid}."
        except OSError as exc:
            return False, str(exc)

    def open_file_location(self, exe_path: str) -> tuple[bool, str]:
        """Open Windows Explorer highlighting the executable path safely (never invokes a shell)."""
        if not exe_path:
            return False, "Executable path is unavailable for this process."
        path = Path(exe_path)
        if not path.exists():
            return False, f"Path does not exist: {exe_path}"
        try:
            if sys.platform == "win32":
                subprocess.Popen(
                    ["explorer.exe", f"/select,{str(path)}"],
                    shell=False,
                )
                return True, f"Opened location for {path.name}."
            return False, f"File location: {path.parent}"
        except OSError as exc:
            return False, str(exc)

    def set_process_priority(self, pid: int, level: str) -> tuple[bool, str]:
        if level not in _PRIORITY_MAP_WIN:
            return False, "Unsupported or unsafe priority level (Realtime is intentionally blocked)."
        try:
            proc = psutil.Process(pid)
            name = proc.name()
            if name.lower() in PROTECTED_SYSTEM_PROCESSES or pid in (0, 4):
                return False, f"Blocked: '{name}' is a protected Windows system process."
            if sys.platform != "win32":
                return False, "Windows priority classes are only supported on Windows."
            before = proc.nice()
            target_cls = _PRIORITY_MAP_WIN[level]
            proc.nice(target_cls)
            after = proc.nice()
            self._audit.record("process_priority", f"{name} ({pid})", before, after, success=True)
            return True, f"Set {name} priority to {level}."
        except psutil.AccessDenied:
            return False, "Access denied. Run as Administrator to modify this process priority."
        except psutil.NoSuchProcess:
            return False, f"Process PID {pid} no longer exists."
        except OSError as exc:
            return False, str(exc)

    def evaluate_cpu_affinity(self, pid: int) -> tuple[bool, list[int], str]:
        """Recommend CPU affinity ONLY when enough logical cores exist to avoid starvation."""
        logical = psutil.cpu_count(logical=True) or 1
        if logical < 6:
            return (
                False,
                list(range(logical)),
                f"Affinity pinning is NOT recommended on {logical}-thread CPUs (reduces scheduling headroom).",
            )
        try:
            proc = psutil.Process(pid)
            name = proc.name()
            if name.lower() in PROTECTED_SYSTEM_PROCESSES or pid in (0, 4):
                return False, [], f"Blocked: '{name}' is a protected system process."
            recommended = list(range(1, logical))
            return (
                True,
                recommended,
                f"Optional: Pinning {name} off CPU 0 (threads 1..{logical - 1}) can reduce OS interrupt contention. Measure frame stability and revert if no improvement.",
            )
        except (psutil.NoSuchProcess, psutil.AccessDenied) as exc:
            return False, [], str(exc)

    def apply_cpu_affinity(self, pid: int, cpus: list[int]) -> tuple[bool, str]:
        try:
            proc = psutil.Process(pid)
            name = proc.name()
            if name.lower() in PROTECTED_SYSTEM_PROCESSES or pid in (0, 4):
                return False, f"Blocked: '{name}' is a protected Windows process."
            before = proc.cpu_affinity()
            proc.cpu_affinity(cpus)
            after = proc.cpu_affinity()
            self._audit.record("cpu_affinity", f"{name} ({pid})", before, after, success=True)
            return True, f"Updated CPU affinity for {name} to {after}."
        except psutil.AccessDenied:
            return False, "Access denied. Administrator privileges may be required."
        except (psutil.NoSuchProcess, ValueError, AttributeError) as exc:
            return False, str(exc)

    def terminate_process(self, pid: int) -> tuple[bool, str]:
        if pid in (0, 4, os.getpid()):
            return False, "Blocked for stability: cannot terminate critical system or self process."
        try:
            proc = psutil.Process(pid)
            name = proc.name()
            if name.lower() in PROTECTED_SYSTEM_PROCESSES:
                return False, f"Blocked for Windows safety: cannot terminate '{name}'."
            proc.terminate()
            self._audit.record("process_terminate", f"{name} ({pid})", "running", "terminated", success=True)
            return True, f"Sent terminate signal to {name} (PID {pid})."
        except psutil.AccessDenied:
            return False, "Access denied terminating process."
        except psutil.NoSuchProcess:
            return False, f"Process PID {pid} already exited."
