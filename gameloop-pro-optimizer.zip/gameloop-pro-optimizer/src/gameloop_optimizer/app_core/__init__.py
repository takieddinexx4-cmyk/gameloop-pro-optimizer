"""Core primitives, configuration, models, localization, and safe execution helpers."""
