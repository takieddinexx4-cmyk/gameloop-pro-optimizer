"""Deterministic, transparent hardware scoring and bottleneck analysis."""

from __future__ import annotations

from gameloop_optimizer.app_core.models import AnalysisReport, HardwareProfile


class HardwareAnalyzer:
    """Evaluates PC readiness for GameLoop/PUBG Mobile without fabricated claims."""

    def analyze(self, hw: HardwareProfile) -> AnalysisReport:
        issues: list[str] = []
        recommendations: list[str] = []
        notes: list[str] = []

        # 1. CPU score (max 30)
        cpu_score = 0
        cores = hw.cpu_cores_physical.value if hw.cpu_cores_physical.available else 0
        threads = hw.cpu_cores_logical.value if hw.cpu_cores_logical.available else 0
        if cores >= 8:
            cpu_score = 30
        elif cores >= 6:
            cpu_score = 25
        elif cores >= 4:
            cpu_score = 19 if threads >= 8 else 15
        elif cores >= 2:
            cpu_score = 8
            issues.append("Low physical CPU core count (< 4 cores) limits emulator stability.")
            recommendations.append("Use Low-End PUBG profile and close background apps while playing.")
        else:
            notes.append("CPU core count unavailable; CPU score omitted.")

        # 2. RAM score (max 25)
        ram_score = 0
        ram_gb = float(hw.ram_total_gb.value) if hw.ram_total_gb.available else 0.0
        if ram_gb >= 16:
            ram_score = 25
        elif ram_gb >= 12:
            ram_score = 20
        elif ram_gb >= 8:
            ram_score = 14
            recommendations.append("Keep browser tabs and overlays closed to preserve free RAM for GameLoop.")
        elif ram_gb > 0:
            ram_score = 6
            issues.append(f"Total RAM ({ram_gb} GB) is below 8 GB recommended minimum for smooth emulation.")
            recommendations.append("Allocate conservative RAM in GameLoop and avoid high texture presets.")

        if hw.ram_usage_percent.available and float(hw.ram_usage_percent.value) >= 85.0:
            issues.append(f"High current RAM pressure ({hw.ram_usage_percent.value}% used).")
            recommendations.append("Check Process Manager for heavy background applications.")

        # 3. GPU score (max 30)
        gpu_score = 10  # Neutral baseline when GPU details are incomplete
        gpu_name_lower = str(hw.gpu_name.value or "").lower() if hw.gpu_name.available else ""
        vram = float(hw.gpu_vram_gb.value) if hw.gpu_vram_gb.available else None
        integrated_hint = any(k in gpu_name_lower for k in ("intel(r) uhd", "intel(r) hd", "microsoft basic"))

        if vram is not None:
            if vram >= 8 and not integrated_hint:
                gpu_score = 30
            elif vram >= 4 and not integrated_hint:
                gpu_score = 24
            elif vram >= 2 and not integrated_hint:
                gpu_score = 16
            else:
                gpu_score = 8
                issues.append(f"Limited dedicated GPU VRAM ({vram} GB) may cause texture stutter.")
                recommendations.append("Select Smooth graphics and disable high Anti-Aliasing in PUBG.")
        elif integrated_hint:
            gpu_score = 8
            issues.append("Integrated graphics detected; avoid high resolutions or heavy shaders.")
        else:
            notes.append("GPU VRAM could not be read reliably; GPU score uses conservative baseline.")

        # 4. Storage score (max 15)
        storage_score = 10
        free_gb = (
            float(hw.gameloop_drive_free_gb.value)
            if hw.gameloop_drive_free_gb.available
            else (float(hw.system_drive_free_gb.value) if hw.system_drive_free_gb.available else None)
        )
        if free_gb is not None:
            if free_gb >= 40:
                storage_score = 15
            elif free_gb >= 20:
                storage_score = 11
            elif free_gb >= 10:
                storage_score = 6
                issues.append(f"Low free disk space ({free_gb} GB) can slow shader caching and paging.")
                recommendations.append("Free disk space or run Cleaner PRO preview on old GameLoop logs.")
            else:
                storage_score = 2
                issues.append(f"Critically low disk space ({free_gb} GB free).")
                recommendations.append("Free at least 15–20 GB on the system and GameLoop drives.")

        if not hw.cpu_temp_c.available:
            notes.append("CPU temperature sensor unavailable; thermal throttling could not be checked.")
        elif float(hw.cpu_temp_c.value) >= 85.0:
            issues.append(f"Elevated CPU temperature detected ({hw.cpu_temp_c.value} °C).")
            recommendations.append("Verify cooling, fan curves, and thermal paste before increasing workloads.")

        if not hw.gameloop_installed:
            issues.append("GameLoop installation was not detected automatically.")
            recommendations.append("Install GameLoop or specify a custom GameLoop folder in Settings.")

        total_score = max(0, min(100, cpu_score + ram_score + gpu_score + storage_score))

        if total_score >= 80:
            readiness = "High Performance"
        elif total_score >= 60:
            readiness = "Balanced Gaming"
        elif total_score >= 40:
            readiness = "Entry / Mid-Range"
        else:
            readiness = "Low-End"

        bottleneck = self._determine_bottleneck(cpu_score, ram_score, gpu_score, storage_score)

        if not recommendations:
            recommendations.append("Hardware looks healthy; focus on Safe optimizations and a balanced PUBG profile.")

        return AnalysisReport(
            hardware=hw,
            hardware_score=total_score,
            gaming_readiness=readiness,
            bottleneck=bottleneck,
            issues=issues,
            recommendations=recommendations,
            notes=notes,
        )

    @staticmethod
    def _determine_bottleneck(cpu_s: int, ram_s: int, gpu_s: int, storage_s: int) -> str:
        ratios = {
            "CPU": cpu_s / 30.0,
            "RAM": ram_s / 25.0,
            "GPU / VRAM": gpu_s / 30.0,
            "Storage Free Space": storage_s / 15.0,
        }
        weakest_name, weakest_ratio = min(ratios.items(), key=lambda kv: kv[1])
        if weakest_ratio >= 0.75:
            return "No major hardware bottleneck detected"
        return weakest_name
