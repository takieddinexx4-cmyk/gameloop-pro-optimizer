"""Structured JSONL audit log recording before/after values of every change."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from gameloop_optimizer.app_core.paths import get_logs_dir


class AuditLogger:
    def __init__(self, log_dir: Path | None = None) -> None:
        self._dir = log_dir or get_logs_dir()
        self._dir.mkdir(parents=True, exist_ok=True)
        self._file = self._dir / "audit.jsonl"

    @property
    def file_path(self) -> Path:
        return self._file

    def record(
        self,
        action: str,
        target: str,
        before: Any = None,
        after: Any = None,
        backup_id: str = "",
        success: bool = True,
        details: str = "",
    ) -> None:
        entry = {
            "timestamp_utc": datetime.now(timezone.utc).isoformat(),
            "action": action,
            "target": target,
            "before": before,
            "after": after,
            "backup_id": backup_id,
            "success": success,
            "details": details,
        }
        try:
            with self._file.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(entry, ensure_ascii=False, default=str) + "\n")
        except OSError:
            pass

    def recent_entries(self, limit: int = 50) -> list[dict[str, Any]]:
        if not self._file.exists():
            return []
        try:
            lines = self._file.read_text(encoding="utf-8").splitlines()
            items: list[dict[str, Any]] = []
            for line in lines[-limit:]:
                try:
                    items.append(json.loads(line))
                except ValueError:
                    continue
            return list(reversed(items))
        except OSError:
            return []
