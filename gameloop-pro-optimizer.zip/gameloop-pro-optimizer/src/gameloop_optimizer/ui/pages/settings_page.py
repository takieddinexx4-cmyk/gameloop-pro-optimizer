"""Settings page: language/RTL, paths, monitor cadence, and GitHub Release update check."""

from __future__ import annotations

import webbrowser

from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QSpinBox,
)

from gameloop_optimizer.app_core.models import UpdateInfo
from gameloop_optimizer.app_core.service_container import ServiceContainer
from gameloop_optimizer.ui.pages.base_page import BasePage
from gameloop_optimizer.ui.widgets.cards import GlassCard


class SettingsPage(BasePage):
    def __init__(self, services: ServiceContainer, parent=None) -> None:
        super().__init__(services, parent)
        self._build_ui()
        self._load_values()

    def _build_ui(self) -> None:
        card = GlassCard()
        self.form = QFormLayout()
        self.form.setSpacing(10)

        self.lang_combo = QComboBox()
        self.lang_combo.addItem("العربية (Arabic - RTL)", "ar")
        self.lang_combo.addItem("English (LTR)", "en")

        path_row = QHBoxLayout()
        self.custom_gl_input = QLineEdit()
        self.browse_btn = QPushButton()
        self.browse_btn.clicked.connect(self._browse_gl_path)
        path_row.addWidget(self.custom_gl_input, 1)
        path_row.addWidget(self.browse_btn)

        self.interval_spin = QSpinBox()
        self.interval_spin.setRange(500, 5000)
        self.interval_spin.setSingleStep(250)

        self.ping_chk = QCheckBox()
        self.ping_host_input = QLineEdit()

        self.log_age_spin = QSpinBox()
        self.log_age_spin.setRange(0, 365)

        self.gh_owner_input = QLineEdit()
        self.gh_repo_input = QLineEdit()

        self.form.addRow("", self.lang_combo)
        self.form.addRow("", path_row)
        self.form.addRow("", self.interval_spin)
        self.form.addRow("", self.ping_chk)
        self.form.addRow("", self.ping_host_input)
        self.form.addRow("", self.log_age_spin)
        self.form.addRow("", self.gh_owner_input)
        self.form.addRow("", self.gh_repo_input)
        card.root_layout.addLayout(self.form)

        btn_row = QHBoxLayout()
        self.save_btn = QPushButton()
        self.save_btn.setObjectName("PrimaryButton")
        self.save_btn.clicked.connect(self._save)

        self.update_btn = QPushButton()
        self.update_btn.clicked.connect(self._check_updates)

        btn_row.addWidget(self.save_btn)
        btn_row.addWidget(self.update_btn)
        btn_row.addStretch(1)
        card.root_layout.addLayout(btn_row)

        self.page_layout.addWidget(card)
        self.page_layout.addStretch(1)

    def retranslate_ui(self) -> None:
        labels = [
            self.t("settings.language"),
            self.t("settings.custom_gl_path"),
            self.t("settings.monitor_interval"),
            self.t("settings.enable_ping"),
            self.t("settings.ping_host"),
            self.t("settings.log_age"),
            self.t("settings.gh_owner"),
            self.t("settings.gh_repo"),
        ]
        for idx, text in enumerate(labels):
            item = self.form.itemAt(idx, QFormLayout.ItemRole.LabelRole)
            if item and item.widget():
                item.widget().setText(text)
        self.browse_btn.setText(self.t("common.browse"))
        self.save_btn.setText(self.t("settings.save"))
        self.update_btn.setText(self.t("settings.check_updates"))

    def _load_values(self) -> None:
        cfg = self.services.config_manager.config
        idx = self.lang_combo.findData(cfg.language)
        if idx >= 0:
            self.lang_combo.setCurrentIndex(idx)
        self.custom_gl_input.setText(cfg.custom_gameloop_path)
        self.interval_spin.setValue(cfg.monitor_interval_ms)
        self.ping_chk.setChecked(cfg.enable_ping_monitor)
        self.ping_host_input.setText(cfg.ping_target_host)
        self.log_age_spin.setValue(cfg.cleaner_log_min_age_days)
        self.gh_owner_input.setText(cfg.github_owner)
        self.gh_repo_input.setText(cfg.github_repo)

    def _browse_gl_path(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, self.t("settings.custom_gl_path"))
        if folder:
            self.custom_gl_input.setText(folder)

    def _save(self) -> None:
        cfg = self.services.config_manager.config
        new_lang = self.lang_combo.currentData()
        cfg.language = new_lang
        cfg.custom_gameloop_path = self.custom_gl_input.text().strip()
        cfg.monitor_interval_ms = self.interval_spin.value()
        cfg.enable_ping_monitor = self.ping_chk.isChecked()
        cfg.ping_target_host = self.ping_host_input.text().strip() or "1.1.1.1"
        cfg.cleaner_log_min_age_days = self.log_age_spin.value()
        cfg.github_owner = self.gh_owner_input.text().strip()
        cfg.github_repo = self.gh_repo_input.text().strip()
        self.services.config_manager.save(cfg)
        self.services.translator.set_language(new_lang)
        QMessageBox.information(self, self.t("common.success"), "Settings saved.")

    def _check_updates(self) -> None:
        def on_done(info: UpdateInfo) -> None:
            if not info.checked:
                QMessageBox.information(self, self.t("common.info"), info.error or "Unable to check updates.")
                return
            if info.update_available:
                ans = QMessageBox.question(
                    self,
                    self.t("common.info"),
                    f"New release available: v{info.latest_version} (current v{info.current_version}).\n"
                    "Open the official GitHub Release page to review SHA-256 and download manually?",
                )
                if ans == QMessageBox.StandardButton.Yes and info.release_url.startswith("https://github.com/"):
                    webbrowser.open(info.release_url)
            else:
                QMessageBox.information(
                    self,
                    self.t("common.info"),
                    f"You are on the latest version (v{info.current_version}).",
                )

        self.run_background_task(
            self.t("settings.check_updates"), self.services.update_manager.check_for_updates, on_done
        )
