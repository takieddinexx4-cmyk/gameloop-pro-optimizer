"""Hardware-capped PUBG Mobile / GameLoop configuration profiles."""
