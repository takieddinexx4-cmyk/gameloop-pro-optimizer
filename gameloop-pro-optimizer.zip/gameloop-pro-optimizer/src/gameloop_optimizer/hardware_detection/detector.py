"""Real hardware, OS, display, storage, and GameLoop environment detection."""

from __future__ import annotations

import ctypes
import os
import platform
import shutil
import sys
from pathlib import Path
from typing import Any, Callable

import psutil

from gameloop_optimizer.app_core.models import HardwareProfile, MetricValue
from gameloop_optimizer.hardware_detection.sensors import SensorProbe
from gameloop_optimizer.logging.logger import get_logger

logger = get_logger("hardware_detection.detector")


def _detect_display_windows() -> tuple[str | None, int | None]:
    if sys.platform != "win32":
        return None, None
    try:
        class DEVMODEW(ctypes.Structure):
            _fields_ = [
                ("dmDeviceName", ctypes.c_wchar * 32),
                ("dmSpecVersion", ctypes.c_ushort),
                ("dmDriverVersion", ctypes.c_ushort),
                ("dmSize", ctypes.c_ushort),
                ("dmDriverExtra", ctypes.c_ushort),
                ("dmFields", ctypes.c_ulong),
                ("dmPositionX", ctypes.c_long),
                ("dmPositionY", ctypes.c_long),
                ("dmDisplayOrientation", ctypes.c_ulong),
                ("dmDisplayFixedOutput", ctypes.c_ulong),
                ("dmColor", ctypes.c_short),
                ("dmDuplex", ctypes.c_short),
                ("dmYResolution", ctypes.c_short),
                ("dmTTOption", ctypes.c_short),
                ("dmCollate", ctypes.c_short),
                ("dmFormName", ctypes.c_wchar * 32),
                ("dmLogPixels", ctypes.c_ushort),
                ("dmBitsPerPel", ctypes.c_ulong),
                ("dmPelsWidth", ctypes.c_ulong),
                ("dmPelsHeight", ctypes.c_ulong),
                ("dmDisplayFlags", ctypes.c_ulong),
                ("dmDisplayFrequency", ctypes.c_ulong),
            ]

        dm = DEVMODEW()
        dm.dmSize = ctypes.sizeof(DEVMODEW)
        # ENUM_CURRENT_SETTINGS = -1
        if ctypes.windll.user32.EnumDisplaySettingsW(None, -1, ctypes.byref(dm)):
            res = f"{dm.dmPelsWidth}x{dm.dmPelsHeight}" if dm.dmPelsWidth else None
            hz = int(dm.dmDisplayFrequency) if dm.dmDisplayFrequency > 1 else None
            return res, hz
    except Exception as exc:  # noqa: BLE001
        logger.debug("Display detection failed: %s", exc)
    return None, None


def _read_64bit_vram_registry() -> float | None:
    """Read 64-bit VRAM size from Windows display class registry (avoids WMI 4GB cap)."""
    if sys.platform != "win32":
        return None
    try:
        import winreg

        base = r"SYSTEM\ControlSet001\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}"
        best_bytes = 0
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, base) as root:
            for idx in range(0, 16):
                sub_name = f"{idx:04d}"
                try:
                    with winreg.OpenKey(root, sub_name) as sub:
                        val, reg_type = winreg.QueryValueEx(
                            sub, "HardwareInformation.qwMemorySize"
                        )
                        if reg_type == winreg.REG_QWORD and isinstance(val, int):
                            best_bytes = max(best_bytes, val)
                        elif reg_type == winreg.REG_BINARY and isinstance(val, bytes):
                            best_bytes = max(best_bytes, int.from_bytes(val[:8], "little"))
                except OSError:
                    continue
        if best_bytes > 0:
            return round(best_bytes / (1024**3), 2)
    except Exception as exc:  # noqa: BLE001
        logger.debug("64-bit VRAM registry lookup failed: %s", exc)
    return None


def _query_wmi_hardware() -> dict[str, Any]:
    """Query CPU, GPU, and Disk info via WMI on Windows safely."""
    data: dict[str, Any] = {}
    if sys.platform != "win32":
        return data
    try:
        import pythoncom
        import wmi
    except ImportError:
        return data

    pythoncom.CoInitialize()
    try:
        conn = wmi.WMI()
        cpus = conn.Win32_Processor()
        if cpus:
            data["cpu_name"] = str(getattr(cpus[0], "Name", "")).strip()

        gpus = conn.Win32_VideoController()
        if gpus:
            # Prefer discrete/highest-VRAM adapter if multiple adapters exist
            chosen = max(
                gpus,
                key=lambda g: int(getattr(g, "AdapterRAM", 0) or 0),
            )
            data["gpu_name"] = str(getattr(chosen, "Name", "")).strip()
            data["gpu_driver"] = str(getattr(chosen, "DriverVersion", "")).strip()
            raw_ram = getattr(chosen, "AdapterRAM", None)
            if raw_ram and int(raw_ram) > 0:
                data["gpu_vram_gb"] = round(int(raw_ram) / (1024**3), 2)

        disks = conn.Win32_DiskDrive()
        if disks:
            models = []
            for d in disks[:4]:
                model = str(getattr(d, "Model", "")).strip()
                media = str(getattr(d, "MediaType", "")).strip()
                if model:
                    models.append(f"{model} ({media})" if media else model)
            if models:
                data["storage_summary"] = "; ".join(models)
    except Exception as exc:  # noqa: BLE001
        logger.warning("WMI hardware query error: %s", exc)
    finally:
        pythoncom.CoUninitialize()
    return data


class HardwareDetector:
    def __init__(
        self,
        gameloop_discovery=None,
        sensor_probe: SensorProbe | None = None,
        wmi_querier: Callable[[], dict[str, Any]] | None = None,
        display_querier: Callable[[], tuple[str | None, int | None]] | None = None,
        vram_reg_querier: Callable[[], float | None] | None = None,
    ) -> None:
        self._gameloop_discovery = gameloop_discovery
        self._sensors = sensor_probe or SensorProbe()
        self._wmi_querier = wmi_querier or _query_wmi_hardware
        self._display_querier = display_querier or _detect_display_windows
        self._vram_reg_querier = vram_reg_querier or _read_64bit_vram_registry

    def detect(self, progress_cb=None, cancel_token=None) -> HardwareProfile:
        profile = HardwareProfile()
        if progress_cb:
            progress_cb(10, "Reading CPU and memory metrics...")

        wmi_info = self._wmi_querier()

        cpu_name = wmi_info.get("cpu_name") or platform.processor() or ""
        profile.cpu_name = (
            MetricValue(value=cpu_name, available=True)
            if cpu_name
            else MetricValue(available=False, reason="CPU model string unavailable.")
        )

        phys = psutil.cpu_count(logical=False)
        logi = psutil.cpu_count(logical=True)
        profile.cpu_cores_physical = (
            MetricValue(value=phys, unit="cores", available=True)
            if phys
            else MetricValue(available=False, reason="Physical core count unavailable.")
        )
        profile.cpu_cores_logical = (
            MetricValue(value=logi, unit="threads", available=True)
            if logi
            else MetricValue(available=False, reason="Logical core count unavailable.")
        )

        freq = psutil.cpu_freq()
        if freq and freq.max:
            profile.cpu_freq_mhz = MetricValue(value=round(freq.max, 0), unit="MHz", available=True)
        elif freq and freq.current:
            profile.cpu_freq_mhz = MetricValue(value=round(freq.current, 0), unit="MHz", available=True)
        else:
            profile.cpu_freq_mhz = MetricValue(available=False, reason="CPU frequency unavailable.")

        vm = psutil.virtual_memory()
        profile.ram_total_gb = MetricValue(value=round(vm.total / (1024**3), 2), unit="GB", available=True)
        profile.ram_available_gb = MetricValue(value=round(vm.available / (1024**3), 2), unit="GB", available=True)
        profile.ram_usage_percent = MetricValue(value=round(vm.percent, 1), unit="%", available=True)

        if progress_cb:
            progress_cb(45, "Reading GPU, display, and storage...")

        gpu_name = wmi_info.get("gpu_name")
        profile.gpu_name = (
            MetricValue(value=gpu_name, available=True)
            if gpu_name
            else MetricValue(available=False, reason="GPU adapter info requires Windows WMI.")
        )

        vram_reg = self._vram_reg_querier()
        vram_gb = vram_reg if vram_reg is not None else wmi_info.get("gpu_vram_gb")
        profile.gpu_vram_gb = (
            MetricValue(value=vram_gb, unit="GB", available=True)
            if vram_gb is not None
            else MetricValue(available=False, reason="Dedicated VRAM could not be read reliably.")
        )

        drv = wmi_info.get("gpu_driver")
        profile.gpu_driver_version = (
            MetricValue(value=drv, available=True)
            if drv
            else MetricValue(available=False, reason="GPU driver version unavailable.")
        )

        storage_summary = wmi_info.get("storage_summary")
        profile.storage_summary = (
            MetricValue(value=storage_summary, available=True)
            if storage_summary
            else MetricValue(available=False, reason="Physical disk model unavailable.")
        )

        sys_drive = os.environ.get("SystemDrive", "C:") + os.sep if sys.platform == "win32" else os.sep
        profile.system_drive_free_gb = self._free_space_metric(sys_drive)

        win_ver = f"{platform.system()} {platform.release()} (Build {platform.version()})"
        profile.windows_version = MetricValue(value=win_ver, available=True)

        disp_res, disp_hz = self._display_querier()
        profile.display_resolution = (
            MetricValue(value=disp_res, available=True)
            if disp_res
            else MetricValue(available=False, reason="Display resolution unavailable.")
        )
        profile.display_refresh_hz = (
            MetricValue(value=disp_hz, unit="Hz", available=True)
            if disp_hz
            else MetricValue(available=False, reason="Monitor refresh rate unavailable.")
        )

        if progress_cb:
            progress_cb(70, "Probing temperature sensors...")

        profile.cpu_temp_c, profile.gpu_temp_c = self._sensors.read_temperatures()

        if progress_cb:
            progress_cb(90, "Detecting GameLoop installation...")

        if self._gameloop_discovery is not None:
            gl_info = self._gameloop_discovery.discover()
            profile.gameloop_installed = gl_info.installed
            profile.gameloop_path = gl_info.install_dir
            profile.gameloop_version = (
                MetricValue(value=gl_info.version, available=True)
                if gl_info.version
                else MetricValue(
                    available=False,
                    reason="GameLoop not installed." if not gl_info.installed else "GameLoop version string not found.",
                )
            )
            if gl_info.installed and gl_info.install_dir:
                profile.gameloop_drive_free_gb = self._free_space_metric(gl_info.install_dir)
            else:
                profile.gameloop_drive_free_gb = MetricValue(
                    available=False, reason="GameLoop installation directory not found."
                )

        if progress_cb:
            progress_cb(100, "Hardware scan complete.")
        return profile

    @staticmethod
    def _free_space_metric(path_str: str) -> MetricValue:
        try:
            target = Path(path_str)
            probe = target if target.exists() else Path(target.anchor or os.sep)
            usage = shutil.disk_usage(str(probe))
            return MetricValue(value=round(usage.free / (1024**3), 2), unit="GB", available=True)
        except OSError as exc:
            return MetricValue(available=False, reason=str(exc))
