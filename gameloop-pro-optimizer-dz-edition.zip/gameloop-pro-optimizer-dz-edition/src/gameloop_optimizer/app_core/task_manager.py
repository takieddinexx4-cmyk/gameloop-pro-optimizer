"""Unified Operations & Task Manager for tracking active and historical tasks.

Pure-Python thread-safe core so it can be unit-tested without Qt, while allowing
UI panels to subscribe to state transitions cleanly.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
import threading
from typing import Callable
import uuid

OP_STATUS_RUNNING = "running"
OP_STATUS_COMPLETED = "completed"
OP_STATUS_FAILED = "failed"
OP_STATUS_CANCELLED = "cancelled"


@dataclass
class OperationRecord:
    """Represents a single background operation executed by the optimizer."""

    op_id: str
    name: str
    description: str = ""
    status: str = OP_STATUS_RUNNING
    # None indicates indeterminate progress (never fabricate fake percentages)
    progress: int | None = None
    started_at: str = ""
    finished_at: str = ""
    steps_log: list[str] = field(default_factory=list)
    result_summary: str = ""
    cancellable: bool = True

    def to_dict(self) -> dict[str, object]:
        return {
            "op_id": self.op_id,
            "name": self.name,
            "description": self.description,
            "status": self.status,
            "progress": self.progress,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "steps_log": list(self.steps_log),
            "result_summary": self.result_summary,
            "cancellable": self.cancellable,
        }


class TaskManager:
    """Tracks active operations, prevents duplicate concurrent runs, and stores history."""

    def __init__(self, max_history: int = 80) -> None:
        self._lock = threading.RLock()
        self._max_history = max(10, int(max_history))
        self._active: dict[str, OperationRecord] = {}
        self._history: list[OperationRecord] = []
        self._cancel_callbacks: dict[str, Callable[[], None]] = {}
        self._listeners: list[Callable[[OperationRecord], None]] = []

    def subscribe(self, listener: Callable[[OperationRecord], None]) -> None:
        with self._lock:
            if listener not in self._listeners:
                self._listeners.append(listener)

    def unsubscribe(self, listener: Callable[[OperationRecord], None]) -> None:
        with self._lock:
            if listener in self._listeners:
                self._listeners.remove(listener)

    def _notify(self, record: OperationRecord) -> None:
        with self._lock:
            listeners = list(self._listeners)
        for fn in listeners:
            try:
                fn(record)
            except Exception:  # noqa: BLE001 - UI listener errors must not crash backend
                continue

    @staticmethod
    def _now_iso() -> str:
        return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")

    def has_running_operation(self, name: str | None = None) -> bool:
        with self._lock:
            if name is None:
                return bool(self._active)
            return any(op.name == name for op in self._active.values())

    def start_operation(
        self,
        name: str,
        description: str = "",
        cancellable: bool = True,
        cancel_callback: Callable[[], None] | None = None,
        allow_duplicate: bool = False,
    ) -> OperationRecord:
        with self._lock:
            if not allow_duplicate and self.has_running_operation(name):
                raise RuntimeError(f"Operation '{name}' is already running.")
            op_id = uuid.uuid4().hex[:10]
            record = OperationRecord(
                op_id=op_id,
                name=name,
                description=description or name,
                status=OP_STATUS_RUNNING,
                progress=None,
                started_at=self._now_iso(),
                steps_log=[f"[{self._now_iso()}] Started: {description or name}"],
                cancellable=cancellable,
            )
            self._active[op_id] = record
            if cancel_callback is not None:
                self._cancel_callbacks[op_id] = cancel_callback
        self._notify(record)
        return record

    def update_progress(
        self,
        op_id: str,
        progress: int | None = None,
        message: str = "",
    ) -> OperationRecord | None:
        with self._lock:
            record = self._active.get(op_id)
            if record is None:
                return None
            if progress is not None:
                record.progress = max(0, min(100, int(progress)))
            if message:
                record.description = message
                entry = f"[{self._now_iso()}] {message}"
                if not record.steps_log or record.steps_log[-1] != entry:
                    record.steps_log.append(entry)
                    if len(record.steps_log) > 200:
                        record.steps_log = record.steps_log[-200:]
        self._notify(record)
        return record

    def finish_operation(
        self,
        op_id: str,
        status: str = OP_STATUS_COMPLETED,
        result_summary: str = "",
    ) -> OperationRecord | None:
        if status not in (OP_STATUS_COMPLETED, OP_STATUS_FAILED, OP_STATUS_CANCELLED):
            status = OP_STATUS_COMPLETED
        with self._lock:
            record = self._active.pop(op_id, None)
            self._cancel_callbacks.pop(op_id, None)
            if record is None:
                return None
            record.status = status
            record.finished_at = self._now_iso()
            if status == OP_STATUS_COMPLETED and record.progress is not None:
                record.progress = 100
            if result_summary:
                record.result_summary = result_summary
                record.steps_log.append(f"[{record.finished_at}] {status.upper()}: {result_summary}")
            else:
                record.steps_log.append(f"[{record.finished_at}] {status.upper()}")
            self._history.insert(0, record)
            if len(self._history) > self._max_history:
                self._history = self._history[: self._max_history]
        self._notify(record)
        return record

    def request_cancel(self, op_id: str) -> bool:
        with self._lock:
            record = self._active.get(op_id)
            cb = self._cancel_callbacks.get(op_id)
            if record is None or not record.cancellable:
                return False
            record.steps_log.append(f"[{self._now_iso()}] Cancellation requested by user.")
        if cb is not None:
            try:
                cb()
            except Exception:  # noqa: BLE001
                return False
        self._notify(record)
        return True

    def active_operations(self) -> list[OperationRecord]:
        with self._lock:
            return list(self._active.values())

    def history(self, limit: int = 30) -> list[OperationRecord]:
        with self._lock:
            return list(self._history[: max(1, int(limit))])

    def all_recent(self, limit: int = 30) -> list[OperationRecord]:
        with self._lock:
            combined = list(self._active.values()) + list(self._history)
            return combined[: max(1, int(limit))]
