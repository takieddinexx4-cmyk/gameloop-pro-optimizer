"""Unit tests for GAMELOOP PRO OPTIMIZER — DZ EDITION new features, localization, and safety."""

from __future__ import annotations

import json
import os
from pathlib import Path
from types import SimpleNamespace

import psutil
import pytest

from gameloop_optimizer.app_core.constants import APP_EDITION, APP_NAME, APP_VERSION
from gameloop_optimizer.app_core.task_manager import (
    OP_STATUS_CANCELLED,
    OP_STATUS_COMPLETED,
    OP_STATUS_FAILED,
    OP_STATUS_RUNNING,
    TaskManager,
)
from gameloop_optimizer.gaming_tools.process_tools import ProcessTools
from gameloop_optimizer.hardware_detection.sensors import SensorProbe
from gameloop_optimizer.logging.audit import AuditLogger
from gameloop_optimizer.performance_monitor.monitor import PerformanceMonitor


def test_dz_edition_branding_constants() -> None:
    assert "DZ EDITION" in APP_NAME
    assert APP_EDITION == "DZ EDITION"
    assert bool(APP_VERSION)


def test_task_manager_lifecycle_indeterminate_and_cancel() -> None:
    tm = TaskManager(max_history=20)
    cancelled_flag = {"hit": False}

    op = tm.start_operation(
        name="Quick Scan",
        description="Scanning hardware",
        cancellable=True,
        cancel_callback=lambda: cancelled_flag.__setitem__("hit", True),
    )
    assert op.status == OP_STATUS_RUNNING
    assert op.progress is None  # Indeterminate until real percent is reported

    # Duplicate concurrent run of same operation must be blocked
    with pytest.raises(RuntimeError):
        tm.start_operation(name="Quick Scan")

    tm.update_progress(op.op_id, progress=45, message="Probing GPU")
    assert tm.active_operations()[0].progress == 45

    assert tm.request_cancel(op.op_id) is True
    assert cancelled_flag["hit"] is True

    finished = tm.finish_operation(op.op_id, status=OP_STATUS_CANCELLED, result_summary="User cancelled")
    assert finished is not None
    assert finished.status == OP_STATUS_CANCELLED
    assert len(tm.active_operations()) == 0
    assert len(tm.history()) == 1

    # Verify completed and failed states too
    op2 = tm.start_operation(name="Backup")
    tm.update_progress(op2.op_id, progress=80, message="Hashing SHA-256")
    done2 = tm.finish_operation(op2.op_id, status=OP_STATUS_COMPLETED, result_summary="Verified")
    assert done2 is not None and done2.progress == 100

    op3 = tm.start_operation(name="ADB Repair")
    done3 = tm.finish_operation(op3.op_id, status=OP_STATUS_FAILED, result_summary="ADB missing")
    assert done3 is not None and done3.status == OP_STATUS_FAILED
    assert len(tm.history()) == 3


def test_process_tools_self_pid_and_details(
    audit_logger: AuditLogger, monkeypatch: pytest.MonkeyPatch
) -> None:
    tools = ProcessTools(audit_logger=audit_logger)

    # Terminating current optimizer PID must always be blocked
    ok_self, msg_self = tools.terminate_process(os.getpid())
    assert ok_self is False
    assert "blocked" in msg_self.lower()

    # Fake process details check
    class FakeProc:
        def __init__(self, pid: int) -> None:
            self.pid = pid

        def name(self) -> str:
            return "AndroidEmulatorEx.exe"

        def exe(self) -> str:
            return r"C:\Program Files\TxGameAssistant\ui\AndroidEmulatorEx.exe"

        def username(self) -> str:
            return "PC\\Gamer"

        def status(self) -> str:
            return "running"

        def cpu_percent(self, interval=None) -> float:
            return 18.5

        def memory_info(self):
            return SimpleNamespace(rss=512 * 1024 * 1024)

        def num_threads(self) -> int:
            return 24

    monkeypatch.setattr(psutil, "Process", FakeProc)
    ok, details = tools.get_process_details(4242)
    assert ok is True
    assert isinstance(details, dict)
    assert details["is_gameloop"] is True
    assert details["is_protected"] is False
    assert details["ram_mb"] == 512.0


def test_sensor_probe_vram_and_monitor_network(monkeypatch: pytest.MonkeyPatch) -> None:
    probe_missing = SensorProbe(
        wmi_provider=lambda: (None, None),
        nvidia_provider=lambda: (None, None),
        psutil_temp_provider=lambda: None,
        nvidia_vram_provider=lambda: (None, None),
    )
    used, total = probe_missing.read_gpu_vram()
    assert used.available is False
    assert total.available is False

    probe_nv = SensorProbe(
        wmi_provider=lambda: (None, None),
        nvidia_provider=lambda: (64.0, 42.0),
        psutil_temp_provider=lambda: None,
        nvidia_vram_provider=lambda: (2048.0, 8192.0),
    )
    used_nv, total_nv = probe_nv.read_gpu_vram()
    assert used_nv.available is True and used_nv.value == 2048
    assert total_nv.available is True and total_nv.value == 8192

    counters = iter(
        [
            SimpleNamespace(bytes_sent=100_000, bytes_recv=200_000),
            SimpleNamespace(bytes_sent=151_200, bytes_recv=404_800),
        ]
    )
    monkeypatch.setattr(psutil, "cpu_percent", lambda interval=None: 22.0)
    monkeypatch.setattr(psutil, "virtual_memory", lambda: SimpleNamespace(percent=50.0, used=8 * 1024**3))
    monkeypatch.setattr(psutil, "process_iter", lambda *a, **kw: [])
    monkeypatch.setattr(psutil, "net_io_counters", lambda: next(counters))

    mon = PerformanceMonitor(sensor_probe=probe_nv)
    snap = mon.sample()
    assert snap.gpu_vram_used_mb.value == 2048
    assert snap.net_sent_kbps.available is True
    assert snap.net_recv_kbps.available is True


def test_locales_full_ar_en_parity() -> None:
    root = Path(__file__).resolve().parent.parent
    en = json.loads((root / "locales" / "en.json").read_text(encoding="utf-8"))
    ar = json.loads((root / "locales" / "ar.json").read_text(encoding="utf-8"))
    assert set(en.keys()) == set(ar.keys())
    for k in en:
        assert isinstance(en[k], str) and en[k].strip()
        assert isinstance(ar[k], str) and ar[k].strip()


def test_dz_assets_and_zero_shell_true() -> None:
    root = Path(__file__).resolve().parent.parent
    assets = root / "assets"
    for fname in (
        "app_icon.ico",
        "app_icon.png",
        "dz_logo_square.png",
        "dz_logo_square.svg",
        "dz_logo_small.png",
        "dz_logo_horizontal.png",
        "dz_logo_horizontal.svg",
        "dz_splash.png",
    ):
        fpath = assets / fname
        assert fpath.exists() and fpath.stat().st_size > 100

    for py_file in (root / "src").rglob("*.py"):
        text = py_file.read_text(encoding="utf-8")
        assert "shell=True" not in text, f"Forbidden shell=True found in {py_file}"
