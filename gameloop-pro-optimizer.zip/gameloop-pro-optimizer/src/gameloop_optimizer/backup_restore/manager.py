"""SHA-256 verified backup and granular/full restoration manager."""

from __future__ import annotations

import hashlib
import json
import shutil
import uuid
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from gameloop_optimizer.app_core.models import BackupRecord
from gameloop_optimizer.app_core.paths import get_backups_dir
from gameloop_optimizer.backup_restore.registry_io import (
    RegistryBackend,
    RegistryValueSnapshot,
    WindowsRegistryBackend,
)
from gameloop_optimizer.logging.audit import AuditLogger
from gameloop_optimizer.logging.logger import get_logger

logger = get_logger("backup_restore.manager")


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


class BackupManager:
    def __init__(
        self,
        backups_dir: Path | None = None,
        registry: RegistryBackend | None = None,
        audit_logger: AuditLogger | None = None,
    ) -> None:
        self._dir = backups_dir or get_backups_dir()
        self._dir.mkdir(parents=True, exist_ok=True)
        self.registry: RegistryBackend = registry or WindowsRegistryBackend()
        self._audit = audit_logger or AuditLogger()
        self._custom_restorers: dict[str, Callable[[dict[str, Any]], tuple[bool, str]]] = {}

    def register_custom_restorer(
        self, item_type: str, handler: Callable[[dict[str, Any]], tuple[bool, str]]
    ) -> None:
        self._custom_restorers[item_type] = handler

    def create_backup(
        self,
        category: str,
        description: str,
        registry_snapshots: list[RegistryValueSnapshot] | None = None,
        file_paths: list[str] | None = None,
        custom_items: list[dict[str, Any]] | None = None,
    ) -> BackupRecord:
        backup_id = f"{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}_{uuid.uuid4().hex[:8]}"
        created_at = datetime.now(timezone.utc).isoformat()
        items: list[dict[str, Any]] = []

        for snap in registry_snapshots or []:
            items.append({"item_type": "registry", "data": asdict(snap)})

        files_dir = self._dir / f"{backup_id}_files"
        for idx, raw_path in enumerate(file_paths or []):
            src = Path(raw_path)
            if not src.exists() or not src.is_file():
                continue
            files_dir.mkdir(parents=True, exist_ok=True)
            copied_name = f"{idx}_{src.name}"
            dst = files_dir / copied_name
            shutil.copy2(src, dst)
            items.append(
                {
                    "item_type": "file",
                    "data": {
                        "original_path": str(src),
                        "stored_rel": f"{files_dir.name}/{copied_name}",
                        "sha256": _sha256_file(dst),
                    },
                }
            )

        for custom in custom_items or []:
            items.append(custom)

        payload = {
            "backup_id": backup_id,
            "created_at": created_at,
            "category": category,
            "description": description,
            "items": items,
        }
        canonical = json.dumps(payload, sort_keys=True, ensure_ascii=False).encode("utf-8")
        digest = _sha256_bytes(canonical)

        envelope = {"sha256": digest, "payload": payload}
        out_file = self._dir / f"{backup_id}.json"
        out_file.write_text(json.dumps(envelope, indent=2, ensure_ascii=False), encoding="utf-8")

        self._audit.record(
            action="backup_create",
            target=backup_id,
            after={"category": category, "item_count": len(items), "sha256": digest},
            backup_id=backup_id,
            success=True,
            details=description,
        )
        return BackupRecord(
            backup_id=backup_id,
            created_at=created_at,
            category=category,
            description=description,
            sha256=digest,
            item_count=len(items),
            file_path=str(out_file),
            verified=True,
        )

    def verify_backup(self, backup_id: str) -> tuple[bool, str, dict[str, Any] | None]:
        file_path = self._dir / f"{backup_id}.json"
        if not file_path.is_file():
            return False, "Backup file does not exist.", None
        try:
            envelope = json.loads(file_path.read_text(encoding="utf-8"))
            expected_hash = envelope.get("sha256", "")
            payload = envelope.get("payload")
            if not isinstance(payload, dict):
                return False, "Malformed backup payload.", None
            canonical = json.dumps(payload, sort_keys=True, ensure_ascii=False).encode("utf-8")
            actual_hash = _sha256_bytes(canonical)
            if actual_hash != expected_hash:
                return False, "Backup integrity check failed: SHA-256 mismatch.", None

            for item in payload.get("items", []):
                if item.get("item_type") == "file":
                    fdata = item.get("data", {})
                    stored = self._dir / fdata.get("stored_rel", "")
                    if not stored.is_file():
                        return False, f"Missing backed-up file: {fdata.get('stored_rel')}", None
                    if _sha256_file(stored) != fdata.get("sha256"):
                        return False, f"Backed-up file hash mismatch: {stored.name}", None
            return True, "Integrity verified (SHA-256 valid).", payload
        except (OSError, ValueError) as exc:
            return False, f"Failed to read backup: {exc}", None

    def list_backups(self) -> list[BackupRecord]:
        records: list[BackupRecord] = []
        for path in sorted(self._dir.glob("*.json"), reverse=True):
            backup_id = path.stem
            valid, _msg, payload = self.verify_backup(backup_id)
            if payload is None:
                try:
                    raw = json.loads(path.read_text(encoding="utf-8"))
                    payload = raw.get("payload", {})
                    digest = raw.get("sha256", "")
                except (OSError, ValueError):
                    payload = {}
                    digest = ""
            else:
                raw = json.loads(path.read_text(encoding="utf-8"))
                digest = raw.get("sha256", "")

            records.append(
                BackupRecord(
                    backup_id=backup_id,
                    created_at=payload.get("created_at", "Unknown"),
                    category=payload.get("category", "unknown"),
                    description=payload.get("description", ""),
                    sha256=digest,
                    item_count=len(payload.get("items", [])),
                    file_path=str(path),
                    verified=valid,
                )
            )
        return records

    def load_backup_items(self, backup_id: str) -> list[dict[str, Any]]:
        valid, _msg, payload = self.verify_backup(backup_id)
        if not valid or not payload:
            return []
        return list(payload.get("items", []))

    def restore_backup(
        self, backup_id: str, item_indices: list[int] | None = None
    ) -> tuple[bool, list[str]]:
        valid, msg, payload = self.verify_backup(backup_id)
        if not valid or payload is None:
            return False, [msg]

        items = payload.get("items", [])
        selected = (
            [(i, items[i]) for i in item_indices if 0 <= i < len(items)]
            if item_indices is not None
            else list(enumerate(items))
        )

        logs: list[str] = []
        all_ok = True
        for idx, item in selected:
            itype = item.get("item_type")
            data = item.get("data", {})
            if itype == "registry":
                ok, res_msg = self._restore_registry_item(data)
            elif itype == "file":
                ok, res_msg = self._restore_file_item(data)
            elif itype in self._custom_restorers:
                ok, res_msg = self._custom_restorers[itype](data)
            else:
                ok, res_msg = False, f"No restorer registered for item type '{itype}'."

            logs.append(f"[{idx}] {itype}: {res_msg}")
            if not ok:
                all_ok = False

        self._audit.record(
            action="backup_restore",
            target=backup_id,
            backup_id=backup_id,
            success=all_ok,
            details="; ".join(logs),
        )
        return all_ok, logs

    def _restore_registry_item(self, data: dict[str, Any]) -> tuple[bool, str]:
        root = data["root"]
        subkey = data["subkey"]
        name = data["name"]
        if data.get("existed"):
            return self.registry.write_value(root, subkey, name, data.get("value"), data.get("reg_type", 1))
        return self.registry.delete_value(root, subkey, name)

    def _restore_file_item(self, data: dict[str, Any]) -> tuple[bool, str]:
        original = Path(data["original_path"])
        stored = self._dir / data["stored_rel"]
        try:
            original.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(stored, original)
            return True, f"Restored file to {original}"
        except OSError as exc:
            return False, f"Failed to restore {original}: {exc}"
