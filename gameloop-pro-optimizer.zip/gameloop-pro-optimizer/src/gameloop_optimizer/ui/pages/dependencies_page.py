"""Dependencies page: read-only check of Visual C++, DirectX, .NET, and Virtualization."""

from __future__ import annotations

from PySide6.QtWidgets import (
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
)

from gameloop_optimizer.app_core.models import DependencyStatus
from gameloop_optimizer.app_core.service_container import ServiceContainer
from gameloop_optimizer.ui.pages.base_page import BasePage


class DependenciesPage(BasePage):
    def __init__(self, services: ServiceContainer, parent=None) -> None:
        super().__init__(services, parent)
        self._items: list[DependencyStatus] = []
        self._build_ui()

    def _build_ui(self) -> None:
        self.subtitle_label = QLabel()
        self.subtitle_label.setObjectName("MutedLabel")
        self.page_layout.addWidget(self.subtitle_label)

        top = QHBoxLayout()
        self.check_btn = QPushButton()
        self.check_btn.setObjectName("PrimaryButton")
        self.check_btn.clicked.connect(self._run_check)
        top.addWidget(self.check_btn)
        top.addStretch(1)
        self.page_layout.addLayout(top)

        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["Dependency", "Status", "Version", "Details", "Official Link"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeMode.ResizeToContents)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        self.page_layout.addWidget(self.table, 1)

    def retranslate_ui(self) -> None:
        self.subtitle_label.setText(self.t("deps.subtitle"))
        self.check_btn.setText(self.t("deps.run_check"))
        self._render()

    def on_page_activated(self) -> None:
        if not self._items:
            self._run_check()

    def _run_check(self) -> None:
        def on_done(results: list[DependencyStatus]) -> None:
            self._items = results
            self._render()

        self.run_background_task(
            self.t("deps.run_check"), self.services.dependencies_checker.check_all, on_done
        )

    def _render(self) -> None:
        self.table.setRowCount(len(self._items))
        for row, dep in enumerate(self._items):
            self.table.setItem(row, 0, QTableWidgetItem(dep.name))
            self.table.setItem(row, 1, QTableWidgetItem(dep.status_level.upper()))
            self.table.setItem(row, 2, QTableWidgetItem(dep.version))
            self.table.setItem(row, 3, QTableWidgetItem(dep.details))
            if dep.official_url:
                btn = QPushButton(self.t("common.open_url"))
                btn.clicked.connect(lambda _c=False, u=dep.official_url: self._open_link(u))
                self.table.setCellWidget(row, 4, btn)
            else:
                self.table.setItem(row, 4, QTableWidgetItem("--"))
        self.table.resizeRowsToContents()

    def _open_link(self, url: str) -> None:
        ans = QMessageBox.question(
            self,
            self.t("common.confirm"),
            f"Open official Microsoft page in your browser?\n{url}",
        )
        if ans == QMessageBox.StandardButton.Yes:
            self.services.dependencies_checker.open_official_download(url)
