"""Safe ADB controller using argument lists and dynamic GameLoop port detection."""

from __future__ import annotations

import re
from typing import Callable, Sequence

import psutil

from gameloop_optimizer.app_core.constants import GAMELOOP_PROCESS_NAMES
from gameloop_optimizer.app_core.models import AdbDeviceInfo, AdbStatus
from gameloop_optimizer.app_core.process_runner import CommandResult, run_command
from gameloop_optimizer.gameloop_manager.discovery import GameLoopDiscovery
from gameloop_optimizer.logging.logger import get_logger

logger = get_logger("adb_manager")

_LOCAL_ENDPOINT_RE = re.compile(r"^(127\.0\.0\.1|localhost):(\d{2,5})$")
_KNOWN_GAMELOOP_ADB_PORTS = (5555, 5557, 5559, 6555)


class AdbManager:
    def __init__(
        self,
        discovery: GameLoopDiscovery,
        command_runner: Callable[[Sequence[str], float], CommandResult] | None = None,
    ) -> None:
        self._discovery = discovery
        self._runner = command_runner or (lambda args, timeout=10.0: run_command(args, timeout=timeout))

    def get_adb_path(self) -> str:
        info = self._discovery.discover()
        return info.adb_exe

    def detect_active_ports(self) -> list[int]:
        """Inspect GameLoop process listening sockets for likely ADB TCP ports."""
        ports: set[int] = set()
        try:
            for proc in psutil.process_iter(["name", "pid"]):
                name = (proc.info.get("name") or "").lower()
                if name not in GAMELOOP_PROCESS_NAMES:
                    continue
                try:
                    for conn in proc.net_connections(kind="tcp"):
                        if conn.status == psutil.CONN_LISTEN and conn.laddr:
                            port = int(conn.laddr.port)
                            if 5550 <= port <= 6600:
                                ports.add(port)
                except (psutil.AccessDenied, psutil.NoSuchProcess, AttributeError):
                    continue
        except Exception as exc:  # noqa: BLE001
            logger.debug("Port scan skipped: %s", exc)
        return sorted(ports)

    def get_status(self) -> AdbStatus:
        adb_path = self.get_adb_path()
        if not adb_path:
            return AdbStatus(
                adb_available=False,
                error="adb.exe not found (GameLoop may not be installed or ADB is missing).",
            )

        res = self._runner([adb_path, "devices"], 8.0)
        if res.not_found:
            return AdbStatus(adb_available=False, adb_path=adb_path, error="ADB executable could not be launched.")
        if res.timed_out:
            return AdbStatus(adb_available=True, adb_path=adb_path, error="ADB command timed out.")

        devices = self._parse_devices(res.stdout)
        ports = self.detect_active_ports()
        return AdbStatus(
            adb_available=True,
            adb_path=adb_path,
            server_running=res.ok,
            devices=devices,
            active_ports=ports,
            error="" if res.ok else (res.stderr or "ADB returned non-zero exit status."),
        )

    def connect(self, endpoint: str = "127.0.0.1:5555") -> tuple[bool, str]:
        adb_path = self.get_adb_path()
        if not adb_path:
            return False, "ADB executable not found."
        if not self._validate_endpoint(endpoint):
            return False, "Invalid local ADB endpoint. Expected 127.0.0.1:<port>."

        res = self._runner([adb_path, "connect", endpoint], 10.0)
        output = (res.stdout + " " + res.stderr).strip()
        if res.ok and ("connected" in output.lower() or "already connected" in output.lower()):
            return True, output or f"Connected to {endpoint}."
        return False, output or "Failed to connect to ADB endpoint."

    def disconnect(self, endpoint: str | None = None) -> tuple[bool, str]:
        adb_path = self.get_adb_path()
        if not adb_path:
            return False, "ADB executable not found."
        args = [adb_path, "disconnect"]
        if endpoint:
            if not self._validate_endpoint(endpoint):
                return False, "Invalid local ADB endpoint."
            args.append(endpoint)
        res = self._runner(args, 8.0)
        output = (res.stdout + " " + res.stderr).strip()
        return res.ok, output or "ADB disconnected."

    def repair(self, progress_cb=None, cancel_token=None) -> tuple[bool, str]:
        adb_path = self.get_adb_path()
        if not adb_path:
            return False, "Cannot repair ADB: adb.exe not found."

        if progress_cb:
            progress_cb(20, "Stopping ADB server...")
        self._runner([adb_path, "kill-server"], 8.0)

        if cancel_token and cancel_token.is_cancelled:
            return False, "Cancelled by user."

        if progress_cb:
            progress_cb(50, "Starting clean ADB server...")
        start_res = self._runner([adb_path, "start-server"], 10.0)
        if not start_res.ok:
            return False, f"Failed to start ADB server: {start_res.stderr or start_res.stdout}"

        if progress_cb:
            progress_cb(75, "Detecting emulator ADB ports and reconnecting...")

        ports = self.detect_active_ports() or list(_KNOWN_GAMELOOP_ADB_PORTS[:2])
        connected_msgs: list[str] = []
        for port in ports:
            if cancel_token and cancel_token.is_cancelled:
                return False, "Cancelled by user."
            ok, msg = self.connect(f"127.0.0.1:{port}")
            if ok:
                connected_msgs.append(f"127.0.0.1:{port} ({msg})")
                break

        status = self.get_status()
        if progress_cb:
            progress_cb(100, "ADB repair verification finished.")

        online = [d for d in status.devices if d.state == "device"]
        if online:
            return True, f"ADB repaired and verified online device(s): {', '.join(d.serial for d in online)}"
        if connected_msgs:
            return True, f"ADB server restarted; connected: {', '.join(connected_msgs)}"
        return (
            False,
            "ADB server restarted, but no running emulator device responded. Ensure GameLoop emulator is running with ADB enabled.",
        )

    @staticmethod
    def _validate_endpoint(endpoint: str) -> bool:
        match = _LOCAL_ENDPOINT_RE.match(endpoint.strip())
        if not match:
            return False
        port = int(match.group(2))
        return 1024 <= port <= 65535

    @staticmethod
    def _parse_devices(stdout: str) -> list[AdbDeviceInfo]:
        devices: list[AdbDeviceInfo] = []
        for line in stdout.splitlines():
            stripped = line.strip()
            if not stripped or stripped.startswith("List of devices") or stripped.startswith("*"):
                continue
            parts = stripped.split()
            if len(parts) >= 2:
                devices.append(AdbDeviceInfo(serial=parts[0], state=parts[1]))
        return devices
