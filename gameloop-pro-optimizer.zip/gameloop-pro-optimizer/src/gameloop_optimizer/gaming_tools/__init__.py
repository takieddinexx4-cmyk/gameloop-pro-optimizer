"""Process priority/affinity, Mouse & Input diagnostics, and verified external tool links."""
