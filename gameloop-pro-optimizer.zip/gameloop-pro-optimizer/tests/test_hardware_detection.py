"""Tests for honest sensor unavailability and hardware scoring/bottleneck analysis."""

from __future__ import annotations

from gameloop_optimizer.app_core.models import HardwareProfile, MetricValue
from gameloop_optimizer.hardware_detection.analyzer import HardwareAnalyzer
from gameloop_optimizer.hardware_detection.detector import HardwareDetector
from gameloop_optimizer.hardware_detection.sensors import SensorProbe


def test_sensors_unavailable_never_fabricated() -> None:
    probe = SensorProbe(
        wmi_provider=lambda: (None, None),
        nvidia_provider=lambda: (None, None),
        psutil_temp_provider=lambda: None,
    )
    cpu_t, gpu_t = probe.read_temperatures()
    gpu_load = probe.read_gpu_utilization()

    assert cpu_t.available is False
    assert cpu_t.value is None
    assert cpu_t.display("Unavailable") == "Unavailable"
    assert cpu_t.reason

    assert gpu_t.available is False
    assert gpu_t.value is None
    assert gpu_load.available is False
    assert gpu_load.value is None


def test_detector_handles_missing_wmi_and_sensors() -> None:
    probe = SensorProbe(
        wmi_provider=lambda: (None, None),
        nvidia_provider=lambda: (None, None),
        psutil_temp_provider=lambda: None,
    )
    detector = HardwareDetector(
        gameloop_discovery=None,
        sensor_probe=probe,
        wmi_querier=lambda: {},
        display_querier=lambda: (None, None),
        vram_reg_querier=lambda: None,
    )
    hw = detector.detect()

    assert hw.ram_total_gb.available is True
    assert hw.cpu_temp_c.available is False
    assert hw.gpu_temp_c.available is False
    assert hw.gpu_name.available is False
    assert hw.display_refresh_hz.available is False

    report = HardwareAnalyzer().analyze(hw)
    assert 0 <= report.hardware_score <= 100
    assert any("temperature sensor unavailable" in n.lower() for n in report.notes)


def test_analyzer_identifies_low_end_ram_bottleneck() -> None:
    hw = HardwareProfile(
        cpu_cores_physical=MetricValue(2, "cores", True),
        cpu_cores_logical=MetricValue(4, "threads", True),
        ram_total_gb=MetricValue(4.0, "GB", True),
        ram_usage_percent=MetricValue(88.0, "%", True),
        gpu_name=MetricValue("Intel(R) UHD Graphics 620", "", True),
        gpu_vram_gb=MetricValue(1.0, "GB", True),
        system_drive_free_gb=MetricValue(60.0, "GB", True),
        cpu_temp_c=MetricValue(available=False, reason="No sensor"),
        gameloop_installed=False,
    )
    report = HardwareAnalyzer().analyze(hw)

    assert report.gaming_readiness == "Low-End"
    assert report.hardware_score < 45
    assert any("below 8 gb" in i.lower() for i in report.issues)
    assert any("gameloop installation was not detected" in i.lower() for i in report.issues)
