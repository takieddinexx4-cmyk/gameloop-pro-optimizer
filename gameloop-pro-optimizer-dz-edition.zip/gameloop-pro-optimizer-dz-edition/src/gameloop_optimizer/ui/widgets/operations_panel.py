"""Unified Operations Center & History dialog backed by TaskManager."""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QDialog,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QPlainTextEdit,
    QProgressBar,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from gameloop_optimizer.app_core.service_container import ServiceContainer
from gameloop_optimizer.app_core.task_manager import (
    OP_STATUS_CANCELLED,
    OP_STATUS_COMPLETED,
    OP_STATUS_FAILED,
    OP_STATUS_RUNNING,
    OperationRecord,
)
from gameloop_optimizer.ui.widgets.cards import GlassCard, StatusBadge


_STATUS_BADGE_MAP = {
    OP_STATUS_RUNNING: ("Running", "cyan"),
    OP_STATUS_COMPLETED: ("Completed", "ok"),
    OP_STATUS_FAILED: ("Failed", "critical"),
    OP_STATUS_CANCELLED: ("Cancelled", "warning"),
}


class OperationsCenterDialog(QDialog):
    """Displays active operations with live progress/cancel plus full Operation History."""

    def __init__(self, services: ServiceContainer, parent=None) -> None:
        super().__init__(parent)
        self.services = services
        self.setMinimumSize(760, 520)
        self._history_records: list[OperationRecord] = []
        self._build_ui()
        self.retranslate_ui()
        self.refresh_view()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 16, 18, 16)
        layout.setSpacing(12)

        header = QHBoxLayout()
        self.title_label = QLabel()
        self.title_label.setObjectName("PageTitle")
        header.addWidget(self.title_label, 1)

        self.refresh_btn = QPushButton()
        self.refresh_btn.clicked.connect(self.refresh_view)
        header.addWidget(self.refresh_btn)
        layout.addLayout(header)

        self.tabs = QTabWidget()

        # Active operations tab
        active_tab = QWidget()
        active_layout = QVBoxLayout(active_tab)
        active_layout.setContentsMargins(12, 12, 12, 12)
        active_layout.setSpacing(10)
        self.active_container = QVBoxLayout()
        self.active_container.setSpacing(10)
        active_layout.addLayout(self.active_container)
        active_layout.addStretch(1)
        self.tabs.addTab(active_tab, "")

        # History tab
        history_tab = QWidget()
        hist_layout = QVBoxLayout(history_tab)
        hist_layout.setContentsMargins(12, 12, 12, 12)
        hist_layout.setSpacing(10)

        self.history_table = QTableWidget(0, 5)
        self.history_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.history_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.history_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.history_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        self.history_table.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeMode.Stretch)
        self.history_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.history_table.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
        self.history_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.history_table.setAlternatingRowColors(True)
        self.history_table.currentCellChanged.connect(self._on_history_selected)
        hist_layout.addWidget(self.history_table, 2)

        self.log_label = QLabel()
        self.log_label.setObjectName("SectionTitle")
        hist_layout.addWidget(self.log_label)

        self.steps_log_view = QPlainTextEdit()
        self.steps_log_view.setReadOnly(True)
        self.steps_log_view.setMaximumHeight(150)
        hist_layout.addWidget(self.steps_log_view, 1)

        self.tabs.addTab(history_tab, "")
        layout.addWidget(self.tabs, 1)

        footer = QHBoxLayout()
        footer.addStretch(1)
        self.close_btn = QPushButton()
        self.close_btn.clicked.connect(self.accept)
        footer.addWidget(self.close_btn)
        layout.addLayout(footer)

    def retranslate_ui(self) -> None:
        tr = self.services.translator.t
        self.setWindowTitle(tr("ops.title"))
        self.title_label.setText(tr("ops.title"))
        self.refresh_btn.setText(tr("common.refresh"))
        self.close_btn.setText(tr("common.close"))
        self.tabs.setTabText(0, tr("ops.tab_active"))
        self.tabs.setTabText(1, tr("ops.tab_history"))
        self.log_label.setText(tr("ops.steps_log"))
        self.history_table.setHorizontalHeaderLabels(
            [
                tr("ops.col_name"),
                tr("ops.col_status"),
                tr("ops.col_started"),
                tr("ops.col_finished"),
                tr("ops.col_result"),
            ]
        )

    def refresh_view(self) -> None:
        tr = self.services.translator.t

        # Clear active operation cards
        while self.active_container.count():
            item = self.active_container.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()

        active_ops = self.services.task_manager.active_operations()
        if not active_ops:
            empty = GlassCard()
            lbl = QLabel(tr("ops.no_active"))
            lbl.setObjectName("MutedLabel")
            lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            empty.root_layout.addWidget(lbl)
            self.active_container.addWidget(empty)
        else:
            for op in active_ops:
                card = GlassCard(accent="cyan")
                top = QHBoxLayout()
                name_lbl = QLabel(op.name)
                name_lbl.setObjectName("SectionTitle")
                top.addWidget(name_lbl, 1)

                status_text, level = _STATUS_BADGE_MAP.get(op.status, (op.status, "info"))
                top.addWidget(StatusBadge(status_text, level))
                card.root_layout.addLayout(top)

                desc_lbl = QLabel(f"{op.description}  •  {op.started_at}")
                desc_lbl.setObjectName("MutedLabel")
                desc_lbl.setWordWrap(True)
                card.root_layout.addWidget(desc_lbl)

                bar = QProgressBar()
                if op.progress is None:
                    bar.setRange(0, 0)
                    bar.setTextVisible(False)
                else:
                    bar.setRange(0, 100)
                    bar.setValue(op.progress)
                card.root_layout.addWidget(bar)

                if op.cancellable:
                    row = QHBoxLayout()
                    row.addStretch(1)
                    cancel_btn = QPushButton(tr("common.cancel"))
                    cancel_btn.setObjectName("DangerButton")
                    cancel_btn.clicked.connect(
                        lambda _checked=False, oid=op.op_id: self._cancel_op(oid)
                    )
                    row.addWidget(cancel_btn)
                    card.root_layout.addLayout(row)

                self.active_container.addWidget(card)

        self._history_records = self.services.task_manager.history(limit=50)
        self.history_table.setRowCount(len(self._history_records))
        for idx, rec in enumerate(self._history_records):
            status_text, _lvl = _STATUS_BADGE_MAP.get(rec.status, (rec.status, "info"))
            self.history_table.setItem(idx, 0, QTableWidgetItem(rec.name))
            self.history_table.setItem(idx, 1, QTableWidgetItem(status_text))
            self.history_table.setItem(idx, 2, QTableWidgetItem(rec.started_at))
            self.history_table.setItem(idx, 3, QTableWidgetItem(rec.finished_at or "--"))
            self.history_table.setItem(idx, 4, QTableWidgetItem(rec.result_summary or rec.description))

        if self._history_records:
            self.history_table.selectRow(0)
            self._on_history_selected(0)
        else:
            self.steps_log_view.setPlainText(tr("ops.no_history"))

    def _cancel_op(self, op_id: str) -> None:
        self.services.task_manager.request_cancel(op_id)
        self.refresh_view()

    def _on_history_selected(self, row_idx: int, *_args) -> None:
        if 0 <= row_idx < len(self._history_records):
            rec = self._history_records[row_idx]
            self.steps_log_view.setPlainText("\n".join(rec.steps_log))
