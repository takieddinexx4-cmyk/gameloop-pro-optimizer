"""GitHub Releases update checker with strict SHA-256 verification and user consent."""
