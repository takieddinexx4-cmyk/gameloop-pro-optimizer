# Changelog

All notable changes to **GAMELOOP PRO OPTIMIZER** are documented in this file.

## [1.0.0] - 2025-01-01

### Added
- **PC Analysis**: Real hardware detection (CPU, RAM, GPU/64-bit VRAM fallback, storage, display resolution/Hz, Windows version, GameLoop path/version) with honest `Unavailable` reporting when temperature or GPU sensors are absent.
- **Smart Optimization**: Safe / Advanced / Pro Custom modes with read -> preview -> consent -> SHA-256 backup -> apply -> verify -> rollback workflow.
- **Crash & Lag Center**: GameLoop log signature scanner, Windows Event Log reader, ADB health check, RAM/CPU/disk pressure checks, targeted `Fix Now` actions, and JSON report export.
- **PUBG Profiles**: Hardware-capped Low-End / Balanced / High Performance / Competitive / High Graphics / Custom profiles with backup, verification, import, and export.
- **GameLoop Center**: Dynamic path/port discovery, start/stop/restart, folder shortcuts, and safe ADB connect/disconnect/repair.
- **Gaming Tools & Mouse/Input**: Safe process priority/affinity evaluation, GPU preference, Mouse acceleration diagnostics with backup, and official external tool links with WinVerifyTrust signature & SHA-256 verification.
- **Live Monitor**: Low-overhead background polling with 60s and 5m QPainter graphs and read-only RTSS FPS support.
- **Cleaner PRO**: Mandatory preview, strict SAV/INI/PAK/user protection guard, and Windows Recycle Bin deletion only.
- **Backup & Restore**: SHA-256 integrity verification, full and granular item restoration.
- **Bilingual UI**: Dark Premium PySide6 interface with Arabic (true RTL) and English (LTR).
- **CI/CD**: Automated Windows build via GitHub Actions (`windows-latest`) producing `GAMELOOP PRO OPTIMIZER.exe` + `.sha256` and GitHub Releases on `v*` tags.
