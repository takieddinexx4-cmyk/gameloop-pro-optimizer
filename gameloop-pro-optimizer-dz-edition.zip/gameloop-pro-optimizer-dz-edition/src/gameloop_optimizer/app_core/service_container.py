"""Dependency container wiring backend modules for UI pages cleanly."""

from __future__ import annotations

from typing import Optional

from gameloop_optimizer.app_core.config import ConfigManager
from gameloop_optimizer.app_core.i18n import Translator
from gameloop_optimizer.app_core.models import AnalysisReport, GameLoopInstallInfo
from gameloop_optimizer.app_core.task_manager import TaskManager
from gameloop_optimizer.logging.audit import AuditLogger


class ServiceContainer:
    """Holds shared stateful services and lazily initializes domain engines."""

    def __init__(self) -> None:
        self.config_manager = ConfigManager()
        self.translator = Translator(language=self.config_manager.config.language)
        self.audit = AuditLogger()
        self.task_manager = TaskManager()

        self.last_analysis: Optional[AnalysisReport] = None
        self.last_gameloop_info: Optional[GameLoopInstallInfo] = None

        self._backup_manager = None
        self._hardware_detector = None
        self._hardware_analyzer = None
        self._gameloop_discovery = None
        self._gameloop_controller = None
        self._adb_manager = None
        self._optimization_engine = None
        self._crash_analyzer = None
        self._perf_monitor = None
        self._process_tools = None
        self._mouse_tools = None
        self._external_tools = None
        self._dep_checker = None
        self._cleaner = None
        self._profile_manager = None
        self._update_manager = None

    @property
    def backup_manager(self):
        if self._backup_manager is None:
            from gameloop_optimizer.backup_restore.manager import BackupManager

            self._backup_manager = BackupManager(audit_logger=self.audit)
        return self._backup_manager

    @property
    def hardware_detector(self):
        if self._hardware_detector is None:
            from gameloop_optimizer.hardware_detection.detector import HardwareDetector

            self._hardware_detector = HardwareDetector(
                gameloop_discovery=self.gameloop_discovery
            )
        return self._hardware_detector

    @property
    def hardware_analyzer(self):
        if self._hardware_analyzer is None:
            from gameloop_optimizer.hardware_detection.analyzer import HardwareAnalyzer

            self._hardware_analyzer = HardwareAnalyzer()
        return self._hardware_analyzer

    @property
    def gameloop_discovery(self):
        if self._gameloop_discovery is None:
            from gameloop_optimizer.gameloop_manager.discovery import GameLoopDiscovery

            self._gameloop_discovery = GameLoopDiscovery(config_manager=self.config_manager)
        return self._gameloop_discovery

    @property
    def gameloop_controller(self):
        if self._gameloop_controller is None:
            from gameloop_optimizer.gameloop_manager.controller import GameLoopController

            self._gameloop_controller = GameLoopController(discovery=self.gameloop_discovery)
        return self._gameloop_controller

    @property
    def adb_manager(self):
        if self._adb_manager is None:
            from gameloop_optimizer.adb_manager.manager import AdbManager

            self._adb_manager = AdbManager(discovery=self.gameloop_discovery)
        return self._adb_manager

    @property
    def optimization_engine(self):
        if self._optimization_engine is None:
            from gameloop_optimizer.optimization_engine.engine import OptimizationEngine

            self._optimization_engine = OptimizationEngine(
                backup_manager=self.backup_manager,
                audit_logger=self.audit,
                gameloop_discovery=self.gameloop_discovery,
            )
        return self._optimization_engine

    @property
    def crash_analyzer(self):
        if self._crash_analyzer is None:
            from gameloop_optimizer.crash_analyzer.analyzer import CrashLagAnalyzer

            self._crash_analyzer = CrashLagAnalyzer(
                gameloop_discovery=self.gameloop_discovery,
                adb_manager=self.adb_manager,
                hardware_detector=self.hardware_detector,
            )
        return self._crash_analyzer

    @property
    def performance_monitor(self):
        if self._perf_monitor is None:
            from gameloop_optimizer.performance_monitor.monitor import PerformanceMonitor

            self._perf_monitor = PerformanceMonitor(config_manager=self.config_manager)
        return self._perf_monitor

    @property
    def process_tools(self):
        if self._process_tools is None:
            from gameloop_optimizer.gaming_tools.process_tools import ProcessTools

            self._process_tools = ProcessTools(audit_logger=self.audit)
        return self._process_tools

    @property
    def mouse_tools(self):
        if self._mouse_tools is None:
            from gameloop_optimizer.gaming_tools.mouse_input import MouseInputDiagnostics

            self._mouse_tools = MouseInputDiagnostics(
                backup_manager=self.backup_manager,
                audit_logger=self.audit,
            )
        return self._mouse_tools

    @property
    def external_tools(self):
        if self._external_tools is None:
            from gameloop_optimizer.gaming_tools.external_tools import ExternalToolsManager

            self._external_tools = ExternalToolsManager()
        return self._external_tools

    @property
    def dependencies_checker(self):
        if self._dep_checker is None:
            from gameloop_optimizer.dependencies_manager.checker import DependenciesChecker

            self._dep_checker = DependenciesChecker()
        return self._dep_checker

    @property
    def cleaner(self):
        if self._cleaner is None:
            from gameloop_optimizer.cleaner.cleaner_engine import CleanerEngine

            self._cleaner = CleanerEngine(
                gameloop_discovery=self.gameloop_discovery,
                config_manager=self.config_manager,
                audit_logger=self.audit,
            )
        return self._cleaner

    @property
    def profile_manager(self):
        if self._profile_manager is None:
            from gameloop_optimizer.profiles.manager import ProfileManager

            self._profile_manager = ProfileManager(
                backup_manager=self.backup_manager,
                audit_logger=self.audit,
            )
        return self._profile_manager

    @property
    def update_manager(self):
        if self._update_manager is None:
            from gameloop_optimizer.update_manager.updater import UpdateManager

            self._update_manager = UpdateManager(config_manager=self.config_manager)
        return self._update_manager
